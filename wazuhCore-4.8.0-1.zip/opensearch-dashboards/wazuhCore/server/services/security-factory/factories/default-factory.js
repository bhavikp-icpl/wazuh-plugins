"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DefaultFactory = void 0;

var _constants = require("../../../../common/constants");

var _md = _interopRequireDefault(require("md5"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class DefaultFactory {
  constructor() {
    _defineProperty(this, "platform", '');
  }

  async getCurrentUser(request, context) {
    return {
      username: _constants.ELASTIC_NAME,
      authContext: {
        username: _constants.ELASTIC_NAME
      },
      hashUsername: (0, _md.default)(_constants.ELASTIC_NAME)
    };
  }

}

exports.DefaultFactory = DefaultFactory;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlZmF1bHQtZmFjdG9yeS50cyJdLCJuYW1lcyI6WyJEZWZhdWx0RmFjdG9yeSIsImdldEN1cnJlbnRVc2VyIiwicmVxdWVzdCIsImNvbnRleHQiLCJ1c2VybmFtZSIsIkVMQVNUSUNfTkFNRSIsImF1dGhDb250ZXh0IiwiaGFzaFVzZXJuYW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBS0E7O0FBQ0E7Ozs7OztBQUVPLE1BQU1BLGNBQU4sQ0FBaUQ7QUFBQTtBQUFBLHNDQUNuQyxFQURtQztBQUFBOztBQUVsQyxRQUFkQyxjQUFjLENBQ2xCQyxPQURrQixFQUVsQkMsT0FGa0IsRUFHbEI7QUFDQSxXQUFPO0FBQ0xDLE1BQUFBLFFBQVEsRUFBRUMsdUJBREw7QUFFTEMsTUFBQUEsV0FBVyxFQUFFO0FBQUVGLFFBQUFBLFFBQVEsRUFBRUM7QUFBWixPQUZSO0FBR0xFLE1BQUFBLFlBQVksRUFBRSxpQkFBSUYsdUJBQUo7QUFIVCxLQUFQO0FBS0Q7O0FBWHFEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVNlY3VyaXR5RmFjdG9yeSB9IGZyb20gJy4uJztcbmltcG9ydCB7XG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxufSBmcm9tICdzcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgRUxBU1RJQ19OQU1FIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgbWQ1IGZyb20gJ21kNSc7XG5cbmV4cG9ydCBjbGFzcyBEZWZhdWx0RmFjdG9yeSBpbXBsZW1lbnRzIElTZWN1cml0eUZhY3Rvcnkge1xuICBwbGF0Zm9ybTogc3RyaW5nID0gJyc7XG4gIGFzeW5jIGdldEN1cnJlbnRVc2VyKFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICBjb250ZXh0PzogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICApIHtcbiAgICByZXR1cm4ge1xuICAgICAgdXNlcm5hbWU6IEVMQVNUSUNfTkFNRSxcbiAgICAgIGF1dGhDb250ZXh0OiB7IHVzZXJuYW1lOiBFTEFTVElDX05BTUUgfSxcbiAgICAgIGhhc2hVc2VybmFtZTogbWQ1KEVMQVNUSUNfTkFNRSksXG4gICAgfTtcbiAgfVxufVxuIl19