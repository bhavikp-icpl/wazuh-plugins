"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUpdatesRoute = void 0;

var _configSchema = require("@osd/config-schema");

var _constants = require("../../../common/constants");

var _updates = require("../../services/updates");

const getUpdatesRoute = router => {
  router.get({
    path: _constants.routes.checkUpdates,
    validate: {
      query: _configSchema.schema.object({
        query_api: _configSchema.schema.maybe(_configSchema.schema.string()),
        force_query: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      var _request$query, _request$query2;

      const updates = await (0, _updates.getUpdates)(((_request$query = request.query) === null || _request$query === void 0 ? void 0 : _request$query.query_api) === 'true', ((_request$query2 = request.query) === null || _request$query2 === void 0 ? void 0 : _request$query2.force_query) === 'true');
      return response.ok({
        body: updates
      });
    } catch (error) {
      const finalError = error instanceof Error ? error : typeof error === 'string' ? new Error(error) : new Error(`Error trying to get available updates`);
      return response.customError({
        statusCode: 503,
        body: finalError
      });
    }
  });
};

exports.getUpdatesRoute = getUpdatesRoute;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC11cGRhdGVzLnRzIl0sIm5hbWVzIjpbImdldFVwZGF0ZXNSb3V0ZSIsInJvdXRlciIsImdldCIsInBhdGgiLCJyb3V0ZXMiLCJjaGVja1VwZGF0ZXMiLCJ2YWxpZGF0ZSIsInF1ZXJ5Iiwic2NoZW1hIiwib2JqZWN0IiwicXVlcnlfYXBpIiwibWF5YmUiLCJzdHJpbmciLCJmb3JjZV9xdWVyeSIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJ1cGRhdGVzIiwib2siLCJib2R5IiwiZXJyb3IiLCJmaW5hbEVycm9yIiwiRXJyb3IiLCJjdXN0b21FcnJvciIsInN0YXR1c0NvZGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDQTs7QUFDQTs7QUFDQTs7QUFFTyxNQUFNQSxlQUFlLEdBQUlDLE1BQUQsSUFBcUI7QUFDbERBLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRUMsa0JBQU9DLFlBRGY7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1JDLE1BQUFBLEtBQUssRUFBRUMscUJBQU9DLE1BQVAsQ0FBYztBQUNuQkMsUUFBQUEsU0FBUyxFQUFFRixxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiLENBRFE7QUFFbkJDLFFBQUFBLFdBQVcsRUFBRUwscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYjtBQUZNLE9BQWQ7QUFEQztBQUZaLEdBREYsRUFVRSxPQUFPRSxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsUUFBSTtBQUFBOztBQUNGLFlBQU1DLE9BQU8sR0FBRyxNQUFNLHlCQUNwQixtQkFBQUYsT0FBTyxDQUFDUixLQUFSLGtFQUFlRyxTQUFmLE1BQTZCLE1BRFQsRUFFcEIsb0JBQUFLLE9BQU8sQ0FBQ1IsS0FBUixvRUFBZU0sV0FBZixNQUErQixNQUZYLENBQXRCO0FBSUEsYUFBT0csUUFBUSxDQUFDRSxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRUY7QUFEVyxPQUFaLENBQVA7QUFHRCxLQVJELENBUUUsT0FBT0csS0FBUCxFQUFjO0FBQ2QsWUFBTUMsVUFBVSxHQUNkRCxLQUFLLFlBQVlFLEtBQWpCLEdBQ0lGLEtBREosR0FFSSxPQUFPQSxLQUFQLEtBQWlCLFFBQWpCLEdBQ0EsSUFBSUUsS0FBSixDQUFVRixLQUFWLENBREEsR0FFQSxJQUFJRSxLQUFKLENBQVcsdUNBQVgsQ0FMTjtBQU9BLGFBQU9OLFFBQVEsQ0FBQ08sV0FBVCxDQUFxQjtBQUMxQkMsUUFBQUEsVUFBVSxFQUFFLEdBRGM7QUFFMUJMLFFBQUFBLElBQUksRUFBRUU7QUFGb0IsT0FBckIsQ0FBUDtBQUlEO0FBQ0YsR0FoQ0g7QUFrQ0QsQ0FuQ00iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJUm91dGVyIH0gZnJvbSAnb3BlbnNlYXJjaC1kYXNoYm9hcmRzL3NlcnZlcic7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHsgcm91dGVzIH0gZnJvbSAnLi4vLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBnZXRVcGRhdGVzIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvdXBkYXRlcyc7XG5cbmV4cG9ydCBjb25zdCBnZXRVcGRhdGVzUm91dGUgPSAocm91dGVyOiBJUm91dGVyKSA9PiB7XG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogcm91dGVzLmNoZWNrVXBkYXRlcyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBxdWVyeV9hcGk6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGZvcmNlX3F1ZXJ5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB1cGRhdGVzID0gYXdhaXQgZ2V0VXBkYXRlcyhcbiAgICAgICAgICByZXF1ZXN0LnF1ZXJ5Py5xdWVyeV9hcGkgPT09ICd0cnVlJyxcbiAgICAgICAgICByZXF1ZXN0LnF1ZXJ5Py5mb3JjZV9xdWVyeSA9PT0gJ3RydWUnLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHVwZGF0ZXMsXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc3QgZmluYWxFcnJvciA9XG4gICAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICAgICAgPyBlcnJvclxuICAgICAgICAgICAgOiB0eXBlb2YgZXJyb3IgPT09ICdzdHJpbmcnXG4gICAgICAgICAgICA/IG5ldyBFcnJvcihlcnJvcilcbiAgICAgICAgICAgIDogbmV3IEVycm9yKGBFcnJvciB0cnlpbmcgdG8gZ2V0IGF2YWlsYWJsZSB1cGRhdGVzYCk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA1MDMsXG4gICAgICAgICAgYm9keTogZmluYWxFcnJvcixcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcbn07XG4iXX0=