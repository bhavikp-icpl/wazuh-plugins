"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _configSchema = require("@osd/config-schema");

var _common = require("../../common");

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// TODO: consider to extract entity CRUD operations and put it into a client class
function defineRoutes(router) {
  const internalUserSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    password: _configSchema.schema.maybe(_configSchema.schema.string()),
    backend_roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    attributes: _configSchema.schema.any({
      defaultValue: {}
    })
  });

  const actionGroupSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    allowed_actions: _configSchema.schema.arrayOf(_configSchema.schema.string()) // type field is not supported in legacy implementation, comment it out for now.
    // type: schema.oneOf([
    //   schema.literal('cluster'),
    //   schema.literal('index'),
    //   schema.literal('opensearch_dashboards'),
    // ]),

  });

  const roleMappingSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    backend_roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    hosts: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    users: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  });

  const roleSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    cluster_permissions: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    tenant_permissions: _configSchema.schema.arrayOf(_configSchema.schema.any(), {
      defaultValue: []
    }),
    index_permissions: _configSchema.schema.arrayOf(_configSchema.schema.any(), {
      defaultValue: []
    })
  });

  const tenantSchema = _configSchema.schema.object({
    description: _configSchema.schema.string()
  });

  const accountSchema = _configSchema.schema.object({
    password: _configSchema.schema.string(),
    current_password: _configSchema.schema.string()
  });

  const schemaMap = {
    internalusers: internalUserSchema,
    actiongroups: actionGroupSchema,
    rolesmapping: roleMappingSchema,
    roles: roleSchema,
    tenants: tenantSchema,
    account: accountSchema
  };

  function validateRequestBody(resourceName, requestBody) {
    const inputSchema = schemaMap[resourceName];

    if (!inputSchema) {
      throw new Error(`Unknown resource ${resourceName}`);
    }

    inputSchema.validate(requestBody); // throws error if validation fail
  }

  function validateEntityId(resourceName) {
    if (!(0, _common.isValidResourceName)(resourceName)) {
      return 'Invalid entity name or id.';
    }
  }
  /**
   * Lists resources by resource name.
   *
   * The response format is:
   * {
   *   "total": <total_entity_count>,
   *   "data": {
   *     "entity_id_1": { <entity_structure> },
   *     "entity_id_2": { <entity_structure> },
   *     ...
   *   }
   * }
   *
   * e.g. when listing internal users, response may look like:
   * {
   *   "total": 2,
   *   "data": {
   *     "api_test_user2": {
   *       "hash": "",
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "attributes": {},
   *       "description": "",
   *       "static": false
   *     },
   *     "api_test_user1": {
   *       "hash": "",
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "attributes": {},
   *       "static": false
   *     }
   * }
   *
   * when listing action groups, response will look like:
   * {
   *   "total": 2,
   *   "data": {
   *     "read": {
   *       "reserved": true,
   *       "hidden": false,
   *       "allowed_actions": ["indices:data/read*", "indices:admin/mappings/fields/get*"],
   *       "type": "index",
   *       "description": "Allow all read operations",
   *       "static": false
   *     },
   *     "cluster_all": {
   *       "reserved": true,
   *       "hidden": false,
   *       "allowed_actions": ["cluster:*"],
   *       "type": "cluster",
   *       "description": "Allow everything on cluster level",
   *       "static": false
   *     }
   * }
   *
   * role:
   * {
   *   "total": 2,
   *   "data": {
   *     "opensearch_dashboards_user": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Provide the minimum permissions for a opensearch_dashboards user",
   *       "cluster_permissions": ["cluster_composite_ops"],
   *       "index_permissions": [{
   *         "index_patterns": [".opensearch_dashboards", ".opensearch_dashboards-6", ".opensearch_dashboards_*"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["read", "delete", "manage", "index"]
   *       }, {
   *         "index_patterns": [".tasks", ".management-beats"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["indices_all"]
   *       }],
   *       "tenant_permissions": [],
   *       "static": false
   *     },
   *     "all_access": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Allow full access to all indices and all cluster APIs",
   *       "cluster_permissions": ["*"],
   *       "index_permissions": [{
   *         "index_patterns": ["*"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["*"]
   *       }],
   *       "tenant_permissions": [{
   *         "tenant_patterns": ["*"],
   *         "allowed_actions": ["opensearch_dashboards_all_write"]
   *       }],
   *       "static": false
   *     }
   *   }
   * }
   *
   * rolesmapping:
   * {
   *   "total": 2,
   *   "data": {
   *     "security_manager": {
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "hosts": [],
   *       "users": ["zengyan", "admin"],
   *       "and_backend_roles": []
   *     },
   *     "all_access": {
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "hosts": [],
   *       "users": ["zengyan", "admin", "indextest"],
   *       "and_backend_roles": []
   *     }
   *   }
   * }
   *
   * tenants:
   * {
   *   "total": 2,
   *   "data": {
   *     "global_tenant": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Global tenant",
   *       "static": false
   *     },
   *     "test tenant": {
   *       "reserved": false,
   *       "hidden": false,
   *       "description": "tenant description",
   *       "static": false
   *     }
   *   }
   * }
   */


  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.listResource', {
        resourceName: request.params.resourceName
      });
      return response.ok({
        body: {
          total: Object.keys(esResp).length,
          data: esResp
        }
      });
    } catch (error) {
      console.log(JSON.stringify(error));
      return errorResponse(response, error);
    }
  });
  /**
   * Gets entity by id.
   *
   * the response format differs from different resource types. e.g.
   *
   * for internal user, response will look like:
   * {
   *   "hash": "",
   *   "reserved": false,
   *   "hidden": false,
   *   "backend_roles": [],
   *   "attributes": {},
   *   "static": false
   * }
   *
   * for role, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Allow full access to all indices and all cluster APIs",
   *   "cluster_permissions": ["*"],
   *   "index_permissions": [{
   *     "index_patterns": ["*"],
   *     "fls": [],
   *     "masked_fields": [],
   *     "allowed_actions": ["*"]
   *   }],
   *   "tenant_permissions": [{
   *     "tenant_patterns": ["*"],
   *     "allowed_actions": ["opensearch_dashboards_all_write"]
   *   }],
   *   "static": false
   * }
   *
   * for roles mapping, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Allow full access to all indices and all cluster APIs",
   *   "cluster_permissions": ["*"],
   *   "index_permissions": [{
   *     "index_patterns": ["*"],
   *     "fls": [],
   *     "masked_fields": [],
   *     "allowed_actions": ["*"]
   *   }],
   *   "tenant_permissions": [{
   *     "tenant_patterns": ["*"],
   *     "allowed_actions": ["opensearch_dashboards_all_write"]
   *   }],
   *   "static": false
   * }
   *
   * for action groups, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "allowed_actions": ["indices:data/read*", "indices:admin/mappings/fields/get*"],
   *   "type": "index",
   *   "description": "Allow all read operations",
   *   "static": false
   * }
   *
   * for tenant, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Global tenant",
   *   "static": false
   * },
   */

  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.getResource', {
        resourceName: request.params.resourceName,
        id: request.params.id
      });
      return response.ok({
        body: esResp[request.params.id]
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Deletes an entity by id.
   */

  router.delete({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string({
          minLength: 1
        })
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.deleteResource', {
        resourceName: request.params.resourceName,
        id: request.params.id
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Update object with out Id. Resource identification is expected to computed from headers. Eg: auth headers
   *
   * Request sample:
   * /configuration/account
   * {
   *   "password": "new-password",
   *   "current_password": "old-password"
   * }
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string()
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      validateRequestBody(request.params.resourceName, request.body);
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }

    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.saveResourceWithoutId', {
        resourceName: request.params.resourceName,
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Update entity by Id.
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string({
          validate: validateEntityId
        })
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      validateRequestBody(request.params.resourceName, request.body);
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }

    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.saveResource', {
        resourceName: request.params.resourceName,
        id: request.params.id,
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets authentication info of the user.
   *
   * The response looks like:
   * {
   *   "user": "User [name=admin, roles=[], requestedTenant=__user__]",
   *   "user_name": "admin",
   *   "user_requested_tenant": "__user__",
   *   "remote_address": "127.0.0.1:35044",
   *   "backend_roles": [],
   *   "custom_attribute_names": [],
   *   "roles": ["all_access", "security_manager"],
   *   "tenants": {
   *     "another_tenant": true,
   *     "admin": true,
   *     "global_tenant": true,
   *     "aaaaa": true,
   *     "test tenant": true
   *   },
   *   "principal": null,
   *   "peer_certificates": "0",
   *   "sso_logout_url": null
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/auth/authinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.authinfo');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  router.get({
    path: `${_common.API_PREFIX}/auth/dashboardsinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.dashboardsinfo');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets audit log configuration。
   *
   * Sample payload:
   * {
   *   "enabled":true,
   *   "audit":{
   *     "enable_rest":false,
   *     "disabled_rest_categories":[
   *       "FAILED_LOGIN",
   *       "AUTHENTICATED"
   *     ],
   *     "enable_transport":true,
   *     "disabled_transport_categories":[
   *       "GRANTED_PRIVILEGES"
   *     ],
   *     "resolve_bulk_requests":true,
   *     "log_request_body":false,
   *     "resolve_indices":true,
   *     "exclude_sensitive_headers":true,
   *     "ignore_users":[
   *       "admin",
   *     ],
   *     "ignore_requests":[
   *       "SearchRequest",
   *       "indices:data/read/*"
   *     ]
   *   },
   *   "compliance":{
   *     "enabled":true,
   *     "internal_config":false,
   *     "external_config":false,
   *     "read_metadata_only":false,
   *     "read_watched_fields":{
   *       "indexName1":[
   *         "field1",
   *         "fields-*"
   *       ]
   *     },
   *     "read_ignore_users":[
   *       "opensearchdashboardsserver",
   *       "operator/*"
   *     ],
   *     "write_metadata_only":false,
   *     "write_log_diffs":false,
   *     "write_watched_indices":[
   *       "indexName2",
   *       "indexPatterns-*"
   *     ],
   *     "write_ignore_users":[
   *       "admin"
   *     ]
   *   }
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/configuration/audit`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.getAudit');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return response.custom({
        statusCode: error.statusCode,
        body: parseEsErrorResponse(error)
      });
    }
  });
  /**
   * Update audit log configuration。
   *
   * Sample payload:
   * {
   *   "enabled":true,
   *   "audit":{
   *     "enable_rest":false,
   *     "disabled_rest_categories":[
   *       "FAILED_LOGIN",
   *       "AUTHENTICATED"
   *     ],
   *     "enable_transport":true,
   *     "disabled_transport_categories":[
   *       "GRANTED_PRIVILEGES"
   *     ],
   *     "resolve_bulk_requests":true,
   *     "log_request_body":false,
   *     "resolve_indices":true,
   *     "exclude_sensitive_headers":true,
   *     "ignore_users":[
   *       "admin",
   *     ],
   *     "ignore_requests":[
   *       "SearchRequest",
   *       "indices:data/read/*"
   *     ]
   *   },
   *   "compliance":{
   *     "enabled":true,
   *     "internal_config":false,
   *     "external_config":false,
   *     "read_metadata_only":false,
   *     "read_watched_fields":{
   *       "indexName1":[
   *         "field1",
   *         "fields-*"
   *       ]
   *     },
   *     "read_ignore_users":[
   *       "kibanaserver",
   *       "operator/*"
   *     ],
   *     "write_metadata_only":false,
   *     "write_log_diffs":false,
   *     "write_watched_indices":[
   *       "indexName2",
   *       "indexPatterns-*"
   *     ],
   *     "write_ignore_users":[
   *       "admin"
   *     ]
   *   }
   * }
   */

  router.post({
    path: `${_common.API_PREFIX}/configuration/audit/config`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.saveAudit', {
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Deletes cache.
   *
   * Sample response: {"message":"Cache flushed successfully."}
   */

  router.delete({
    path: `${_common.API_PREFIX}/configuration/cache`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResponse;

    try {
      esResponse = await client.callAsCurrentUser('opensearch_security.clearCache');
      return response.ok({
        body: {
          message: esResponse.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets permission info of current user.
   *
   * Sample response:
   * {
   *   "user": "User [name=admin, roles=[], requestedTenant=__user__]",
   *   "user_name": "admin",
   *   "has_api_access": true,
   *   "disabled_endpoints": {}
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/restapiinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.restapiinfo');
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }
  });
  /**
   * Validates DLS (document level security) query.
   *
   * Request payload is an ES query.
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/validatedls/{indexName}`,
    validate: {
      params: _configSchema.schema.object({
        // in legacy plugin implmentation, indexName is not used when calling ES API.
        indexName: _configSchema.schema.maybe(_configSchema.schema.string())
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.validateDls', {
        body: request.body
      });
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets index mapping.
   *
   * Calling ES _mapping API under the hood. see
   * https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-get-mapping.html
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/index_mappings`,
    validate: {
      body: _configSchema.schema.object({
        index: _configSchema.schema.arrayOf(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.getIndexMappings', {
        index: request.body.index.join(','),
        ignore_unavailable: true,
        allow_no_indices: true
      });
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets all indices, and field mappings.
   *
   * Calls ES API '/_all/_mapping/field/*' under the hood. see
   * https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-get-mapping.html
   */

  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/indices`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.indices');
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
}

function parseEsErrorResponse(error) {
  if (error.response) {
    try {
      const esErrorResponse = JSON.parse(error.response);
      return esErrorResponse.reason || error.response;
    } catch (parsingError) {
      return error.response;
    }
  }

  return error.message;
}

function errorResponse(response, error) {
  return response.custom({
    statusCode: error.statusCode,
    body: parseEsErrorResponse(error)
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImludGVybmFsVXNlclNjaGVtYSIsInNjaGVtYSIsIm9iamVjdCIsImRlc2NyaXB0aW9uIiwibWF5YmUiLCJzdHJpbmciLCJwYXNzd29yZCIsImJhY2tlbmRfcm9sZXMiLCJhcnJheU9mIiwiZGVmYXVsdFZhbHVlIiwiYXR0cmlidXRlcyIsImFueSIsImFjdGlvbkdyb3VwU2NoZW1hIiwiYWxsb3dlZF9hY3Rpb25zIiwicm9sZU1hcHBpbmdTY2hlbWEiLCJob3N0cyIsInVzZXJzIiwicm9sZVNjaGVtYSIsImNsdXN0ZXJfcGVybWlzc2lvbnMiLCJ0ZW5hbnRfcGVybWlzc2lvbnMiLCJpbmRleF9wZXJtaXNzaW9ucyIsInRlbmFudFNjaGVtYSIsImFjY291bnRTY2hlbWEiLCJjdXJyZW50X3Bhc3N3b3JkIiwic2NoZW1hTWFwIiwiaW50ZXJuYWx1c2VycyIsImFjdGlvbmdyb3VwcyIsInJvbGVzbWFwcGluZyIsInJvbGVzIiwidGVuYW50cyIsImFjY291bnQiLCJ2YWxpZGF0ZVJlcXVlc3RCb2R5IiwicmVzb3VyY2VOYW1lIiwicmVxdWVzdEJvZHkiLCJpbnB1dFNjaGVtYSIsIkVycm9yIiwidmFsaWRhdGUiLCJ2YWxpZGF0ZUVudGl0eUlkIiwiZ2V0IiwicGF0aCIsIkFQSV9QUkVGSVgiLCJDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVgiLCJwYXJhbXMiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiY2xpZW50Iiwic2VjdXJpdHlfcGx1Z2luIiwiZXNDbGllbnQiLCJhc1Njb3BlZCIsImVzUmVzcCIsImNhbGxBc0N1cnJlbnRVc2VyIiwib2siLCJib2R5IiwidG90YWwiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImxvZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJlcnJvclJlc3BvbnNlIiwiaWQiLCJkZWxldGUiLCJtaW5MZW5ndGgiLCJtZXNzYWdlIiwicG9zdCIsImJhZFJlcXVlc3QiLCJjdXN0b20iLCJzdGF0dXNDb2RlIiwicGFyc2VFc0Vycm9yUmVzcG9uc2UiLCJlc1Jlc3BvbnNlIiwiaW5kZXhOYW1lIiwiaW5kZXgiLCJqb2luIiwiaWdub3JlX3VuYXZhaWxhYmxlIiwiYWxsb3dfbm9faW5kaWNlcyIsImVzRXJyb3JSZXNwb25zZSIsInBhcnNlIiwicmVhc29uIiwicGFyc2luZ0Vycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBT0E7O0FBdEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFXQTtBQUNPLFNBQVNBLFlBQVQsQ0FBc0JDLE1BQXRCLEVBQXVDO0FBQzVDLFFBQU1DLGtCQUFrQixHQUFHQyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3ZDQyxJQUFBQSxXQUFXLEVBQUVGLHFCQUFPRyxLQUFQLENBQWFILHFCQUFPSSxNQUFQLEVBQWIsQ0FEMEI7QUFFdkNDLElBQUFBLFFBQVEsRUFBRUwscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYixDQUY2QjtBQUd2Q0UsSUFBQUEsYUFBYSxFQUFFTixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLEVBQWdDO0FBQUVJLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFoQyxDQUh3QjtBQUl2Q0MsSUFBQUEsVUFBVSxFQUFFVCxxQkFBT1UsR0FBUCxDQUFXO0FBQUVGLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFYO0FBSjJCLEdBQWQsQ0FBM0I7O0FBT0EsUUFBTUcsaUJBQWlCLEdBQUdYLHFCQUFPQyxNQUFQLENBQWM7QUFDdENDLElBQUFBLFdBQVcsRUFBRUYscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYixDQUR5QjtBQUV0Q1EsSUFBQUEsZUFBZSxFQUFFWixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLENBRnFCLENBR3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFSc0MsR0FBZCxDQUExQjs7QUFXQSxRQUFNUyxpQkFBaUIsR0FBR2IscUJBQU9DLE1BQVAsQ0FBYztBQUN0Q0MsSUFBQUEsV0FBVyxFQUFFRixxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiLENBRHlCO0FBRXRDRSxJQUFBQSxhQUFhLEVBQUVOLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBRnVCO0FBR3RDTSxJQUFBQSxLQUFLLEVBQUVkLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBSCtCO0FBSXRDTyxJQUFBQSxLQUFLLEVBQUVmLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDO0FBSitCLEdBQWQsQ0FBMUI7O0FBT0EsUUFBTVEsVUFBVSxHQUFHaEIscUJBQU9DLE1BQVAsQ0FBYztBQUMvQkMsSUFBQUEsV0FBVyxFQUFFRixxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiLENBRGtCO0FBRS9CYSxJQUFBQSxtQkFBbUIsRUFBRWpCLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBRlU7QUFHL0JVLElBQUFBLGtCQUFrQixFQUFFbEIscUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9VLEdBQVAsRUFBZixFQUE2QjtBQUFFRixNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBN0IsQ0FIVztBQUkvQlcsSUFBQUEsaUJBQWlCLEVBQUVuQixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT1UsR0FBUCxFQUFmLEVBQTZCO0FBQUVGLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUE3QjtBQUpZLEdBQWQsQ0FBbkI7O0FBT0EsUUFBTVksWUFBWSxHQUFHcEIscUJBQU9DLE1BQVAsQ0FBYztBQUNqQ0MsSUFBQUEsV0FBVyxFQUFFRixxQkFBT0ksTUFBUDtBQURvQixHQUFkLENBQXJCOztBQUlBLFFBQU1pQixhQUFhLEdBQUdyQixxQkFBT0MsTUFBUCxDQUFjO0FBQ2xDSSxJQUFBQSxRQUFRLEVBQUVMLHFCQUFPSSxNQUFQLEVBRHdCO0FBRWxDa0IsSUFBQUEsZ0JBQWdCLEVBQUV0QixxQkFBT0ksTUFBUDtBQUZnQixHQUFkLENBQXRCOztBQUtBLFFBQU1tQixTQUFjLEdBQUc7QUFDckJDLElBQUFBLGFBQWEsRUFBRXpCLGtCQURNO0FBRXJCMEIsSUFBQUEsWUFBWSxFQUFFZCxpQkFGTztBQUdyQmUsSUFBQUEsWUFBWSxFQUFFYixpQkFITztBQUlyQmMsSUFBQUEsS0FBSyxFQUFFWCxVQUpjO0FBS3JCWSxJQUFBQSxPQUFPLEVBQUVSLFlBTFk7QUFNckJTLElBQUFBLE9BQU8sRUFBRVI7QUFOWSxHQUF2Qjs7QUFTQSxXQUFTUyxtQkFBVCxDQUE2QkMsWUFBN0IsRUFBbURDLFdBQW5ELEVBQTBFO0FBQ3hFLFVBQU1DLFdBQVcsR0FBR1YsU0FBUyxDQUFDUSxZQUFELENBQTdCOztBQUNBLFFBQUksQ0FBQ0UsV0FBTCxFQUFrQjtBQUNoQixZQUFNLElBQUlDLEtBQUosQ0FBVyxvQkFBbUJILFlBQWEsRUFBM0MsQ0FBTjtBQUNEOztBQUNERSxJQUFBQSxXQUFXLENBQUNFLFFBQVosQ0FBcUJILFdBQXJCLEVBTHdFLENBS3JDO0FBQ3BDOztBQUVELFdBQVNJLGdCQUFULENBQTBCTCxZQUExQixFQUFnRDtBQUM5QyxRQUFJLENBQUMsaUNBQW9CQSxZQUFwQixDQUFMLEVBQXdDO0FBQ3RDLGFBQU8sNEJBQVA7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VqQyxFQUFBQSxNQUFNLENBQUN1QyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixpQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI4QixRQUFBQSxZQUFZLEVBQUUvQixxQkFBT0ksTUFBUDtBQURNLE9BQWQ7QUFEQTtBQUZaLEdBREYsRUFTRSxPQUNFc0MsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixrQ0FBekIsRUFBNkQ7QUFDMUVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVjtBQUQ2QyxPQUE3RCxDQUFmO0FBR0EsYUFBT2EsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxLQUFLLEVBQUVDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZTixNQUFaLEVBQW9CTyxNQUR2QjtBQUVKQyxVQUFBQSxJQUFJLEVBQUVSO0FBRkY7QUFEVyxPQUFaLENBQVA7QUFNRCxLQVZELENBVUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2RDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUosS0FBZixDQUFaO0FBQ0EsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQTlCSDtBQWlDQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNFNUQsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsc0JBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVAsRUFETTtBQUVwQjRELFFBQUFBLEVBQUUsRUFBRWhFLHFCQUFPSSxNQUFQO0FBRmdCLE9BQWQ7QUFEQTtBQUZaLEdBREYsRUFVRSxPQUNFc0MsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixpQ0FBekIsRUFBNEQ7QUFDekVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUQ0QztBQUV6RWlDLFFBQUFBLEVBQUUsRUFBRXJCLE9BQU8sQ0FBQ0YsTUFBUixDQUFldUI7QUFGc0QsT0FBNUQsQ0FBZjtBQUlBLGFBQU9wQixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUFFQyxRQUFBQSxJQUFJLEVBQUVILE1BQU0sQ0FBQ04sT0FBTyxDQUFDRixNQUFSLENBQWV1QixFQUFoQjtBQUFkLE9BQVosQ0FBUDtBQUNELEtBTkQsQ0FNRSxPQUFPTixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBMUJIO0FBNkJBO0FBQ0Y7QUFDQTs7QUFDRTVELEVBQUFBLE1BQU0sQ0FBQ21FLE1BQVAsQ0FDRTtBQUNFM0IsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixzQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI4QixRQUFBQSxZQUFZLEVBQUUvQixxQkFBT0ksTUFBUCxFQURNO0FBRXBCNEQsUUFBQUEsRUFBRSxFQUFFaEUscUJBQU9JLE1BQVAsQ0FBYztBQUNoQjhELFVBQUFBLFNBQVMsRUFBRTtBQURLLFNBQWQ7QUFGZ0IsT0FBZDtBQURBO0FBRlosR0FERixFQVlFLE9BQ0V4QixPQURGLEVBRUVDLE9BRkYsRUFHRUMsUUFIRixLQUlrRTtBQUNoRSxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLG9DQUF6QixFQUErRDtBQUM1RW5CLFFBQUFBLFlBQVksRUFBRVksT0FBTyxDQUFDRixNQUFSLENBQWVWLFlBRCtDO0FBRTVFaUMsUUFBQUEsRUFBRSxFQUFFckIsT0FBTyxDQUFDRixNQUFSLENBQWV1QjtBQUZ5RCxPQUEvRCxDQUFmO0FBSUEsYUFBT3BCLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUU7QUFDSmUsVUFBQUEsT0FBTyxFQUFFbEIsTUFBTSxDQUFDa0I7QUFEWjtBQURXLE9BQVosQ0FBUDtBQUtELEtBVkQsQ0FVRSxPQUFPVCxLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBaENIO0FBbUNBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNFNUQsRUFBQUEsTUFBTSxDQUFDc0UsSUFBUCxDQUNFO0FBQ0U5QixJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsSUFBR0MsZ0NBQXlCLGlCQURsRDtBQUVFTCxJQUFBQSxRQUFRLEVBQUU7QUFDUk0sTUFBQUEsTUFBTSxFQUFFekMscUJBQU9DLE1BQVAsQ0FBYztBQUNwQjhCLFFBQUFBLFlBQVksRUFBRS9CLHFCQUFPSSxNQUFQO0FBRE0sT0FBZCxDQURBO0FBSVJnRCxNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT1UsR0FBUDtBQUpFO0FBRlosR0FERixFQVVFLE9BQ0VnQyxPQURGLEVBRUVDLE9BRkYsRUFHRUMsUUFIRixLQUlrRTtBQUNoRSxRQUFJO0FBQ0ZkLE1BQUFBLG1CQUFtQixDQUFDYSxPQUFPLENBQUNGLE1BQVIsQ0FBZVYsWUFBaEIsRUFBOEJZLE9BQU8sQ0FBQ1MsSUFBdEMsQ0FBbkI7QUFDRCxLQUZELENBRUUsT0FBT00sS0FBUCxFQUFjO0FBQ2QsYUFBT2QsUUFBUSxDQUFDeUIsVUFBVCxDQUFvQjtBQUFFakIsUUFBQUEsSUFBSSxFQUFFTTtBQUFSLE9BQXBCLENBQVA7QUFDRDs7QUFDRCxVQUFNYixNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLDJDQUF6QixFQUFzRTtBQUNuRm5CLFFBQUFBLFlBQVksRUFBRVksT0FBTyxDQUFDRixNQUFSLENBQWVWLFlBRHNEO0FBRW5GcUIsUUFBQUEsSUFBSSxFQUFFVCxPQUFPLENBQUNTO0FBRnFFLE9BQXRFLENBQWY7QUFJQSxhQUFPUixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0plLFVBQUFBLE9BQU8sRUFBRWxCLE1BQU0sQ0FBQ2tCO0FBRFo7QUFEVyxPQUFaLENBQVA7QUFLRCxLQVZELENBVUUsT0FBT1QsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQW5DSDtBQXNDQTtBQUNGO0FBQ0E7O0FBQ0U1RCxFQUFBQSxNQUFNLENBQUNzRSxJQUFQLENBQ0U7QUFDRTlCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsc0JBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVAsRUFETTtBQUVwQjRELFFBQUFBLEVBQUUsRUFBRWhFLHFCQUFPSSxNQUFQLENBQWM7QUFDaEIrQixVQUFBQSxRQUFRLEVBQUVDO0FBRE0sU0FBZDtBQUZnQixPQUFkLENBREE7QUFPUmdCLE1BQUFBLElBQUksRUFBRXBELHFCQUFPVSxHQUFQO0FBUEU7QUFGWixHQURGLEVBYUUsT0FDRWdDLE9BREYsRUFFRUMsT0FGRixFQUdFQyxRQUhGLEtBSWtFO0FBQ2hFLFFBQUk7QUFDRmQsTUFBQUEsbUJBQW1CLENBQUNhLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUFoQixFQUE4QlksT0FBTyxDQUFDUyxJQUF0QyxDQUFuQjtBQUNELEtBRkQsQ0FFRSxPQUFPTSxLQUFQLEVBQWM7QUFDZCxhQUFPZCxRQUFRLENBQUN5QixVQUFULENBQW9CO0FBQUVqQixRQUFBQSxJQUFJLEVBQUVNO0FBQVIsT0FBcEIsQ0FBUDtBQUNEOztBQUNELFVBQU1iLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsTUFBTSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsa0NBQXpCLEVBQTZEO0FBQzFFbkIsUUFBQUEsWUFBWSxFQUFFWSxPQUFPLENBQUNGLE1BQVIsQ0FBZVYsWUFENkM7QUFFMUVpQyxRQUFBQSxFQUFFLEVBQUVyQixPQUFPLENBQUNGLE1BQVIsQ0FBZXVCLEVBRnVEO0FBRzFFWixRQUFBQSxJQUFJLEVBQUVULE9BQU8sQ0FBQ1M7QUFINEQsT0FBN0QsQ0FBZjtBQUtBLGFBQU9SLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUU7QUFDSmUsVUFBQUEsT0FBTyxFQUFFbEIsTUFBTSxDQUFDa0I7QUFEWjtBQURXLE9BQVosQ0FBUDtBQUtELEtBWEQsQ0FXRSxPQUFPVCxLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBdkNIO0FBMENBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRTVELEVBQUFBLE1BQU0sQ0FBQ3VDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsZ0JBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUNFTyxPQURGLEVBRUVDLE9BRkYsRUFHRUMsUUFIRixLQUlrRTtBQUNoRSxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLDhCQUF6QixDQUFmO0FBRUEsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRUg7QUFEVyxPQUFaLENBQVA7QUFHRCxLQU5ELENBTUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQXJCSDtBQXdCQTVELEVBQUFBLE1BQU0sQ0FBQ3VDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsc0JBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUNFTyxPQURGLEVBRUVDLE9BRkYsRUFHRUMsUUFIRixLQUlrRTtBQUNoRSxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLG9DQUF6QixDQUFmO0FBRUEsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRUg7QUFEVyxPQUFaLENBQVA7QUFHRCxLQU5ELENBTUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQXJCSDtBQXdCQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRTVELEVBQUFBLE1BQU0sQ0FBQ3VDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsc0JBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUNFTyxPQURGLEVBRUVDLE9BRkYsRUFHRUMsUUFIRixLQUlrRTtBQUNoRSxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBRUEsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLDhCQUF6QixDQUFmO0FBRUEsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRUg7QUFEVyxPQUFaLENBQVA7QUFHRCxLQU5ELENBTUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2QsYUFBT2QsUUFBUSxDQUFDMEIsTUFBVCxDQUFnQjtBQUNyQkMsUUFBQUEsVUFBVSxFQUFFYixLQUFLLENBQUNhLFVBREc7QUFFckJuQixRQUFBQSxJQUFJLEVBQUVvQixvQkFBb0IsQ0FBQ2QsS0FBRDtBQUZMLE9BQWhCLENBQVA7QUFJRDtBQUNGLEdBekJIO0FBNEJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNFNUQsRUFBQUEsTUFBTSxDQUFDc0UsSUFBUCxDQUNFO0FBQ0U5QixJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsNkJBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUNSaUIsTUFBQUEsSUFBSSxFQUFFcEQscUJBQU9VLEdBQVA7QUFERTtBQUZaLEdBREYsRUFPRSxPQUFPZ0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsTUFBTSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsK0JBQXpCLEVBQTBEO0FBQ3ZFRSxRQUFBQSxJQUFJLEVBQUVULE9BQU8sQ0FBQ1M7QUFEeUQsT0FBMUQsQ0FBZjtBQUdBLGFBQU9SLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUU7QUFDSmUsVUFBQUEsT0FBTyxFQUFFbEIsTUFBTSxDQUFDa0I7QUFEWjtBQURXLE9BQVosQ0FBUDtBQUtELEtBVEQsQ0FTRSxPQUFPVCxLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBdEJIO0FBeUJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7O0FBQ0U1RCxFQUFBQSxNQUFNLENBQUNtRSxNQUFQLENBQ0U7QUFDRTNCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxzQkFEdEI7QUFFRUosSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLE9BQU9PLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSThCLFVBQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxVQUFVLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsZ0NBQXpCLENBQW5CO0FBQ0EsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUVNLFVBQVUsQ0FBQ047QUFEaEI7QUFEVyxPQUFaLENBQVA7QUFLRCxLQVBELENBT0UsT0FBT1QsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQWxCSDtBQXFCQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNFNUQsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxjQUR0QjtBQUVFSixJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT08sT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7O0FBQ0EsUUFBSTtBQUNGLFlBQU04QixVQUFVLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsaUNBQXpCLENBQXpCO0FBQ0EsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRXFCO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FMRCxDQUtFLE9BQU9mLEtBQVAsRUFBYztBQUNkLGFBQU9kLFFBQVEsQ0FBQ3lCLFVBQVQsQ0FBb0I7QUFDekJqQixRQUFBQSxJQUFJLEVBQUVNO0FBRG1CLE9BQXBCLENBQVA7QUFHRDtBQUNGLEdBakJIO0FBb0JBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7O0FBQ0U1RCxFQUFBQSxNQUFNLENBQUNzRSxJQUFQLENBQ0U7QUFDRTlCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsMEJBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCO0FBQ0F5RSxRQUFBQSxTQUFTLEVBQUUxRSxxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiO0FBRlMsT0FBZCxDQURBO0FBS1JnRCxNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT1UsR0FBUDtBQUxFO0FBRlosR0FERixFQVdFLE9BQU9nQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjs7QUFDQSxRQUFJO0FBQ0YsWUFBTThCLFVBQVUsR0FBRyxNQUFNNUIsTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixpQ0FBekIsRUFBNEQ7QUFDbkZFLFFBQUFBLElBQUksRUFBRVQsT0FBTyxDQUFDUztBQURxRSxPQUE1RCxDQUF6QjtBQUdBLGFBQU9SLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVxQjtBQURXLE9BQVosQ0FBUDtBQUdELEtBUEQsQ0FPRSxPQUFPZixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBdkJIO0FBMEJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRTVELEVBQUFBLE1BQU0sQ0FBQ3NFLElBQVAsQ0FDRTtBQUNFOUIsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixpQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JpQixNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT0MsTUFBUCxDQUFjO0FBQ2xCMEUsUUFBQUEsS0FBSyxFQUFFM0UscUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9JLE1BQVAsRUFBZjtBQURXLE9BQWQ7QUFERTtBQUZaLEdBREYsRUFTRSxPQUFPc0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7O0FBQ0EsUUFBSTtBQUNGLFlBQU04QixVQUFVLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsc0NBQXpCLEVBQWlFO0FBQ3hGeUIsUUFBQUEsS0FBSyxFQUFFaEMsT0FBTyxDQUFDUyxJQUFSLENBQWF1QixLQUFiLENBQW1CQyxJQUFuQixDQUF3QixHQUF4QixDQURpRjtBQUV4RkMsUUFBQUEsa0JBQWtCLEVBQUUsSUFGb0U7QUFHeEZDLFFBQUFBLGdCQUFnQixFQUFFO0FBSHNFLE9BQWpFLENBQXpCO0FBTUEsYUFBT2xDLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVxQjtBQURXLE9BQVosQ0FBUDtBQUdELEtBVkQsQ0FVRSxPQUFPZixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBeEJIO0FBMkJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRTVELEVBQUFBLE1BQU0sQ0FBQ3VDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsSUFBR0MsZ0NBQXlCLFVBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUFPTyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjs7QUFDQSxRQUFJO0FBQ0YsWUFBTThCLFVBQVUsR0FBRyxNQUFNNUIsTUFBTSxDQUFDSyxpQkFBUCxDQUF5Qiw2QkFBekIsQ0FBekI7QUFDQSxhQUFPTixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFcUI7QUFEVyxPQUFaLENBQVA7QUFHRCxLQUxELENBS0UsT0FBT2YsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQWZIO0FBaUJEOztBQUVELFNBQVNjLG9CQUFULENBQThCZCxLQUE5QixFQUEwQztBQUN4QyxNQUFJQSxLQUFLLENBQUNkLFFBQVYsRUFBb0I7QUFDbEIsUUFBSTtBQUNGLFlBQU1tQyxlQUFlLEdBQUdsQixJQUFJLENBQUNtQixLQUFMLENBQVd0QixLQUFLLENBQUNkLFFBQWpCLENBQXhCO0FBQ0EsYUFBT21DLGVBQWUsQ0FBQ0UsTUFBaEIsSUFBMEJ2QixLQUFLLENBQUNkLFFBQXZDO0FBQ0QsS0FIRCxDQUdFLE9BQU9zQyxZQUFQLEVBQXFCO0FBQ3JCLGFBQU94QixLQUFLLENBQUNkLFFBQWI7QUFDRDtBQUNGOztBQUNELFNBQU9jLEtBQUssQ0FBQ1MsT0FBYjtBQUNEOztBQUVELFNBQVNKLGFBQVQsQ0FBdUJuQixRQUF2QixFQUFzRWMsS0FBdEUsRUFBa0Y7QUFDaEYsU0FBT2QsUUFBUSxDQUFDMEIsTUFBVCxDQUFnQjtBQUNyQkMsSUFBQUEsVUFBVSxFQUFFYixLQUFLLENBQUNhLFVBREc7QUFFckJuQixJQUFBQSxJQUFJLEVBQUVvQixvQkFBb0IsQ0FBQ2QsS0FBRDtBQUZMLEdBQWhCLENBQVA7QUFJRCIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqICAgQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXHJcbiAqXHJcbiAqICAgTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKS5cclxuICogICBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXHJcbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcclxuICpcclxuICogICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXHJcbiAqXHJcbiAqICAgb3IgaW4gdGhlIFwibGljZW5zZVwiIGZpbGUgYWNjb21wYW55aW5nIHRoaXMgZmlsZS4gVGhpcyBmaWxlIGlzIGRpc3RyaWJ1dGVkXHJcbiAqICAgb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXHJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcclxuICogICBwZXJtaXNzaW9ucyBhbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcclxuaW1wb3J0IHtcclxuICBJUm91dGVyLFxyXG4gIFJlc3BvbnNlRXJyb3IsXHJcbiAgSU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2UsXHJcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXHJcbn0gZnJvbSAnb3BlbnNlYXJjaC1kYXNoYm9hcmRzL3NlcnZlcic7XHJcbmltcG9ydCB7IEFQSV9QUkVGSVgsIENPTkZJR1VSQVRJT05fQVBJX1BSRUZJWCwgaXNWYWxpZFJlc291cmNlTmFtZSB9IGZyb20gJy4uLy4uL2NvbW1vbic7XHJcblxyXG4vLyBUT0RPOiBjb25zaWRlciB0byBleHRyYWN0IGVudGl0eSBDUlVEIG9wZXJhdGlvbnMgYW5kIHB1dCBpdCBpbnRvIGEgY2xpZW50IGNsYXNzXHJcbmV4cG9ydCBmdW5jdGlvbiBkZWZpbmVSb3V0ZXMocm91dGVyOiBJUm91dGVyKSB7XHJcbiAgY29uc3QgaW50ZXJuYWxVc2VyU2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XHJcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICBwYXNzd29yZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICBiYWNrZW5kX3JvbGVzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcclxuICAgIGF0dHJpYnV0ZXM6IHNjaGVtYS5hbnkoeyBkZWZhdWx0VmFsdWU6IHt9IH0pLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBhY3Rpb25Hcm91cFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxyXG4gICAgYWxsb3dlZF9hY3Rpb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpLFxyXG4gICAgLy8gdHlwZSBmaWVsZCBpcyBub3Qgc3VwcG9ydGVkIGluIGxlZ2FjeSBpbXBsZW1lbnRhdGlvbiwgY29tbWVudCBpdCBvdXQgZm9yIG5vdy5cclxuICAgIC8vIHR5cGU6IHNjaGVtYS5vbmVPZihbXHJcbiAgICAvLyAgIHNjaGVtYS5saXRlcmFsKCdjbHVzdGVyJyksXHJcbiAgICAvLyAgIHNjaGVtYS5saXRlcmFsKCdpbmRleCcpLFxyXG4gICAgLy8gICBzY2hlbWEubGl0ZXJhbCgnb3BlbnNlYXJjaF9kYXNoYm9hcmRzJyksXHJcbiAgICAvLyBdKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgcm9sZU1hcHBpbmdTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcclxuICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcclxuICAgIGJhY2tlbmRfcm9sZXM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxyXG4gICAgaG9zdHM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxyXG4gICAgdXNlcnM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByb2xlU2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XHJcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICBjbHVzdGVyX3Blcm1pc3Npb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcclxuICAgIHRlbmFudF9wZXJtaXNzaW9uczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLmFueSgpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgICBpbmRleF9wZXJtaXNzaW9uczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLmFueSgpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHRlbmFudFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5zdHJpbmcoKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYWNjb3VudFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgcGFzc3dvcmQ6IHNjaGVtYS5zdHJpbmcoKSxcclxuICAgIGN1cnJlbnRfcGFzc3dvcmQ6IHNjaGVtYS5zdHJpbmcoKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2NoZW1hTWFwOiBhbnkgPSB7XHJcbiAgICBpbnRlcm5hbHVzZXJzOiBpbnRlcm5hbFVzZXJTY2hlbWEsXHJcbiAgICBhY3Rpb25ncm91cHM6IGFjdGlvbkdyb3VwU2NoZW1hLFxyXG4gICAgcm9sZXNtYXBwaW5nOiByb2xlTWFwcGluZ1NjaGVtYSxcclxuICAgIHJvbGVzOiByb2xlU2NoZW1hLFxyXG4gICAgdGVuYW50czogdGVuYW50U2NoZW1hLFxyXG4gICAgYWNjb3VudDogYWNjb3VudFNjaGVtYSxcclxuICB9O1xyXG5cclxuICBmdW5jdGlvbiB2YWxpZGF0ZVJlcXVlc3RCb2R5KHJlc291cmNlTmFtZTogc3RyaW5nLCByZXF1ZXN0Qm9keTogYW55KTogYW55IHtcclxuICAgIGNvbnN0IGlucHV0U2NoZW1hID0gc2NoZW1hTWFwW3Jlc291cmNlTmFtZV07XHJcbiAgICBpZiAoIWlucHV0U2NoZW1hKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biByZXNvdXJjZSAke3Jlc291cmNlTmFtZX1gKTtcclxuICAgIH1cclxuICAgIGlucHV0U2NoZW1hLnZhbGlkYXRlKHJlcXVlc3RCb2R5KTsgLy8gdGhyb3dzIGVycm9yIGlmIHZhbGlkYXRpb24gZmFpbFxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gdmFsaWRhdGVFbnRpdHlJZChyZXNvdXJjZU5hbWU6IHN0cmluZykge1xyXG4gICAgaWYgKCFpc1ZhbGlkUmVzb3VyY2VOYW1lKHJlc291cmNlTmFtZSkpIHtcclxuICAgICAgcmV0dXJuICdJbnZhbGlkIGVudGl0eSBuYW1lIG9yIGlkLic7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBMaXN0cyByZXNvdXJjZXMgYnkgcmVzb3VyY2UgbmFtZS5cclxuICAgKlxyXG4gICAqIFRoZSByZXNwb25zZSBmb3JtYXQgaXM6XHJcbiAgICoge1xyXG4gICAqICAgXCJ0b3RhbFwiOiA8dG90YWxfZW50aXR5X2NvdW50PixcclxuICAgKiAgIFwiZGF0YVwiOiB7XHJcbiAgICogICAgIFwiZW50aXR5X2lkXzFcIjogeyA8ZW50aXR5X3N0cnVjdHVyZT4gfSxcclxuICAgKiAgICAgXCJlbnRpdHlfaWRfMlwiOiB7IDxlbnRpdHlfc3RydWN0dXJlPiB9LFxyXG4gICAqICAgICAuLi5cclxuICAgKiAgIH1cclxuICAgKiB9XHJcbiAgICpcclxuICAgKiBlLmcuIHdoZW4gbGlzdGluZyBpbnRlcm5hbCB1c2VycywgcmVzcG9uc2UgbWF5IGxvb2sgbGlrZTpcclxuICAgKiB7XHJcbiAgICogICBcInRvdGFsXCI6IDIsXHJcbiAgICogICBcImRhdGFcIjoge1xyXG4gICAqICAgICBcImFwaV90ZXN0X3VzZXIyXCI6IHtcclxuICAgKiAgICAgICBcImhhc2hcIjogXCJcIixcclxuICAgKiAgICAgICBcInJlc2VydmVkXCI6IGZhbHNlLFxyXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxyXG4gICAqICAgICAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcclxuICAgKiAgICAgICBcImF0dHJpYnV0ZXNcIjoge30sXHJcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlwiLFxyXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXHJcbiAgICogICAgIH0sXHJcbiAgICogICAgIFwiYXBpX3Rlc3RfdXNlcjFcIjoge1xyXG4gICAqICAgICAgIFwiaGFzaFwiOiBcIlwiLFxyXG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXHJcbiAgICogICAgICAgXCJoaWRkZW5cIjogZmFsc2UsXHJcbiAgICogICAgICAgXCJiYWNrZW5kX3JvbGVzXCI6IFtdLFxyXG4gICAqICAgICAgIFwiYXR0cmlidXRlc1wiOiB7fSxcclxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxyXG4gICAqICAgICB9XHJcbiAgICogfVxyXG4gICAqXHJcbiAgICogd2hlbiBsaXN0aW5nIGFjdGlvbiBncm91cHMsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxyXG4gICAqIHtcclxuICAgKiAgIFwidG90YWxcIjogMixcclxuICAgKiAgIFwiZGF0YVwiOiB7XHJcbiAgICogICAgIFwicmVhZFwiOiB7XHJcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxyXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxyXG4gICAqICAgICAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcImluZGljZXM6ZGF0YS9yZWFkKlwiLCBcImluZGljZXM6YWRtaW4vbWFwcGluZ3MvZmllbGRzL2dldCpcIl0sXHJcbiAgICogICAgICAgXCJ0eXBlXCI6IFwiaW5kZXhcIixcclxuICAgKiAgICAgICBcImRlc2NyaXB0aW9uXCI6IFwiQWxsb3cgYWxsIHJlYWQgb3BlcmF0aW9uc1wiLFxyXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXHJcbiAgICogICAgIH0sXHJcbiAgICogICAgIFwiY2x1c3Rlcl9hbGxcIjoge1xyXG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogdHJ1ZSxcclxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImFsbG93ZWRfYWN0aW9uc1wiOiBbXCJjbHVzdGVyOipcIl0sXHJcbiAgICogICAgICAgXCJ0eXBlXCI6IFwiY2x1c3RlclwiLFxyXG4gICAqICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBldmVyeXRoaW5nIG9uIGNsdXN0ZXIgbGV2ZWxcIixcclxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxyXG4gICAqICAgICB9XHJcbiAgICogfVxyXG4gICAqXHJcbiAgICogcm9sZTpcclxuICAgKiB7XHJcbiAgICogICBcInRvdGFsXCI6IDIsXHJcbiAgICogICBcImRhdGFcIjoge1xyXG4gICAqICAgICBcIm9wZW5zZWFyY2hfZGFzaGJvYXJkc191c2VyXCI6IHtcclxuICAgKiAgICAgICBcInJlc2VydmVkXCI6IHRydWUsXHJcbiAgICogICAgICAgXCJoaWRkZW5cIjogZmFsc2UsXHJcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlByb3ZpZGUgdGhlIG1pbmltdW0gcGVybWlzc2lvbnMgZm9yIGEgb3BlbnNlYXJjaF9kYXNoYm9hcmRzIHVzZXJcIixcclxuICAgKiAgICAgICBcImNsdXN0ZXJfcGVybWlzc2lvbnNcIjogW1wiY2x1c3Rlcl9jb21wb3NpdGVfb3BzXCJdLFxyXG4gICAqICAgICAgIFwiaW5kZXhfcGVybWlzc2lvbnNcIjogW3tcclxuICAgKiAgICAgICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiLm9wZW5zZWFyY2hfZGFzaGJvYXJkc1wiLCBcIi5vcGVuc2VhcmNoX2Rhc2hib2FyZHMtNlwiLCBcIi5vcGVuc2VhcmNoX2Rhc2hib2FyZHNfKlwiXSxcclxuICAgKiAgICAgICAgIFwiZmxzXCI6IFtdLFxyXG4gICAqICAgICAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxyXG4gICAqICAgICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wicmVhZFwiLCBcImRlbGV0ZVwiLCBcIm1hbmFnZVwiLCBcImluZGV4XCJdXHJcbiAgICogICAgICAgfSwge1xyXG4gICAqICAgICAgICAgXCJpbmRleF9wYXR0ZXJuc1wiOiBbXCIudGFza3NcIiwgXCIubWFuYWdlbWVudC1iZWF0c1wiXSxcclxuICAgKiAgICAgICAgIFwiZmxzXCI6IFtdLFxyXG4gICAqICAgICAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxyXG4gICAqICAgICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiaW5kaWNlc19hbGxcIl1cclxuICAgKiAgICAgICB9XSxcclxuICAgKiAgICAgICBcInRlbmFudF9wZXJtaXNzaW9uc1wiOiBbXSxcclxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxyXG4gICAqICAgICB9LFxyXG4gICAqICAgICBcImFsbF9hY2Nlc3NcIjoge1xyXG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogdHJ1ZSxcclxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImRlc2NyaXB0aW9uXCI6IFwiQWxsb3cgZnVsbCBhY2Nlc3MgdG8gYWxsIGluZGljZXMgYW5kIGFsbCBjbHVzdGVyIEFQSXNcIixcclxuICAgKiAgICAgICBcImNsdXN0ZXJfcGVybWlzc2lvbnNcIjogW1wiKlwiXSxcclxuICAgKiAgICAgICBcImluZGV4X3Blcm1pc3Npb25zXCI6IFt7XHJcbiAgICogICAgICAgICBcImluZGV4X3BhdHRlcm5zXCI6IFtcIipcIl0sXHJcbiAgICogICAgICAgICBcImZsc1wiOiBbXSxcclxuICAgKiAgICAgICAgIFwibWFza2VkX2ZpZWxkc1wiOiBbXSxcclxuICAgKiAgICAgICAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcIipcIl1cclxuICAgKiAgICAgICB9XSxcclxuICAgKiAgICAgICBcInRlbmFudF9wZXJtaXNzaW9uc1wiOiBbe1xyXG4gICAqICAgICAgICAgXCJ0ZW5hbnRfcGF0dGVybnNcIjogW1wiKlwiXSxcclxuICAgKiAgICAgICAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcIm9wZW5zZWFyY2hfZGFzaGJvYXJkc19hbGxfd3JpdGVcIl1cclxuICAgKiAgICAgICB9XSxcclxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxyXG4gICAqICAgICB9XHJcbiAgICogICB9XHJcbiAgICogfVxyXG4gICAqXHJcbiAgICogcm9sZXNtYXBwaW5nOlxyXG4gICAqIHtcclxuICAgKiAgIFwidG90YWxcIjogMixcclxuICAgKiAgIFwiZGF0YVwiOiB7XHJcbiAgICogICAgIFwic2VjdXJpdHlfbWFuYWdlclwiOiB7XHJcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImJhY2tlbmRfcm9sZXNcIjogW10sXHJcbiAgICogICAgICAgXCJob3N0c1wiOiBbXSxcclxuICAgKiAgICAgICBcInVzZXJzXCI6IFtcInplbmd5YW5cIiwgXCJhZG1pblwiXSxcclxuICAgKiAgICAgICBcImFuZF9iYWNrZW5kX3JvbGVzXCI6IFtdXHJcbiAgICogICAgIH0sXHJcbiAgICogICAgIFwiYWxsX2FjY2Vzc1wiOiB7XHJcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImJhY2tlbmRfcm9sZXNcIjogW10sXHJcbiAgICogICAgICAgXCJob3N0c1wiOiBbXSxcclxuICAgKiAgICAgICBcInVzZXJzXCI6IFtcInplbmd5YW5cIiwgXCJhZG1pblwiLCBcImluZGV4dGVzdFwiXSxcclxuICAgKiAgICAgICBcImFuZF9iYWNrZW5kX3JvbGVzXCI6IFtdXHJcbiAgICogICAgIH1cclxuICAgKiAgIH1cclxuICAgKiB9XHJcbiAgICpcclxuICAgKiB0ZW5hbnRzOlxyXG4gICAqIHtcclxuICAgKiAgIFwidG90YWxcIjogMixcclxuICAgKiAgIFwiZGF0YVwiOiB7XHJcbiAgICogICAgIFwiZ2xvYmFsX3RlbmFudFwiOiB7XHJcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxyXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxyXG4gICAqICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJHbG9iYWwgdGVuYW50XCIsXHJcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcclxuICAgKiAgICAgfSxcclxuICAgKiAgICAgXCJ0ZXN0IHRlbmFudFwiOiB7XHJcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgICAgICBcImRlc2NyaXB0aW9uXCI6IFwidGVuYW50IGRlc2NyaXB0aW9uXCIsXHJcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcclxuICAgKiAgICAgfVxyXG4gICAqICAgfVxyXG4gICAqIH1cclxuICAgKi9cclxuICByb3V0ZXIuZ2V0KFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX1gLFxyXG4gICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBhc3luYyAoXHJcbiAgICAgIGNvbnRleHQsXHJcbiAgICAgIHJlcXVlc3QsXHJcbiAgICAgIHJlc3BvbnNlXHJcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XHJcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xyXG4gICAgICBsZXQgZXNSZXNwO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGVzUmVzcCA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbnNlYXJjaF9zZWN1cml0eS5saXN0UmVzb3VyY2UnLCB7XHJcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICB0b3RhbDogT2JqZWN0LmtleXMoZXNSZXNwKS5sZW5ndGgsXHJcbiAgICAgICAgICAgIGRhdGE6IGVzUmVzcCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTtcclxuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyBlbnRpdHkgYnkgaWQuXHJcbiAgICpcclxuICAgKiB0aGUgcmVzcG9uc2UgZm9ybWF0IGRpZmZlcnMgZnJvbSBkaWZmZXJlbnQgcmVzb3VyY2UgdHlwZXMuIGUuZy5cclxuICAgKlxyXG4gICAqIGZvciBpbnRlcm5hbCB1c2VyLCByZXNwb25zZSB3aWxsIGxvb2sgbGlrZTpcclxuICAgKiB7XHJcbiAgICogICBcImhhc2hcIjogXCJcIixcclxuICAgKiAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXHJcbiAgICogICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcclxuICAgKiAgIFwiYXR0cmlidXRlc1wiOiB7fSxcclxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXHJcbiAgICogfVxyXG4gICAqXHJcbiAgICogZm9yIHJvbGUsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxyXG4gICAqIHtcclxuICAgKiAgIFwicmVzZXJ2ZWRcIjogdHJ1ZSxcclxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxyXG4gICAqICAgXCJkZXNjcmlwdGlvblwiOiBcIkFsbG93IGZ1bGwgYWNjZXNzIHRvIGFsbCBpbmRpY2VzIGFuZCBhbGwgY2x1c3RlciBBUElzXCIsXHJcbiAgICogICBcImNsdXN0ZXJfcGVybWlzc2lvbnNcIjogW1wiKlwiXSxcclxuICAgKiAgIFwiaW5kZXhfcGVybWlzc2lvbnNcIjogW3tcclxuICAgKiAgICAgXCJpbmRleF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxyXG4gICAqICAgICBcImZsc1wiOiBbXSxcclxuICAgKiAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxyXG4gICAqICAgICBcImFsbG93ZWRfYWN0aW9uc1wiOiBbXCIqXCJdXHJcbiAgICogICB9XSxcclxuICAgKiAgIFwidGVuYW50X3Blcm1pc3Npb25zXCI6IFt7XHJcbiAgICogICAgIFwidGVuYW50X3BhdHRlcm5zXCI6IFtcIipcIl0sXHJcbiAgICogICAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcIm9wZW5zZWFyY2hfZGFzaGJvYXJkc19hbGxfd3JpdGVcIl1cclxuICAgKiAgIH1dLFxyXG4gICAqICAgXCJzdGF0aWNcIjogZmFsc2VcclxuICAgKiB9XHJcbiAgICpcclxuICAgKiBmb3Igcm9sZXMgbWFwcGluZywgcmVzcG9uc2Ugd2lsbCBsb29rIGxpa2U6XHJcbiAgICoge1xyXG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxyXG4gICAqICAgXCJoaWRkZW5cIjogZmFsc2UsXHJcbiAgICogICBcImRlc2NyaXB0aW9uXCI6IFwiQWxsb3cgZnVsbCBhY2Nlc3MgdG8gYWxsIGluZGljZXMgYW5kIGFsbCBjbHVzdGVyIEFQSXNcIixcclxuICAgKiAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxyXG4gICAqICAgXCJpbmRleF9wZXJtaXNzaW9uc1wiOiBbe1xyXG4gICAqICAgICBcImluZGV4X3BhdHRlcm5zXCI6IFtcIipcIl0sXHJcbiAgICogICAgIFwiZmxzXCI6IFtdLFxyXG4gICAqICAgICBcIm1hc2tlZF9maWVsZHNcIjogW10sXHJcbiAgICogICAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcIipcIl1cclxuICAgKiAgIH1dLFxyXG4gICAqICAgXCJ0ZW5hbnRfcGVybWlzc2lvbnNcIjogW3tcclxuICAgKiAgICAgXCJ0ZW5hbnRfcGF0dGVybnNcIjogW1wiKlwiXSxcclxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wib3BlbnNlYXJjaF9kYXNoYm9hcmRzX2FsbF93cml0ZVwiXVxyXG4gICAqICAgfV0sXHJcbiAgICogICBcInN0YXRpY1wiOiBmYWxzZVxyXG4gICAqIH1cclxuICAgKlxyXG4gICAqIGZvciBhY3Rpb24gZ3JvdXBzLCByZXNwb25zZSB3aWxsIGxvb2sgbGlrZTpcclxuICAgKiB7XHJcbiAgICogICBcInJlc2VydmVkXCI6IHRydWUsXHJcbiAgICogICBcImhpZGRlblwiOiBmYWxzZSxcclxuICAgKiAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcImluZGljZXM6ZGF0YS9yZWFkKlwiLCBcImluZGljZXM6YWRtaW4vbWFwcGluZ3MvZmllbGRzL2dldCpcIl0sXHJcbiAgICogICBcInR5cGVcIjogXCJpbmRleFwiLFxyXG4gICAqICAgXCJkZXNjcmlwdGlvblwiOiBcIkFsbG93IGFsbCByZWFkIG9wZXJhdGlvbnNcIixcclxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXHJcbiAgICogfVxyXG4gICAqXHJcbiAgICogZm9yIHRlbmFudCwgcmVzcG9uc2Ugd2lsbCBsb29rIGxpa2U6XHJcbiAgICoge1xyXG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxyXG4gICAqICAgXCJoaWRkZW5cIjogZmFsc2UsXHJcbiAgICogICBcImRlc2NyaXB0aW9uXCI6IFwiR2xvYmFsIHRlbmFudFwiLFxyXG4gICAqICAgXCJzdGF0aWNcIjogZmFsc2VcclxuICAgKiB9LFxyXG4gICAqL1xyXG4gIHJvdXRlci5nZXQoXHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9LyR7Q09ORklHVVJBVElPTl9BUElfUFJFRklYfS97cmVzb3VyY2VOYW1lfS97aWR9YCxcclxuICAgICAgdmFsaWRhdGU6IHtcclxuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICAgICAgcmVzb3VyY2VOYW1lOiBzY2hlbWEuc3RyaW5nKCksXHJcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIGFzeW5jIChcclxuICAgICAgY29udGV4dCxcclxuICAgICAgcmVxdWVzdCxcclxuICAgICAgcmVzcG9uc2VcclxuICAgICk6IFByb21pc2U8SU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2U8YW55IHwgUmVzcG9uc2VFcnJvcj4+ID0+IHtcclxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XHJcbiAgICAgIGxldCBlc1Jlc3A7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LmdldFJlc291cmNlJywge1xyXG4gICAgICAgICAgcmVzb3VyY2VOYW1lOiByZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsXHJcbiAgICAgICAgICBpZDogcmVxdWVzdC5wYXJhbXMuaWQsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogZXNSZXNwW3JlcXVlc3QucGFyYW1zLmlkXSB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgLyoqXHJcbiAgICogRGVsZXRlcyBhbiBlbnRpdHkgYnkgaWQuXHJcbiAgICovXHJcbiAgcm91dGVyLmRlbGV0ZShcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vJHtDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVh9L3tyZXNvdXJjZU5hbWV9L3tpZH1gLFxyXG4gICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKHtcclxuICAgICAgICAgICAgbWluTGVuZ3RoOiAxLFxyXG4gICAgICAgICAgfSksXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgYXN5bmMgKFxyXG4gICAgICBjb250ZXh0LFxyXG4gICAgICByZXF1ZXN0LFxyXG4gICAgICByZXNwb25zZVxyXG4gICAgKTogUHJvbWlzZTxJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xyXG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcclxuICAgICAgbGV0IGVzUmVzcDtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuZGVsZXRlUmVzb3VyY2UnLCB7XHJcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSxcclxuICAgICAgICAgIGlkOiByZXF1ZXN0LnBhcmFtcy5pZCxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBlc1Jlc3AubWVzc2FnZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFVwZGF0ZSBvYmplY3Qgd2l0aCBvdXQgSWQuIFJlc291cmNlIGlkZW50aWZpY2F0aW9uIGlzIGV4cGVjdGVkIHRvIGNvbXB1dGVkIGZyb20gaGVhZGVycy4gRWc6IGF1dGggaGVhZGVyc1xyXG4gICAqXHJcbiAgICogUmVxdWVzdCBzYW1wbGU6XHJcbiAgICogL2NvbmZpZ3VyYXRpb24vYWNjb3VudFxyXG4gICAqIHtcclxuICAgKiAgIFwicGFzc3dvcmRcIjogXCJuZXctcGFzc3dvcmRcIixcclxuICAgKiAgIFwiY3VycmVudF9wYXNzd29yZFwiOiBcIm9sZC1wYXNzd29yZFwiXHJcbiAgICogfVxyXG4gICAqL1xyXG4gIHJvdXRlci5wb3N0KFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX1gLFxyXG4gICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICB9KSxcclxuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgYXN5bmMgKFxyXG4gICAgICBjb250ZXh0LFxyXG4gICAgICByZXF1ZXN0LFxyXG4gICAgICByZXNwb25zZVxyXG4gICAgKTogUHJvbWlzZTxJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHZhbGlkYXRlUmVxdWVzdEJvZHkocmVxdWVzdC5wYXJhbXMucmVzb3VyY2VOYW1lLCByZXF1ZXN0LmJvZHkpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHsgYm9keTogZXJyb3IgfSk7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XHJcbiAgICAgIGxldCBlc1Jlc3A7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LnNhdmVSZXNvdXJjZVdpdGhvdXRJZCcsIHtcclxuICAgICAgICAgIHJlc291cmNlTmFtZTogcmVxdWVzdC5wYXJhbXMucmVzb3VyY2VOYW1lLFxyXG4gICAgICAgICAgYm9keTogcmVxdWVzdC5ib2R5LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgLyoqXHJcbiAgICogVXBkYXRlIGVudGl0eSBieSBJZC5cclxuICAgKi9cclxuICByb3V0ZXIucG9zdChcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vJHtDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVh9L3tyZXNvdXJjZU5hbWV9L3tpZH1gLFxyXG4gICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKHtcclxuICAgICAgICAgICAgdmFsaWRhdGU6IHZhbGlkYXRlRW50aXR5SWQsXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9KSxcclxuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgYXN5bmMgKFxyXG4gICAgICBjb250ZXh0LFxyXG4gICAgICByZXF1ZXN0LFxyXG4gICAgICByZXNwb25zZVxyXG4gICAgKTogUHJvbWlzZTxJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHZhbGlkYXRlUmVxdWVzdEJvZHkocmVxdWVzdC5wYXJhbXMucmVzb3VyY2VOYW1lLCByZXF1ZXN0LmJvZHkpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHsgYm9keTogZXJyb3IgfSk7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XHJcbiAgICAgIGxldCBlc1Jlc3A7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LnNhdmVSZXNvdXJjZScsIHtcclxuICAgICAgICAgIHJlc291cmNlTmFtZTogcmVxdWVzdC5wYXJhbXMucmVzb3VyY2VOYW1lLFxyXG4gICAgICAgICAgaWQ6IHJlcXVlc3QucGFyYW1zLmlkLFxyXG4gICAgICAgICAgYm9keTogcmVxdWVzdC5ib2R5LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyBhdXRoZW50aWNhdGlvbiBpbmZvIG9mIHRoZSB1c2VyLlxyXG4gICAqXHJcbiAgICogVGhlIHJlc3BvbnNlIGxvb2tzIGxpa2U6XHJcbiAgICoge1xyXG4gICAqICAgXCJ1c2VyXCI6IFwiVXNlciBbbmFtZT1hZG1pbiwgcm9sZXM9W10sIHJlcXVlc3RlZFRlbmFudD1fX3VzZXJfX11cIixcclxuICAgKiAgIFwidXNlcl9uYW1lXCI6IFwiYWRtaW5cIixcclxuICAgKiAgIFwidXNlcl9yZXF1ZXN0ZWRfdGVuYW50XCI6IFwiX191c2VyX19cIixcclxuICAgKiAgIFwicmVtb3RlX2FkZHJlc3NcIjogXCIxMjcuMC4wLjE6MzUwNDRcIixcclxuICAgKiAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcclxuICAgKiAgIFwiY3VzdG9tX2F0dHJpYnV0ZV9uYW1lc1wiOiBbXSxcclxuICAgKiAgIFwicm9sZXNcIjogW1wiYWxsX2FjY2Vzc1wiLCBcInNlY3VyaXR5X21hbmFnZXJcIl0sXHJcbiAgICogICBcInRlbmFudHNcIjoge1xyXG4gICAqICAgICBcImFub3RoZXJfdGVuYW50XCI6IHRydWUsXHJcbiAgICogICAgIFwiYWRtaW5cIjogdHJ1ZSxcclxuICAgKiAgICAgXCJnbG9iYWxfdGVuYW50XCI6IHRydWUsXHJcbiAgICogICAgIFwiYWFhYWFcIjogdHJ1ZSxcclxuICAgKiAgICAgXCJ0ZXN0IHRlbmFudFwiOiB0cnVlXHJcbiAgICogICB9LFxyXG4gICAqICAgXCJwcmluY2lwYWxcIjogbnVsbCxcclxuICAgKiAgIFwicGVlcl9jZXJ0aWZpY2F0ZXNcIjogXCIwXCIsXHJcbiAgICogICBcInNzb19sb2dvdXRfdXJsXCI6IG51bGxcclxuICAgKiB9XHJcbiAgICovXHJcbiAgcm91dGVyLmdldChcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vYXV0aC9hdXRoaW5mb2AsXHJcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICBhc3luYyAoXHJcbiAgICAgIGNvbnRleHQsXHJcbiAgICAgIHJlcXVlc3QsXHJcbiAgICAgIHJlc3BvbnNlXHJcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XHJcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xyXG4gICAgICBsZXQgZXNSZXNwO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGVzUmVzcCA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbnNlYXJjaF9zZWN1cml0eS5hdXRoaW5mbycpO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keTogZXNSZXNwLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICApO1xyXG5cclxuICByb3V0ZXIuZ2V0KFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9hdXRoL2Rhc2hib2FyZHNpbmZvYCxcclxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxyXG4gICAgfSxcclxuICAgIGFzeW5jIChcclxuICAgICAgY29udGV4dCxcclxuICAgICAgcmVxdWVzdCxcclxuICAgICAgcmVzcG9uc2VcclxuICAgICk6IFByb21pc2U8SU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2U8YW55IHwgUmVzcG9uc2VFcnJvcj4+ID0+IHtcclxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XHJcbiAgICAgIGxldCBlc1Jlc3A7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LmRhc2hib2FyZHNpbmZvJyk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiBlc1Jlc3AsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgYXVkaXQgbG9nIGNvbmZpZ3VyYXRpb27jgIJcclxuICAgKlxyXG4gICAqIFNhbXBsZSBwYXlsb2FkOlxyXG4gICAqIHtcclxuICAgKiAgIFwiZW5hYmxlZFwiOnRydWUsXHJcbiAgICogICBcImF1ZGl0XCI6e1xyXG4gICAqICAgICBcImVuYWJsZV9yZXN0XCI6ZmFsc2UsXHJcbiAgICogICAgIFwiZGlzYWJsZWRfcmVzdF9jYXRlZ29yaWVzXCI6W1xyXG4gICAqICAgICAgIFwiRkFJTEVEX0xPR0lOXCIsXHJcbiAgICogICAgICAgXCJBVVRIRU5USUNBVEVEXCJcclxuICAgKiAgICAgXSxcclxuICAgKiAgICAgXCJlbmFibGVfdHJhbnNwb3J0XCI6dHJ1ZSxcclxuICAgKiAgICAgXCJkaXNhYmxlZF90cmFuc3BvcnRfY2F0ZWdvcmllc1wiOltcclxuICAgKiAgICAgICBcIkdSQU5URURfUFJJVklMRUdFU1wiXHJcbiAgICogICAgIF0sXHJcbiAgICogICAgIFwicmVzb2x2ZV9idWxrX3JlcXVlc3RzXCI6dHJ1ZSxcclxuICAgKiAgICAgXCJsb2dfcmVxdWVzdF9ib2R5XCI6ZmFsc2UsXHJcbiAgICogICAgIFwicmVzb2x2ZV9pbmRpY2VzXCI6dHJ1ZSxcclxuICAgKiAgICAgXCJleGNsdWRlX3NlbnNpdGl2ZV9oZWFkZXJzXCI6dHJ1ZSxcclxuICAgKiAgICAgXCJpZ25vcmVfdXNlcnNcIjpbXHJcbiAgICogICAgICAgXCJhZG1pblwiLFxyXG4gICAqICAgICBdLFxyXG4gICAqICAgICBcImlnbm9yZV9yZXF1ZXN0c1wiOltcclxuICAgKiAgICAgICBcIlNlYXJjaFJlcXVlc3RcIixcclxuICAgKiAgICAgICBcImluZGljZXM6ZGF0YS9yZWFkLypcIlxyXG4gICAqICAgICBdXHJcbiAgICogICB9LFxyXG4gICAqICAgXCJjb21wbGlhbmNlXCI6e1xyXG4gICAqICAgICBcImVuYWJsZWRcIjp0cnVlLFxyXG4gICAqICAgICBcImludGVybmFsX2NvbmZpZ1wiOmZhbHNlLFxyXG4gICAqICAgICBcImV4dGVybmFsX2NvbmZpZ1wiOmZhbHNlLFxyXG4gICAqICAgICBcInJlYWRfbWV0YWRhdGFfb25seVwiOmZhbHNlLFxyXG4gICAqICAgICBcInJlYWRfd2F0Y2hlZF9maWVsZHNcIjp7XHJcbiAgICogICAgICAgXCJpbmRleE5hbWUxXCI6W1xyXG4gICAqICAgICAgICAgXCJmaWVsZDFcIixcclxuICAgKiAgICAgICAgIFwiZmllbGRzLSpcIlxyXG4gICAqICAgICAgIF1cclxuICAgKiAgICAgfSxcclxuICAgKiAgICAgXCJyZWFkX2lnbm9yZV91c2Vyc1wiOltcclxuICAgKiAgICAgICBcIm9wZW5zZWFyY2hkYXNoYm9hcmRzc2VydmVyXCIsXHJcbiAgICogICAgICAgXCJvcGVyYXRvci8qXCJcclxuICAgKiAgICAgXSxcclxuICAgKiAgICAgXCJ3cml0ZV9tZXRhZGF0YV9vbmx5XCI6ZmFsc2UsXHJcbiAgICogICAgIFwid3JpdGVfbG9nX2RpZmZzXCI6ZmFsc2UsXHJcbiAgICogICAgIFwid3JpdGVfd2F0Y2hlZF9pbmRpY2VzXCI6W1xyXG4gICAqICAgICAgIFwiaW5kZXhOYW1lMlwiLFxyXG4gICAqICAgICAgIFwiaW5kZXhQYXR0ZXJucy0qXCJcclxuICAgKiAgICAgXSxcclxuICAgKiAgICAgXCJ3cml0ZV9pZ25vcmVfdXNlcnNcIjpbXHJcbiAgICogICAgICAgXCJhZG1pblwiXHJcbiAgICogICAgIF1cclxuICAgKiAgIH1cclxuICAgKiB9XHJcbiAgICovXHJcbiAgcm91dGVyLmdldChcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vY29uZmlndXJhdGlvbi9hdWRpdGAsXHJcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICBhc3luYyAoXHJcbiAgICAgIGNvbnRleHQsXHJcbiAgICAgIHJlcXVlc3QsXHJcbiAgICAgIHJlc3BvbnNlXHJcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XHJcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xyXG5cclxuICAgICAgbGV0IGVzUmVzcDtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuZ2V0QXVkaXQnKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IGVzUmVzcCxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcclxuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycm9yLnN0YXR1c0NvZGUsXHJcbiAgICAgICAgICBib2R5OiBwYXJzZUVzRXJyb3JSZXNwb25zZShlcnJvciksXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICApO1xyXG5cclxuICAvKipcclxuICAgKiBVcGRhdGUgYXVkaXQgbG9nIGNvbmZpZ3VyYXRpb27jgIJcclxuICAgKlxyXG4gICAqIFNhbXBsZSBwYXlsb2FkOlxyXG4gICAqIHtcclxuICAgKiAgIFwiZW5hYmxlZFwiOnRydWUsXHJcbiAgICogICBcImF1ZGl0XCI6e1xyXG4gICAqICAgICBcImVuYWJsZV9yZXN0XCI6ZmFsc2UsXHJcbiAgICogICAgIFwiZGlzYWJsZWRfcmVzdF9jYXRlZ29yaWVzXCI6W1xyXG4gICAqICAgICAgIFwiRkFJTEVEX0xPR0lOXCIsXHJcbiAgICogICAgICAgXCJBVVRIRU5USUNBVEVEXCJcclxuICAgKiAgICAgXSxcclxuICAgKiAgICAgXCJlbmFibGVfdHJhbnNwb3J0XCI6dHJ1ZSxcclxuICAgKiAgICAgXCJkaXNhYmxlZF90cmFuc3BvcnRfY2F0ZWdvcmllc1wiOltcclxuICAgKiAgICAgICBcIkdSQU5URURfUFJJVklMRUdFU1wiXHJcbiAgICogICAgIF0sXHJcbiAgICogICAgIFwicmVzb2x2ZV9idWxrX3JlcXVlc3RzXCI6dHJ1ZSxcclxuICAgKiAgICAgXCJsb2dfcmVxdWVzdF9ib2R5XCI6ZmFsc2UsXHJcbiAgICogICAgIFwicmVzb2x2ZV9pbmRpY2VzXCI6dHJ1ZSxcclxuICAgKiAgICAgXCJleGNsdWRlX3NlbnNpdGl2ZV9oZWFkZXJzXCI6dHJ1ZSxcclxuICAgKiAgICAgXCJpZ25vcmVfdXNlcnNcIjpbXHJcbiAgICogICAgICAgXCJhZG1pblwiLFxyXG4gICAqICAgICBdLFxyXG4gICAqICAgICBcImlnbm9yZV9yZXF1ZXN0c1wiOltcclxuICAgKiAgICAgICBcIlNlYXJjaFJlcXVlc3RcIixcclxuICAgKiAgICAgICBcImluZGljZXM6ZGF0YS9yZWFkLypcIlxyXG4gICAqICAgICBdXHJcbiAgICogICB9LFxyXG4gICAqICAgXCJjb21wbGlhbmNlXCI6e1xyXG4gICAqICAgICBcImVuYWJsZWRcIjp0cnVlLFxyXG4gICAqICAgICBcImludGVybmFsX2NvbmZpZ1wiOmZhbHNlLFxyXG4gICAqICAgICBcImV4dGVybmFsX2NvbmZpZ1wiOmZhbHNlLFxyXG4gICAqICAgICBcInJlYWRfbWV0YWRhdGFfb25seVwiOmZhbHNlLFxyXG4gICAqICAgICBcInJlYWRfd2F0Y2hlZF9maWVsZHNcIjp7XHJcbiAgICogICAgICAgXCJpbmRleE5hbWUxXCI6W1xyXG4gICAqICAgICAgICAgXCJmaWVsZDFcIixcclxuICAgKiAgICAgICAgIFwiZmllbGRzLSpcIlxyXG4gICAqICAgICAgIF1cclxuICAgKiAgICAgfSxcclxuICAgKiAgICAgXCJyZWFkX2lnbm9yZV91c2Vyc1wiOltcclxuICAgKiAgICAgICBcImtpYmFuYXNlcnZlclwiLFxyXG4gICAqICAgICAgIFwib3BlcmF0b3IvKlwiXHJcbiAgICogICAgIF0sXHJcbiAgICogICAgIFwid3JpdGVfbWV0YWRhdGFfb25seVwiOmZhbHNlLFxyXG4gICAqICAgICBcIndyaXRlX2xvZ19kaWZmc1wiOmZhbHNlLFxyXG4gICAqICAgICBcIndyaXRlX3dhdGNoZWRfaW5kaWNlc1wiOltcclxuICAgKiAgICAgICBcImluZGV4TmFtZTJcIixcclxuICAgKiAgICAgICBcImluZGV4UGF0dGVybnMtKlwiXHJcbiAgICogICAgIF0sXHJcbiAgICogICAgIFwid3JpdGVfaWdub3JlX3VzZXJzXCI6W1xyXG4gICAqICAgICAgIFwiYWRtaW5cIlxyXG4gICAqICAgICBdXHJcbiAgICogICB9XHJcbiAgICogfVxyXG4gICAqL1xyXG4gIHJvdXRlci5wb3N0KFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9jb25maWd1cmF0aW9uL2F1ZGl0L2NvbmZpZ2AsXHJcbiAgICAgIHZhbGlkYXRlOiB7XHJcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xyXG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcclxuICAgICAgbGV0IGVzUmVzcDtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuc2F2ZUF1ZGl0Jywge1xyXG4gICAgICAgICAgYm9keTogcmVxdWVzdC5ib2R5LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgLyoqXHJcbiAgICogRGVsZXRlcyBjYWNoZS5cclxuICAgKlxyXG4gICAqIFNhbXBsZSByZXNwb25zZToge1wibWVzc2FnZVwiOlwiQ2FjaGUgZmx1c2hlZCBzdWNjZXNzZnVsbHkuXCJ9XHJcbiAgICovXHJcbiAgcm91dGVyLmRlbGV0ZShcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vY29uZmlndXJhdGlvbi9jYWNoZWAsXHJcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XHJcbiAgICAgIGxldCBlc1Jlc3BvbnNlO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGVzUmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuY2xlYXJDYWNoZScpO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcG9uc2UubWVzc2FnZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgcGVybWlzc2lvbiBpbmZvIG9mIGN1cnJlbnQgdXNlci5cclxuICAgKlxyXG4gICAqIFNhbXBsZSByZXNwb25zZTpcclxuICAgKiB7XHJcbiAgICogICBcInVzZXJcIjogXCJVc2VyIFtuYW1lPWFkbWluLCByb2xlcz1bXSwgcmVxdWVzdGVkVGVuYW50PV9fdXNlcl9fXVwiLFxyXG4gICAqICAgXCJ1c2VyX25hbWVcIjogXCJhZG1pblwiLFxyXG4gICAqICAgXCJoYXNfYXBpX2FjY2Vzc1wiOiB0cnVlLFxyXG4gICAqICAgXCJkaXNhYmxlZF9lbmRwb2ludHNcIjoge31cclxuICAgKiB9XHJcbiAgICovXHJcbiAgcm91dGVyLmdldChcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vcmVzdGFwaWluZm9gLFxyXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXHJcbiAgICB9LFxyXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGVzUmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkucmVzdGFwaWluZm8nKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keTogZXNSZXNwb25zZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCh7XHJcbiAgICAgICAgICBib2R5OiBlcnJvcixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFZhbGlkYXRlcyBETFMgKGRvY3VtZW50IGxldmVsIHNlY3VyaXR5KSBxdWVyeS5cclxuICAgKlxyXG4gICAqIFJlcXVlc3QgcGF5bG9hZCBpcyBhbiBFUyBxdWVyeS5cclxuICAgKi9cclxuICByb3V0ZXIucG9zdChcclxuICAgIHtcclxuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vJHtDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVh9L3ZhbGlkYXRlZGxzL3tpbmRleE5hbWV9YCxcclxuICAgICAgdmFsaWRhdGU6IHtcclxuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICAgICAgLy8gaW4gbGVnYWN5IHBsdWdpbiBpbXBsbWVudGF0aW9uLCBpbmRleE5hbWUgaXMgbm90IHVzZWQgd2hlbiBjYWxsaW5nIEVTIEFQSS5cclxuICAgICAgICAgIGluZGV4TmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xyXG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBlc1Jlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LnZhbGlkYXRlRGxzJywge1xyXG4gICAgICAgICAgYm9keTogcmVxdWVzdC5ib2R5LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiBlc1Jlc3BvbnNlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICApO1xyXG5cclxuICAvKipcclxuICAgKiBHZXRzIGluZGV4IG1hcHBpbmcuXHJcbiAgICpcclxuICAgKiBDYWxsaW5nIEVTIF9tYXBwaW5nIEFQSSB1bmRlciB0aGUgaG9vZC4gc2VlXHJcbiAgICogaHR0cHM6Ly93d3cuZWxhc3RpYy5jby9ndWlkZS9lbi9lbGFzdGljc2VhcmNoL3JlZmVyZW5jZS9jdXJyZW50L2luZGljZXMtZ2V0LW1hcHBpbmcuaHRtbFxyXG4gICAqL1xyXG4gIHJvdXRlci5wb3N0KFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0vaW5kZXhfbWFwcGluZ3NgLFxyXG4gICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICAgICAgaW5kZXg6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGVzUmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuZ2V0SW5kZXhNYXBwaW5ncycsIHtcclxuICAgICAgICAgIGluZGV4OiByZXF1ZXN0LmJvZHkuaW5kZXguam9pbignLCcpLFxyXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgYWxsb3dfbm9faW5kaWNlczogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IGVzUmVzcG9uc2UsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgYWxsIGluZGljZXMsIGFuZCBmaWVsZCBtYXBwaW5ncy5cclxuICAgKlxyXG4gICAqIENhbGxzIEVTIEFQSSAnL19hbGwvX21hcHBpbmcvZmllbGQvKicgdW5kZXIgdGhlIGhvb2QuIHNlZVxyXG4gICAqIGh0dHBzOi8vd3d3LmVsYXN0aWMuY28vZ3VpZGUvZW4vZWxhc3RpY3NlYXJjaC9yZWZlcmVuY2UvY3VycmVudC9pbmRpY2VzLWdldC1tYXBwaW5nLmh0bWxcclxuICAgKi9cclxuICByb3V0ZXIuZ2V0KFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0vaW5kaWNlc2AsXHJcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbnNlYXJjaF9zZWN1cml0eS5pbmRpY2VzJyk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IGVzUmVzcG9uc2UsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcnNlRXNFcnJvclJlc3BvbnNlKGVycm9yOiBhbnkpIHtcclxuICBpZiAoZXJyb3IucmVzcG9uc2UpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGVzRXJyb3JSZXNwb25zZSA9IEpTT04ucGFyc2UoZXJyb3IucmVzcG9uc2UpO1xyXG4gICAgICByZXR1cm4gZXNFcnJvclJlc3BvbnNlLnJlYXNvbiB8fCBlcnJvci5yZXNwb25zZTtcclxuICAgIH0gY2F0Y2ggKHBhcnNpbmdFcnJvcikge1xyXG4gICAgICByZXR1cm4gZXJyb3IucmVzcG9uc2U7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBlcnJvci5tZXNzYWdlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSwgZXJyb3I6IGFueSkge1xyXG4gIHJldHVybiByZXNwb25zZS5jdXN0b20oe1xyXG4gICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSxcclxuICAgIGJvZHk6IHBhcnNlRXNFcnJvclJlc3BvbnNlKGVycm9yKSxcclxuICB9KTtcclxufVxyXG4iXX0=