"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "getSavedObject", {
  enumerable: true,
  get: function () {
    return _getSavedObject.getSavedObject;
  }
});
Object.defineProperty(exports, "setSavedObject", {
  enumerable: true,
  get: function () {
    return _setSavedObject.setSavedObject;
  }
});

var _getSavedObject = require("./get-saved-object");

var _setSavedObject = require("./set-saved-object");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgZ2V0U2F2ZWRPYmplY3QgfSBmcm9tICcuL2dldC1zYXZlZC1vYmplY3QnO1xuZXhwb3J0IHsgc2V0U2F2ZWRPYmplY3QgfSBmcm9tICcuL3NldC1zYXZlZC1vYmplY3QnO1xuIl19