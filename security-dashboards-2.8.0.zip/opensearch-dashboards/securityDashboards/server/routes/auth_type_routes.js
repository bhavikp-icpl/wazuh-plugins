"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineAuthTypeRoutes = defineAuthTypeRoutes;

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function defineAuthTypeRoutes(router, config) {
  /**
   * Auth type API that returns current auth type configured on OpenSearchDashboards Server.
   *
   * GET /api/authtype
   * Response:
   *  200 OK
   *  {
   *    authtype: saml
   *  }
   */
  router.get({
    path: '/api/authtype',
    validate: false,
    options: {
      authRequired: false
    }
  }, async (context, request, response) => {
    const authType = config.auth.type || 'basicauth';
    return response.ok({
      body: {
        authtype: authType
      }
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGhfdHlwZV9yb3V0ZXMudHMiXSwibmFtZXMiOlsiZGVmaW5lQXV0aFR5cGVSb3V0ZXMiLCJyb3V0ZXIiLCJjb25maWciLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJvcHRpb25zIiwiYXV0aFJlcXVpcmVkIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImF1dGhUeXBlIiwiYXV0aCIsInR5cGUiLCJvayIsImJvZHkiLCJhdXRodHlwZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFLTyxTQUFTQSxvQkFBVCxDQUE4QkMsTUFBOUIsRUFBK0NDLE1BQS9DLEVBQWlGO0FBQ3RGO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0VELEVBQUFBLE1BQU0sQ0FBQ0UsR0FBUCxDQUNFO0FBQUVDLElBQUFBLElBQUksRUFBRSxlQUFSO0FBQXlCQyxJQUFBQSxRQUFRLEVBQUUsS0FBbkM7QUFBMENDLElBQUFBLE9BQU8sRUFBRTtBQUFFQyxNQUFBQSxZQUFZLEVBQUU7QUFBaEI7QUFBbkQsR0FERixFQUVFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNQyxRQUFRLEdBQUdULE1BQU0sQ0FBQ1UsSUFBUCxDQUFZQyxJQUFaLElBQW9CLFdBQXJDO0FBQ0EsV0FBT0gsUUFBUSxDQUFDSSxFQUFULENBQVk7QUFDakJDLE1BQUFBLElBQUksRUFBRTtBQUNKQyxRQUFBQSxRQUFRLEVBQUVMO0FBRE47QUFEVyxLQUFaLENBQVA7QUFLRCxHQVRIO0FBV0QiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiAgIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xyXG4gKlxyXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXHJcbiAqICAgWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxyXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XHJcbiAqXHJcbiAqICAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxyXG4gKlxyXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxyXG4gKiAgIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXHJcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7IElSb3V0ZXIgfSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcclxuaW1wb3J0IHsgU2VjdXJpdHlQbHVnaW5Db25maWdUeXBlIH0gZnJvbSAnLi4nO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGRlZmluZUF1dGhUeXBlUm91dGVzKHJvdXRlcjogSVJvdXRlciwgY29uZmlnOiBTZWN1cml0eVBsdWdpbkNvbmZpZ1R5cGUpIHtcclxuICAvKipcclxuICAgKiBBdXRoIHR5cGUgQVBJIHRoYXQgcmV0dXJucyBjdXJyZW50IGF1dGggdHlwZSBjb25maWd1cmVkIG9uIE9wZW5TZWFyY2hEYXNoYm9hcmRzIFNlcnZlci5cclxuICAgKlxyXG4gICAqIEdFVCAvYXBpL2F1dGh0eXBlXHJcbiAgICogUmVzcG9uc2U6XHJcbiAgICogIDIwMCBPS1xyXG4gICAqICB7XHJcbiAgICogICAgYXV0aHR5cGU6IHNhbWxcclxuICAgKiAgfVxyXG4gICAqL1xyXG4gIHJvdXRlci5nZXQoXHJcbiAgICB7IHBhdGg6ICcvYXBpL2F1dGh0eXBlJywgdmFsaWRhdGU6IGZhbHNlLCBvcHRpb25zOiB7IGF1dGhSZXF1aXJlZDogZmFsc2UgfSB9LFxyXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGNvbnN0IGF1dGhUeXBlID0gY29uZmlnLmF1dGgudHlwZSB8fCAnYmFzaWNhdXRoJztcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICBhdXRodHlwZTogYXV0aFR5cGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgKTtcclxufVxyXG4iXX0=