"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "getUpdates", {
  enumerable: true,
  get: function () {
    return _getUpdates.getUpdates;
  }
});

var _getUpdates = require("./get-updates");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgZ2V0VXBkYXRlcyB9IGZyb20gJy4vZ2V0LXVwZGF0ZXMnO1xuIl19