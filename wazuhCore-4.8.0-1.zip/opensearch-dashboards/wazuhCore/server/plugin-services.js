"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setCore = exports.getCore = void 0;

var _common = require("../../../src/plugins/opensearch_dashboards_utils/common");

const [getCore, setCore] = (0, _common.createGetterSetter)('Core');
exports.setCore = setCore;
exports.getCore = getCore;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBsdWdpbi1zZXJ2aWNlcy50cyJdLCJuYW1lcyI6WyJnZXRDb3JlIiwic2V0Q29yZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNBOztBQUVPLE1BQU0sQ0FBQ0EsT0FBRCxFQUFVQyxPQUFWLElBQXFCLGdDQUE4QixNQUE5QixDQUEzQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvcmVTdGFydCB9IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHsgY3JlYXRlR2V0dGVyU2V0dGVyIH0gZnJvbSAnLi4vLi4vLi4vc3JjL3BsdWdpbnMvb3BlbnNlYXJjaF9kYXNoYm9hcmRzX3V0aWxzL2NvbW1vbic7XG5cbmV4cG9ydCBjb25zdCBbZ2V0Q29yZSwgc2V0Q29yZV0gPSBjcmVhdGVHZXR0ZXJTZXR0ZXI8Q29yZVN0YXJ0PignQ29yZScpO1xuIl19