"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.routes = exports.SAVED_OBJECT_USER_PREFERENCES = exports.SAVED_OBJECT_UPDATES = exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'wazuhCheckUpdates';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'wazuh_check_updates';
exports.PLUGIN_NAME = PLUGIN_NAME;
const SAVED_OBJECT_UPDATES = 'wazuh-check-updates-available-updates';
exports.SAVED_OBJECT_UPDATES = SAVED_OBJECT_UPDATES;
const SAVED_OBJECT_USER_PREFERENCES = 'wazuh-check-updates-user-preferences';
exports.SAVED_OBJECT_USER_PREFERENCES = SAVED_OBJECT_USER_PREFERENCES;
let routes;
exports.routes = routes;

(function (routes) {
  routes["checkUpdates"] = "/api/wazuh-check-updates/updates";
  routes["userPreferences"] = "/api/wazuh-check-updates/user-preferences/me";
})(routes || (exports.routes = routes = {}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnN0YW50cy50cyJdLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSIsIlNBVkVEX09CSkVDVF9VUERBVEVTIiwiU0FWRURfT0JKRUNUX1VTRVJfUFJFRkVSRU5DRVMiLCJyb3V0ZXMiXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRyxtQkFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLHFCQUFwQjs7QUFFQSxNQUFNQyxvQkFBb0IsR0FBRyx1Q0FBN0I7O0FBQ0EsTUFBTUMsNkJBQTZCLEdBQUcsc0NBQXRDOztJQUVLQyxNOzs7V0FBQUEsTTtBQUFBQSxFQUFBQSxNO0FBQUFBLEVBQUFBLE07R0FBQUEsTSxzQkFBQUEsTSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnd2F6dWhDaGVja1VwZGF0ZXMnO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ3dhenVoX2NoZWNrX3VwZGF0ZXMnO1xuXG5leHBvcnQgY29uc3QgU0FWRURfT0JKRUNUX1VQREFURVMgPSAnd2F6dWgtY2hlY2stdXBkYXRlcy1hdmFpbGFibGUtdXBkYXRlcyc7XG5leHBvcnQgY29uc3QgU0FWRURfT0JKRUNUX1VTRVJfUFJFRkVSRU5DRVMgPSAnd2F6dWgtY2hlY2stdXBkYXRlcy11c2VyLXByZWZlcmVuY2VzJztcblxuZXhwb3J0IGVudW0gcm91dGVzIHtcbiAgY2hlY2tVcGRhdGVzID0gJy9hcGkvd2F6dWgtY2hlY2stdXBkYXRlcy91cGRhdGVzJyxcbiAgdXNlclByZWZlcmVuY2VzID0gJy9hcGkvd2F6dWgtY2hlY2stdXBkYXRlcy91c2VyLXByZWZlcmVuY2VzL21lJyxcbn1cbiJdfQ==