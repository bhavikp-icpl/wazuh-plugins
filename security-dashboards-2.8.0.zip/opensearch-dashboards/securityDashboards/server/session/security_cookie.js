"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.clearOldVersionCookieValue = clearOldVersionCookieValue;
exports.getSecurityCookieOptions = getSecurityCookieOptions;

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function getSecurityCookieOptions(config) {
  return {
    name: config.cookie.name,
    encryptionKey: config.cookie.password,
    validate: sessionStorage => {
      sessionStorage = sessionStorage;

      if (sessionStorage === undefined) {
        return {
          isValid: false,
          path: '/'
        };
      } // TODO: with setting redirect attributes to support OIDC and SAML,
      //       we need to do additonal cookie validatin in AuthenticationHandlers.
      // if SAML fields present


      if (sessionStorage.saml && sessionStorage.saml.requestId && sessionStorage.saml.nextUrl) {
        return {
          isValid: true,
          path: '/'
        };
      } // if OIDC fields present


      if (sessionStorage.oidc) {
        return {
          isValid: true,
          path: '/'
        };
      }

      if (sessionStorage.expiryTime === undefined || sessionStorage.expiryTime < Date.now()) {
        return {
          isValid: false,
          path: '/'
        };
      }

      return {
        isValid: true,
        path: '/'
      };
    },
    isSecure: config.cookie.secure,
    sameSite: config.cookie.isSameSite || undefined
  };
}

function clearOldVersionCookieValue(config) {
  if (config.cookie.secure) {
    return 'security_authentication=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly; Path=/';
  } else {
    return 'security_authentication=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Path=/';
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlY3VyaXR5X2Nvb2tpZS50cyJdLCJuYW1lcyI6WyJnZXRTZWN1cml0eUNvb2tpZU9wdGlvbnMiLCJjb25maWciLCJuYW1lIiwiY29va2llIiwiZW5jcnlwdGlvbktleSIsInBhc3N3b3JkIiwidmFsaWRhdGUiLCJzZXNzaW9uU3RvcmFnZSIsInVuZGVmaW5lZCIsImlzVmFsaWQiLCJwYXRoIiwic2FtbCIsInJlcXVlc3RJZCIsIm5leHRVcmwiLCJvaWRjIiwiZXhwaXJ5VGltZSIsIkRhdGUiLCJub3ciLCJpc1NlY3VyZSIsInNlY3VyZSIsInNhbWVTaXRlIiwiaXNTYW1lU2l0ZSIsImNsZWFyT2xkVmVyc2lvbkNvb2tpZVZhbHVlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE2Qk8sU0FBU0Esd0JBQVQsQ0FDTEMsTUFESyxFQUUrQztBQUNwRCxTQUFPO0FBQ0xDLElBQUFBLElBQUksRUFBRUQsTUFBTSxDQUFDRSxNQUFQLENBQWNELElBRGY7QUFFTEUsSUFBQUEsYUFBYSxFQUFFSCxNQUFNLENBQUNFLE1BQVAsQ0FBY0UsUUFGeEI7QUFHTEMsSUFBQUEsUUFBUSxFQUFHQyxjQUFELElBQXFFO0FBQzdFQSxNQUFBQSxjQUFjLEdBQUdBLGNBQWpCOztBQUNBLFVBQUlBLGNBQWMsS0FBS0MsU0FBdkIsRUFBa0M7QUFDaEMsZUFBTztBQUFFQyxVQUFBQSxPQUFPLEVBQUUsS0FBWDtBQUFrQkMsVUFBQUEsSUFBSSxFQUFFO0FBQXhCLFNBQVA7QUFDRCxPQUo0RSxDQU03RTtBQUNBO0FBQ0E7OztBQUNBLFVBQUlILGNBQWMsQ0FBQ0ksSUFBZixJQUF1QkosY0FBYyxDQUFDSSxJQUFmLENBQW9CQyxTQUEzQyxJQUF3REwsY0FBYyxDQUFDSSxJQUFmLENBQW9CRSxPQUFoRixFQUF5RjtBQUN2RixlQUFPO0FBQUVKLFVBQUFBLE9BQU8sRUFBRSxJQUFYO0FBQWlCQyxVQUFBQSxJQUFJLEVBQUU7QUFBdkIsU0FBUDtBQUNELE9BWDRFLENBYTdFOzs7QUFDQSxVQUFJSCxjQUFjLENBQUNPLElBQW5CLEVBQXlCO0FBQ3ZCLGVBQU87QUFBRUwsVUFBQUEsT0FBTyxFQUFFLElBQVg7QUFBaUJDLFVBQUFBLElBQUksRUFBRTtBQUF2QixTQUFQO0FBQ0Q7O0FBRUQsVUFBSUgsY0FBYyxDQUFDUSxVQUFmLEtBQThCUCxTQUE5QixJQUEyQ0QsY0FBYyxDQUFDUSxVQUFmLEdBQTRCQyxJQUFJLENBQUNDLEdBQUwsRUFBM0UsRUFBdUY7QUFDckYsZUFBTztBQUFFUixVQUFBQSxPQUFPLEVBQUUsS0FBWDtBQUFrQkMsVUFBQUEsSUFBSSxFQUFFO0FBQXhCLFNBQVA7QUFDRDs7QUFDRCxhQUFPO0FBQUVELFFBQUFBLE9BQU8sRUFBRSxJQUFYO0FBQWlCQyxRQUFBQSxJQUFJLEVBQUU7QUFBdkIsT0FBUDtBQUNELEtBekJJO0FBMEJMUSxJQUFBQSxRQUFRLEVBQUVqQixNQUFNLENBQUNFLE1BQVAsQ0FBY2dCLE1BMUJuQjtBQTJCTEMsSUFBQUEsUUFBUSxFQUFFbkIsTUFBTSxDQUFDRSxNQUFQLENBQWNrQixVQUFkLElBQTRCYjtBQTNCakMsR0FBUDtBQTZCRDs7QUFFTSxTQUFTYywwQkFBVCxDQUFvQ3JCLE1BQXBDLEVBQThFO0FBQ25GLE1BQUlBLE1BQU0sQ0FBQ0UsTUFBUCxDQUFjZ0IsTUFBbEIsRUFBMEI7QUFDeEIsV0FBTyxzR0FBUDtBQUNELEdBRkQsTUFFTztBQUNMLFdBQU8sOEZBQVA7QUFDRDtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcclxuICpcclxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxyXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cclxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxyXG4gKlxyXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuICpcclxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcclxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xyXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG5pbXBvcnQgeyBTZXNzaW9uU3RvcmFnZUNvb2tpZU9wdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyBTZWN1cml0eVBsdWdpbkNvbmZpZ1R5cGUgfSBmcm9tICcuLic7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB7XHJcbiAgLy8gc2VjdXJpdHlfYXV0aGVudGljYXRpb25cclxuICB1c2VybmFtZT86IHN0cmluZztcclxuICBjcmVkZW50aWFscz86IGFueTtcclxuICBhdXRoVHlwZT86IHN0cmluZztcclxuICBhc3NpZ25BdXRoSGVhZGVyPzogYm9vbGVhbjtcclxuICBpc0Fub255bW91c0F1dGg/OiBib29sZWFuO1xyXG4gIGV4cGlyeVRpbWU/OiBudW1iZXI7XHJcbiAgYWRkaXRpb25hbEF1dGhIZWFkZXJzPzogYW55O1xyXG5cclxuICAvLyBzZWN1cml0eV9zdG9yYWdlXHJcbiAgdGVuYW50PzogYW55O1xyXG5cclxuICAvLyBmb3Igb2lkYyBhdXRoIHdvcmtmbG93XHJcbiAgb2lkYz86IGFueTtcclxuXHJcbiAgLy8gZm9yIFNhbWwgYXV0aCB3b3JrZmxvd1xyXG4gIHNhbWw/OiB7XHJcbiAgICByZXF1ZXN0SWQ/OiBzdHJpbmc7XHJcbiAgICBuZXh0VXJsPzogc3RyaW5nO1xyXG4gICAgcmVkaXJlY3RIYXNoPzogYm9vbGVhbjtcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VjdXJpdHlDb29raWVPcHRpb25zKFxyXG4gIGNvbmZpZzogU2VjdXJpdHlQbHVnaW5Db25maWdUeXBlXHJcbik6IFNlc3Npb25TdG9yYWdlQ29va2llT3B0aW9uczxTZWN1cml0eVNlc3Npb25Db29raWU+IHtcclxuICByZXR1cm4ge1xyXG4gICAgbmFtZTogY29uZmlnLmNvb2tpZS5uYW1lLFxyXG4gICAgZW5jcnlwdGlvbktleTogY29uZmlnLmNvb2tpZS5wYXNzd29yZCxcclxuICAgIHZhbGlkYXRlOiAoc2Vzc2lvblN0b3JhZ2U6IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB8IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZVtdKSA9PiB7XHJcbiAgICAgIHNlc3Npb25TdG9yYWdlID0gc2Vzc2lvblN0b3JhZ2UgYXMgU2VjdXJpdHlTZXNzaW9uQ29va2llO1xyXG4gICAgICBpZiAoc2Vzc2lvblN0b3JhZ2UgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHJldHVybiB7IGlzVmFsaWQ6IGZhbHNlLCBwYXRoOiAnLycgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gVE9ETzogd2l0aCBzZXR0aW5nIHJlZGlyZWN0IGF0dHJpYnV0ZXMgdG8gc3VwcG9ydCBPSURDIGFuZCBTQU1MLFxyXG4gICAgICAvLyAgICAgICB3ZSBuZWVkIHRvIGRvIGFkZGl0b25hbCBjb29raWUgdmFsaWRhdGluIGluIEF1dGhlbnRpY2F0aW9uSGFuZGxlcnMuXHJcbiAgICAgIC8vIGlmIFNBTUwgZmllbGRzIHByZXNlbnRcclxuICAgICAgaWYgKHNlc3Npb25TdG9yYWdlLnNhbWwgJiYgc2Vzc2lvblN0b3JhZ2Uuc2FtbC5yZXF1ZXN0SWQgJiYgc2Vzc2lvblN0b3JhZ2Uuc2FtbC5uZXh0VXJsKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgaXNWYWxpZDogdHJ1ZSwgcGF0aDogJy8nIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIGlmIE9JREMgZmllbGRzIHByZXNlbnRcclxuICAgICAgaWYgKHNlc3Npb25TdG9yYWdlLm9pZGMpIHtcclxuICAgICAgICByZXR1cm4geyBpc1ZhbGlkOiB0cnVlLCBwYXRoOiAnLycgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHNlc3Npb25TdG9yYWdlLmV4cGlyeVRpbWUgPT09IHVuZGVmaW5lZCB8fCBzZXNzaW9uU3RvcmFnZS5leHBpcnlUaW1lIDwgRGF0ZS5ub3coKSkge1xyXG4gICAgICAgIHJldHVybiB7IGlzVmFsaWQ6IGZhbHNlLCBwYXRoOiAnLycgfTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4geyBpc1ZhbGlkOiB0cnVlLCBwYXRoOiAnLycgfTtcclxuICAgIH0sXHJcbiAgICBpc1NlY3VyZTogY29uZmlnLmNvb2tpZS5zZWN1cmUsXHJcbiAgICBzYW1lU2l0ZTogY29uZmlnLmNvb2tpZS5pc1NhbWVTaXRlIHx8IHVuZGVmaW5lZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJPbGRWZXJzaW9uQ29va2llVmFsdWUoY29uZmlnOiBTZWN1cml0eVBsdWdpbkNvbmZpZ1R5cGUpOiBzdHJpbmcge1xyXG4gIGlmIChjb25maWcuY29va2llLnNlY3VyZSkge1xyXG4gICAgcmV0dXJuICdzZWN1cml0eV9hdXRoZW50aWNhdGlvbj07IE1heC1BZ2U9MDsgRXhwaXJlcz1UaHUsIDAxIEphbiAxOTcwIDAwOjAwOjAwIEdNVDsgU2VjdXJlOyBIdHRwT25seTsgUGF0aD0vJztcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuICdzZWN1cml0eV9hdXRoZW50aWNhdGlvbj07IE1heC1BZ2U9MDsgRXhwaXJlcz1UaHUsIDAxIEphbiAxOTcwIDAwOjAwOjAwIEdNVDsgSHR0cE9ubHk7IFBhdGg9Lyc7XHJcbiAgfVxyXG59XHJcbiJdfQ==