"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SamlAuthRoutes = void 0;

var _configSchema = require("@osd/config-schema");

var _next_url = require("../../../utils/next_url");

var _common = require("../../../../common");

var _cookie_splitter = require("../../../session/cookie_splitter");

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
class SamlAuthRoutes {
  constructor(router, // @ts-ignore: unused variable
  config, sessionStorageFactory, securityClient, coreSetup) {
    this.router = router;
    this.config = config;
    this.sessionStorageFactory = sessionStorageFactory;
    this.securityClient = securityClient;
    this.coreSetup = coreSetup;
  }

  getExtraAuthStorageOptions(logger) {
    // If we're here, we will always have the openid configuration
    return {
      cookiePrefix: this.config.saml.extra_storage.cookie_prefix,
      additionalCookies: this.config.saml.extra_storage.additional_cookies,
      logger
    };
  }

  setupRoutes() {
    this.router.get({
      path: _common.SAML_AUTH_LOGIN,
      validate: {
        query: _configSchema.schema.object({
          nextUrl: _configSchema.schema.maybe(_configSchema.schema.string({
            validate: _next_url.validateNextUrl
          })),
          redirectHash: _configSchema.schema.string()
        })
      },
      options: {
        authRequired: false
      }
    }, async (context, request, response) => {
      if (request.auth.isAuthenticated) {
        return response.redirected({
          headers: {
            location: `${this.coreSetup.http.basePath.serverBasePath}/app/opensearch-dashboards`
          }
        });
      }

      try {
        const samlHeader = await this.securityClient.getSamlHeader(request); // const { nextUrl = '/' } = request.query;

        const cookie = {
          saml: {
            nextUrl: request.query.nextUrl,
            requestId: samlHeader.requestId,
            redirectHash: request.query.redirectHash === 'true'
          }
        };
        this.sessionStorageFactory.asScoped(request).set(cookie);
        return response.redirected({
          headers: {
            location: samlHeader.location
          }
        });
      } catch (error) {
        context.security_plugin.logger.error(`Failed to get saml header: ${error}`);
        return response.internalError(); // TODO: redirect to error page?
      }
    });
    this.router.post({
      path: `/_opendistro/_security/saml/acs`,
      validate: {
        body: _configSchema.schema.any()
      },
      options: {
        authRequired: false
      }
    }, async (context, request, response) => {
      let requestId = '';
      let nextUrl = '/';
      let redirectHash = false;

      try {
        const cookie = await this.sessionStorageFactory.asScoped(request).get();

        if (cookie) {
          var _cookie$saml, _cookie$saml2, _cookie$saml3;

          requestId = ((_cookie$saml = cookie.saml) === null || _cookie$saml === void 0 ? void 0 : _cookie$saml.requestId) || '';
          nextUrl = ((_cookie$saml2 = cookie.saml) === null || _cookie$saml2 === void 0 ? void 0 : _cookie$saml2.nextUrl) || `${this.coreSetup.http.basePath.serverBasePath}/app/opensearch-dashboards`;
          redirectHash = ((_cookie$saml3 = cookie.saml) === null || _cookie$saml3 === void 0 ? void 0 : _cookie$saml3.redirectHash) || false;
        }

        if (!requestId) {
          return response.badRequest({
            body: 'Invalid requestId'
          });
        }
      } catch (error) {
        context.security_plugin.logger.error(`Failed to parse cookie: ${error}`);
        return response.badRequest();
      }

      try {
        const credentials = await this.securityClient.authToken(requestId, request.body.SAMLResponse, undefined);
        const user = await this.securityClient.authenticateWithHeader(request, 'authorization', credentials.authorization);
        let expiryTime = Date.now() + this.config.session.ttl;
        const [headerEncoded, payloadEncoded, signature] = credentials.authorization.split('.');

        if (!payloadEncoded) {
          context.security_plugin.logger.error('JWT token payload not found');
        }

        const tokenPayload = JSON.parse(Buffer.from(payloadEncoded, 'base64').toString());

        if (tokenPayload.exp) {
          expiryTime = parseInt(tokenPayload.exp, 10) * 1000;
        }

        const cookie = {
          username: user.username,
          credentials: {
            authHeaderValueExtra: true
          },
          authType: _common.AuthType.SAML,
          // TODO: create constant
          expiryTime
        };
        (0, _cookie_splitter.setExtraAuthStorage)(request, credentials.authorization, this.getExtraAuthStorageOptions(context.security_plugin.logger));
        this.sessionStorageFactory.asScoped(request).set(cookie);

        if (redirectHash) {
          return response.redirected({
            headers: {
              location: `${this.coreSetup.http.basePath.serverBasePath}/auth/saml/redirectUrlFragment?nextUrl=${escape(nextUrl)}`
            }
          });
        } else {
          return response.redirected({
            headers: {
              location: nextUrl
            }
          });
        }
      } catch (error) {
        context.security_plugin.logger.error(`SAML SP initiated authentication workflow failed: ${error}`);
      }

      return response.internalError();
    });
    this.router.post({
      path: `/_opendistro/_security/saml/acs/idpinitiated`,
      validate: {
        body: _configSchema.schema.any()
      },
      options: {
        authRequired: false
      }
    }, async (context, request, response) => {
      const acsEndpoint = `${this.coreSetup.http.basePath.serverBasePath}/_opendistro/_security/saml/acs/idpinitiated`;

      try {
        const credentials = await this.securityClient.authToken(undefined, request.body.SAMLResponse, acsEndpoint);
        const user = await this.securityClient.authenticateWithHeader(request, 'authorization', credentials.authorization);
        let expiryTime = Date.now() + this.config.session.ttl;
        const [headerEncoded, payloadEncoded, signature] = credentials.authorization.split('.');

        if (!payloadEncoded) {
          context.security_plugin.logger.error('JWT token payload not found');
        }

        const tokenPayload = JSON.parse(Buffer.from(payloadEncoded, 'base64').toString());

        if (tokenPayload.exp) {
          expiryTime = parseInt(tokenPayload.exp, 10) * 1000;
        }

        const cookie = {
          username: user.username,
          credentials: {
            authHeaderValueExtra: true
          },
          authType: _common.AuthType.SAML,
          // TODO: create constant
          expiryTime
        };
        (0, _cookie_splitter.setExtraAuthStorage)(request, credentials.authorization, this.getExtraAuthStorageOptions(context.security_plugin.logger));
        this.sessionStorageFactory.asScoped(request).set(cookie);
        return response.redirected({
          headers: {
            location: `${this.coreSetup.http.basePath.serverBasePath}/app/opensearch-dashboards`
          }
        });
      } catch (error) {
        context.security_plugin.logger.error(`SAML IDP initiated authentication workflow failed: ${error}`);
      }

      return response.internalError();
    }); // captureUrlFragment is the first route that will be invoked in the SP initiated login.
    // This route will execute the captureUrlFragment.js script.

    this.coreSetup.http.resources.register({
      path: '/auth/saml/captureUrlFragment',
      validate: {
        query: _configSchema.schema.object({
          nextUrl: _configSchema.schema.maybe(_configSchema.schema.string({
            validate: _next_url.validateNextUrl
          }))
        })
      },
      options: {
        authRequired: false
      }
    }, async (context, request, response) => {
      this.sessionStorageFactory.asScoped(request).clear();
      const serverBasePath = this.coreSetup.http.basePath.serverBasePath;
      return response.renderHtml({
        body: `
            <!DOCTYPE html>
            <title>OSD SAML Capture</title>
            <link rel="icon" href="data:,">
            <script src="${serverBasePath}/auth/saml/captureUrlFragment.js"></script>
          `
      });
    }); // This script will store the URL Hash in browser's local storage.

    this.coreSetup.http.resources.register({
      path: '/auth/saml/captureUrlFragment.js',
      validate: false,
      options: {
        authRequired: false
      }
    }, async (context, request, response) => {
      this.sessionStorageFactory.asScoped(request).clear();
      return response.renderJs({
        body: `let samlHash=window.location.hash.toString();
                 let redirectHash = false;
                 if (samlHash !== "") {
                    window.localStorage.removeItem('samlHash');
                    window.localStorage.setItem('samlHash', samlHash);
                     redirectHash = true;
                  }
                 let params = new URLSearchParams(window.location.search);
                 let nextUrl = params.get("nextUrl");
                 finalUrl = "login?nextUrl=" + encodeURIComponent(nextUrl);
                 finalUrl += "&redirectHash=" + encodeURIComponent(redirectHash);
                 window.location.replace(finalUrl);
                `
      });
    }); //  Once the User is authenticated via the '_opendistro/_security/saml/acs' route,
    //  the browser will be redirected to '/auth/saml/redirectUrlFragment' route,
    //  which will execute the redirectUrlFragment.js.

    this.coreSetup.http.resources.register({
      path: '/auth/saml/redirectUrlFragment',
      validate: {
        query: _configSchema.schema.object({
          nextUrl: _configSchema.schema.any()
        })
      },
      options: {
        authRequired: true
      }
    }, async (context, request, response) => {
      const serverBasePath = this.coreSetup.http.basePath.serverBasePath;
      return response.renderHtml({
        body: `
            <!DOCTYPE html>
            <title>OSD SAML Success</title>
            <link rel="icon" href="data:,">
            <script src="${serverBasePath}/auth/saml/redirectUrlFragment.js"></script>
          `
      });
    }); // This script will pop the Hash from local storage if it exists.
    // And forward the browser to the next url.

    this.coreSetup.http.resources.register({
      path: '/auth/saml/redirectUrlFragment.js',
      validate: false,
      options: {
        authRequired: true
      }
    }, async (context, request, response) => {
      return response.renderJs({
        body: `let samlHash=window.localStorage.getItem('samlHash');
                 window.localStorage.removeItem('samlHash');
                 let params = new URLSearchParams(window.location.search);
                 let nextUrl = params.get("nextUrl");
                 finalUrl = nextUrl + samlHash;
                 window.location.replace(finalUrl);
                `
      });
    });
    this.router.get({
      path: _common.SAML_AUTH_LOGOUT,
      validate: false
    }, async (context, request, response) => {
      try {
        const authInfo = await this.securityClient.authinfo(request);
        await (0, _cookie_splitter.clearSplitCookies)(request, this.getExtraAuthStorageOptions(context.security_plugin.logger));
        this.sessionStorageFactory.asScoped(request).clear(); // TODO: need a default logout page

        const redirectUrl = authInfo.sso_logout_url || this.coreSetup.http.basePath.serverBasePath || '/';
        return response.redirected({
          headers: {
            location: redirectUrl
          }
        });
      } catch (error) {
        context.security_plugin.logger.error(`SAML logout failed: ${error}`);
        return response.badRequest();
      }
    });
  }

}

exports.SamlAuthRoutes = SamlAuthRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdXRlcy50cyJdLCJuYW1lcyI6WyJTYW1sQXV0aFJvdXRlcyIsImNvbnN0cnVjdG9yIiwicm91dGVyIiwiY29uZmlnIiwic2Vzc2lvblN0b3JhZ2VGYWN0b3J5Iiwic2VjdXJpdHlDbGllbnQiLCJjb3JlU2V0dXAiLCJnZXRFeHRyYUF1dGhTdG9yYWdlT3B0aW9ucyIsImxvZ2dlciIsImNvb2tpZVByZWZpeCIsInNhbWwiLCJleHRyYV9zdG9yYWdlIiwiY29va2llX3ByZWZpeCIsImFkZGl0aW9uYWxDb29raWVzIiwiYWRkaXRpb25hbF9jb29raWVzIiwic2V0dXBSb3V0ZXMiLCJnZXQiLCJwYXRoIiwiU0FNTF9BVVRIX0xPR0lOIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsIm5leHRVcmwiLCJtYXliZSIsInN0cmluZyIsInZhbGlkYXRlTmV4dFVybCIsInJlZGlyZWN0SGFzaCIsIm9wdGlvbnMiLCJhdXRoUmVxdWlyZWQiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiYXV0aCIsImlzQXV0aGVudGljYXRlZCIsInJlZGlyZWN0ZWQiLCJoZWFkZXJzIiwibG9jYXRpb24iLCJodHRwIiwiYmFzZVBhdGgiLCJzZXJ2ZXJCYXNlUGF0aCIsInNhbWxIZWFkZXIiLCJnZXRTYW1sSGVhZGVyIiwiY29va2llIiwicmVxdWVzdElkIiwiYXNTY29wZWQiLCJzZXQiLCJlcnJvciIsInNlY3VyaXR5X3BsdWdpbiIsImludGVybmFsRXJyb3IiLCJwb3N0IiwiYm9keSIsImFueSIsImJhZFJlcXVlc3QiLCJjcmVkZW50aWFscyIsImF1dGhUb2tlbiIsIlNBTUxSZXNwb25zZSIsInVuZGVmaW5lZCIsInVzZXIiLCJhdXRoZW50aWNhdGVXaXRoSGVhZGVyIiwiYXV0aG9yaXphdGlvbiIsImV4cGlyeVRpbWUiLCJEYXRlIiwibm93Iiwic2Vzc2lvbiIsInR0bCIsImhlYWRlckVuY29kZWQiLCJwYXlsb2FkRW5jb2RlZCIsInNpZ25hdHVyZSIsInNwbGl0IiwidG9rZW5QYXlsb2FkIiwiSlNPTiIsInBhcnNlIiwiQnVmZmVyIiwiZnJvbSIsInRvU3RyaW5nIiwiZXhwIiwicGFyc2VJbnQiLCJ1c2VybmFtZSIsImF1dGhIZWFkZXJWYWx1ZUV4dHJhIiwiYXV0aFR5cGUiLCJBdXRoVHlwZSIsIlNBTUwiLCJlc2NhcGUiLCJhY3NFbmRwb2ludCIsInJlc291cmNlcyIsInJlZ2lzdGVyIiwiY2xlYXIiLCJyZW5kZXJIdG1sIiwicmVuZGVySnMiLCJTQU1MX0FVVEhfTE9HT1VUIiwiYXV0aEluZm8iLCJhdXRoaW5mbyIsInJlZGlyZWN0VXJsIiwic3NvX2xvZ291dF91cmwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFlQTs7QUFNQTs7QUFDQTs7QUFFQTs7QUF4QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWlCTyxNQUFNQSxjQUFOLENBQXFCO0FBQzFCQyxFQUFBQSxXQUFXLENBQ1FDLE1BRFIsRUFFVDtBQUNpQkMsRUFBQUEsTUFIUixFQUlRQyxxQkFKUixFQUtRQyxjQUxSLEVBTVFDLFNBTlIsRUFPVDtBQUFBLFNBTmlCSixNQU1qQixHQU5pQkEsTUFNakI7QUFBQSxTQUppQkMsTUFJakIsR0FKaUJBLE1BSWpCO0FBQUEsU0FIaUJDLHFCQUdqQixHQUhpQkEscUJBR2pCO0FBQUEsU0FGaUJDLGNBRWpCLEdBRmlCQSxjQUVqQjtBQUFBLFNBRGlCQyxTQUNqQixHQURpQkEsU0FDakI7QUFBRTs7QUFFSUMsRUFBQUEsMEJBQTBCLENBQUNDLE1BQUQsRUFBMkM7QUFDM0U7QUFDQSxXQUFPO0FBQ0xDLE1BQUFBLFlBQVksRUFBRSxLQUFLTixNQUFMLENBQVlPLElBQVosQ0FBaUJDLGFBQWpCLENBQStCQyxhQUR4QztBQUVMQyxNQUFBQSxpQkFBaUIsRUFBRSxLQUFLVixNQUFMLENBQVlPLElBQVosQ0FBaUJDLGFBQWpCLENBQStCRyxrQkFGN0M7QUFHTE4sTUFBQUE7QUFISyxLQUFQO0FBS0Q7O0FBRU1PLEVBQUFBLFdBQVcsR0FBRztBQUNuQixTQUFLYixNQUFMLENBQVljLEdBQVosQ0FDRTtBQUNFQyxNQUFBQSxJQUFJLEVBQUVDLHVCQURSO0FBRUVDLE1BQUFBLFFBQVEsRUFBRTtBQUNSQyxRQUFBQSxLQUFLLEVBQUVDLHFCQUFPQyxNQUFQLENBQWM7QUFDbkJDLFVBQUFBLE9BQU8sRUFBRUYscUJBQU9HLEtBQVAsQ0FDUEgscUJBQU9JLE1BQVAsQ0FBYztBQUNaTixZQUFBQSxRQUFRLEVBQUVPO0FBREUsV0FBZCxDQURPLENBRFU7QUFNbkJDLFVBQUFBLFlBQVksRUFBRU4scUJBQU9JLE1BQVA7QUFOSyxTQUFkO0FBREMsT0FGWjtBQVlFRyxNQUFBQSxPQUFPLEVBQUU7QUFDUEMsUUFBQUEsWUFBWSxFQUFFO0FBRFA7QUFaWCxLQURGLEVBaUJFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFJRCxPQUFPLENBQUNFLElBQVIsQ0FBYUMsZUFBakIsRUFBa0M7QUFDaEMsZUFBT0YsUUFBUSxDQUFDRyxVQUFULENBQW9CO0FBQ3pCQyxVQUFBQSxPQUFPLEVBQUU7QUFDUEMsWUFBQUEsUUFBUSxFQUFHLEdBQUUsS0FBSy9CLFNBQUwsQ0FBZWdDLElBQWYsQ0FBb0JDLFFBQXBCLENBQTZCQyxjQUFlO0FBRGxEO0FBRGdCLFNBQXBCLENBQVA7QUFLRDs7QUFFRCxVQUFJO0FBQ0YsY0FBTUMsVUFBVSxHQUFHLE1BQU0sS0FBS3BDLGNBQUwsQ0FBb0JxQyxhQUFwQixDQUFrQ1gsT0FBbEMsQ0FBekIsQ0FERSxDQUVGOztBQUNBLGNBQU1ZLE1BQTZCLEdBQUc7QUFDcENqQyxVQUFBQSxJQUFJLEVBQUU7QUFDSmEsWUFBQUEsT0FBTyxFQUFFUSxPQUFPLENBQUNYLEtBQVIsQ0FBY0csT0FEbkI7QUFFSnFCLFlBQUFBLFNBQVMsRUFBRUgsVUFBVSxDQUFDRyxTQUZsQjtBQUdKakIsWUFBQUEsWUFBWSxFQUFFSSxPQUFPLENBQUNYLEtBQVIsQ0FBY08sWUFBZCxLQUErQjtBQUh6QztBQUQ4QixTQUF0QztBQU9BLGFBQUt2QixxQkFBTCxDQUEyQnlDLFFBQTNCLENBQW9DZCxPQUFwQyxFQUE2Q2UsR0FBN0MsQ0FBaURILE1BQWpEO0FBQ0EsZUFBT1gsUUFBUSxDQUFDRyxVQUFULENBQW9CO0FBQ3pCQyxVQUFBQSxPQUFPLEVBQUU7QUFDUEMsWUFBQUEsUUFBUSxFQUFFSSxVQUFVLENBQUNKO0FBRGQ7QUFEZ0IsU0FBcEIsQ0FBUDtBQUtELE9BaEJELENBZ0JFLE9BQU9VLEtBQVAsRUFBYztBQUNkakIsUUFBQUEsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhCLENBQStCdUMsS0FBL0IsQ0FBc0MsOEJBQTZCQSxLQUFNLEVBQXpFO0FBQ0EsZUFBT2YsUUFBUSxDQUFDaUIsYUFBVCxFQUFQLENBRmMsQ0FFbUI7QUFDbEM7QUFDRixLQTlDSDtBQWlEQSxTQUFLL0MsTUFBTCxDQUFZZ0QsSUFBWixDQUNFO0FBQ0VqQyxNQUFBQSxJQUFJLEVBQUcsaUNBRFQ7QUFFRUUsTUFBQUEsUUFBUSxFQUFFO0FBQ1JnQyxRQUFBQSxJQUFJLEVBQUU5QixxQkFBTytCLEdBQVA7QUFERSxPQUZaO0FBS0V4QixNQUFBQSxPQUFPLEVBQUU7QUFDUEMsUUFBQUEsWUFBWSxFQUFFO0FBRFA7QUFMWCxLQURGLEVBVUUsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQUlZLFNBQWlCLEdBQUcsRUFBeEI7QUFDQSxVQUFJckIsT0FBZSxHQUFHLEdBQXRCO0FBQ0EsVUFBSUksWUFBcUIsR0FBRyxLQUE1Qjs7QUFDQSxVQUFJO0FBQ0YsY0FBTWdCLE1BQU0sR0FBRyxNQUFNLEtBQUt2QyxxQkFBTCxDQUEyQnlDLFFBQTNCLENBQW9DZCxPQUFwQyxFQUE2Q2YsR0FBN0MsRUFBckI7O0FBQ0EsWUFBSTJCLE1BQUosRUFBWTtBQUFBOztBQUNWQyxVQUFBQSxTQUFTLEdBQUcsaUJBQUFELE1BQU0sQ0FBQ2pDLElBQVAsOERBQWFrQyxTQUFiLEtBQTBCLEVBQXRDO0FBQ0FyQixVQUFBQSxPQUFPLEdBQ0wsa0JBQUFvQixNQUFNLENBQUNqQyxJQUFQLGdFQUFhYSxPQUFiLEtBQ0MsR0FBRSxLQUFLakIsU0FBTCxDQUFlZ0MsSUFBZixDQUFvQkMsUUFBcEIsQ0FBNkJDLGNBQWUsNEJBRmpEO0FBR0FiLFVBQUFBLFlBQVksR0FBRyxrQkFBQWdCLE1BQU0sQ0FBQ2pDLElBQVAsZ0VBQWFpQixZQUFiLEtBQTZCLEtBQTVDO0FBQ0Q7O0FBQ0QsWUFBSSxDQUFDaUIsU0FBTCxFQUFnQjtBQUNkLGlCQUFPWixRQUFRLENBQUNxQixVQUFULENBQW9CO0FBQ3pCRixZQUFBQSxJQUFJLEVBQUU7QUFEbUIsV0FBcEIsQ0FBUDtBQUdEO0FBQ0YsT0FkRCxDQWNFLE9BQU9KLEtBQVAsRUFBYztBQUNkakIsUUFBQUEsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhCLENBQStCdUMsS0FBL0IsQ0FBc0MsMkJBQTBCQSxLQUFNLEVBQXRFO0FBQ0EsZUFBT2YsUUFBUSxDQUFDcUIsVUFBVCxFQUFQO0FBQ0Q7O0FBRUQsVUFBSTtBQUNGLGNBQU1DLFdBQVcsR0FBRyxNQUFNLEtBQUtqRCxjQUFMLENBQW9Ca0QsU0FBcEIsQ0FDeEJYLFNBRHdCLEVBRXhCYixPQUFPLENBQUNvQixJQUFSLENBQWFLLFlBRlcsRUFHeEJDLFNBSHdCLENBQTFCO0FBS0EsY0FBTUMsSUFBSSxHQUFHLE1BQU0sS0FBS3JELGNBQUwsQ0FBb0JzRCxzQkFBcEIsQ0FDakI1QixPQURpQixFQUVqQixlQUZpQixFQUdqQnVCLFdBQVcsQ0FBQ00sYUFISyxDQUFuQjtBQU1BLFlBQUlDLFVBQVUsR0FBR0MsSUFBSSxDQUFDQyxHQUFMLEtBQWEsS0FBSzVELE1BQUwsQ0FBWTZELE9BQVosQ0FBb0JDLEdBQWxEO0FBQ0EsY0FBTSxDQUFDQyxhQUFELEVBQWdCQyxjQUFoQixFQUFnQ0MsU0FBaEMsSUFBNkNkLFdBQVcsQ0FBQ00sYUFBWixDQUEwQlMsS0FBMUIsQ0FBZ0MsR0FBaEMsQ0FBbkQ7O0FBQ0EsWUFBSSxDQUFDRixjQUFMLEVBQXFCO0FBQ25CckMsVUFBQUEsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhCLENBQStCdUMsS0FBL0IsQ0FBcUMsNkJBQXJDO0FBQ0Q7O0FBQ0QsY0FBTXVCLFlBQVksR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZUCxjQUFaLEVBQTRCLFFBQTVCLEVBQXNDUSxRQUF0QyxFQUFYLENBQXJCOztBQUVBLFlBQUlMLFlBQVksQ0FBQ00sR0FBakIsRUFBc0I7QUFDcEJmLFVBQUFBLFVBQVUsR0FBR2dCLFFBQVEsQ0FBQ1AsWUFBWSxDQUFDTSxHQUFkLEVBQW1CLEVBQW5CLENBQVIsR0FBaUMsSUFBOUM7QUFDRDs7QUFFRCxjQUFNakMsTUFBNkIsR0FBRztBQUNwQ21DLFVBQUFBLFFBQVEsRUFBRXBCLElBQUksQ0FBQ29CLFFBRHFCO0FBRXBDeEIsVUFBQUEsV0FBVyxFQUFFO0FBQ1h5QixZQUFBQSxvQkFBb0IsRUFBRTtBQURYLFdBRnVCO0FBS3BDQyxVQUFBQSxRQUFRLEVBQUVDLGlCQUFTQyxJQUxpQjtBQUtYO0FBQ3pCckIsVUFBQUE7QUFOb0MsU0FBdEM7QUFTQSxrREFDRTlCLE9BREYsRUFFRXVCLFdBQVcsQ0FBQ00sYUFGZCxFQUdFLEtBQUtyRCwwQkFBTCxDQUFnQ3VCLE9BQU8sQ0FBQ2tCLGVBQVIsQ0FBd0J4QyxNQUF4RCxDQUhGO0FBTUEsYUFBS0oscUJBQUwsQ0FBMkJ5QyxRQUEzQixDQUFvQ2QsT0FBcEMsRUFBNkNlLEdBQTdDLENBQWlESCxNQUFqRDs7QUFFQSxZQUFJaEIsWUFBSixFQUFrQjtBQUNoQixpQkFBT0ssUUFBUSxDQUFDRyxVQUFULENBQW9CO0FBQ3pCQyxZQUFBQSxPQUFPLEVBQUU7QUFDUEMsY0FBQUEsUUFBUSxFQUFHLEdBQ1QsS0FBSy9CLFNBQUwsQ0FBZWdDLElBQWYsQ0FBb0JDLFFBQXBCLENBQTZCQyxjQUM5QiwwQ0FBeUMyQyxNQUFNLENBQUM1RCxPQUFELENBQVU7QUFIbkQ7QUFEZ0IsV0FBcEIsQ0FBUDtBQU9ELFNBUkQsTUFRTztBQUNMLGlCQUFPUyxRQUFRLENBQUNHLFVBQVQsQ0FBb0I7QUFDekJDLFlBQUFBLE9BQU8sRUFBRTtBQUNQQyxjQUFBQSxRQUFRLEVBQUVkO0FBREg7QUFEZ0IsV0FBcEIsQ0FBUDtBQUtEO0FBQ0YsT0F2REQsQ0F1REUsT0FBT3dCLEtBQVAsRUFBYztBQUNkakIsUUFBQUEsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhCLENBQStCdUMsS0FBL0IsQ0FDRyxxREFBb0RBLEtBQU0sRUFEN0Q7QUFHRDs7QUFFRCxhQUFPZixRQUFRLENBQUNpQixhQUFULEVBQVA7QUFDRCxLQS9GSDtBQWtHQSxTQUFLL0MsTUFBTCxDQUFZZ0QsSUFBWixDQUNFO0FBQ0VqQyxNQUFBQSxJQUFJLEVBQUcsOENBRFQ7QUFFRUUsTUFBQUEsUUFBUSxFQUFFO0FBQ1JnQyxRQUFBQSxJQUFJLEVBQUU5QixxQkFBTytCLEdBQVA7QUFERSxPQUZaO0FBS0V4QixNQUFBQSxPQUFPLEVBQUU7QUFDUEMsUUFBQUEsWUFBWSxFQUFFO0FBRFA7QUFMWCxLQURGLEVBVUUsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFlBQU1vRCxXQUFXLEdBQUksR0FBRSxLQUFLOUUsU0FBTCxDQUFlZ0MsSUFBZixDQUFvQkMsUUFBcEIsQ0FBNkJDLGNBQWUsOENBQW5FOztBQUNBLFVBQUk7QUFDRixjQUFNYyxXQUFXLEdBQUcsTUFBTSxLQUFLakQsY0FBTCxDQUFvQmtELFNBQXBCLENBQ3hCRSxTQUR3QixFQUV4QjFCLE9BQU8sQ0FBQ29CLElBQVIsQ0FBYUssWUFGVyxFQUd4QjRCLFdBSHdCLENBQTFCO0FBS0EsY0FBTTFCLElBQUksR0FBRyxNQUFNLEtBQUtyRCxjQUFMLENBQW9Cc0Qsc0JBQXBCLENBQ2pCNUIsT0FEaUIsRUFFakIsZUFGaUIsRUFHakJ1QixXQUFXLENBQUNNLGFBSEssQ0FBbkI7QUFNQSxZQUFJQyxVQUFVLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxLQUFhLEtBQUs1RCxNQUFMLENBQVk2RCxPQUFaLENBQW9CQyxHQUFsRDtBQUNBLGNBQU0sQ0FBQ0MsYUFBRCxFQUFnQkMsY0FBaEIsRUFBZ0NDLFNBQWhDLElBQTZDZCxXQUFXLENBQUNNLGFBQVosQ0FBMEJTLEtBQTFCLENBQWdDLEdBQWhDLENBQW5EOztBQUNBLFlBQUksQ0FBQ0YsY0FBTCxFQUFxQjtBQUNuQnJDLFVBQUFBLE9BQU8sQ0FBQ2tCLGVBQVIsQ0FBd0J4QyxNQUF4QixDQUErQnVDLEtBQS9CLENBQXFDLDZCQUFyQztBQUNEOztBQUNELGNBQU11QixZQUFZLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWVAsY0FBWixFQUE0QixRQUE1QixFQUFzQ1EsUUFBdEMsRUFBWCxDQUFyQjs7QUFDQSxZQUFJTCxZQUFZLENBQUNNLEdBQWpCLEVBQXNCO0FBQ3BCZixVQUFBQSxVQUFVLEdBQUdnQixRQUFRLENBQUNQLFlBQVksQ0FBQ00sR0FBZCxFQUFtQixFQUFuQixDQUFSLEdBQWlDLElBQTlDO0FBQ0Q7O0FBRUQsY0FBTWpDLE1BQTZCLEdBQUc7QUFDcENtQyxVQUFBQSxRQUFRLEVBQUVwQixJQUFJLENBQUNvQixRQURxQjtBQUVwQ3hCLFVBQUFBLFdBQVcsRUFBRTtBQUNYeUIsWUFBQUEsb0JBQW9CLEVBQUU7QUFEWCxXQUZ1QjtBQUtwQ0MsVUFBQUEsUUFBUSxFQUFFQyxpQkFBU0MsSUFMaUI7QUFLWDtBQUN6QnJCLFVBQUFBO0FBTm9DLFNBQXRDO0FBU0Esa0RBQ0U5QixPQURGLEVBRUV1QixXQUFXLENBQUNNLGFBRmQsRUFHRSxLQUFLckQsMEJBQUwsQ0FBZ0N1QixPQUFPLENBQUNrQixlQUFSLENBQXdCeEMsTUFBeEQsQ0FIRjtBQU1BLGFBQUtKLHFCQUFMLENBQTJCeUMsUUFBM0IsQ0FBb0NkLE9BQXBDLEVBQTZDZSxHQUE3QyxDQUFpREgsTUFBakQ7QUFDQSxlQUFPWCxRQUFRLENBQUNHLFVBQVQsQ0FBb0I7QUFDekJDLFVBQUFBLE9BQU8sRUFBRTtBQUNQQyxZQUFBQSxRQUFRLEVBQUcsR0FBRSxLQUFLL0IsU0FBTCxDQUFlZ0MsSUFBZixDQUFvQkMsUUFBcEIsQ0FBNkJDLGNBQWU7QUFEbEQ7QUFEZ0IsU0FBcEIsQ0FBUDtBQUtELE9BM0NELENBMkNFLE9BQU9PLEtBQVAsRUFBYztBQUNkakIsUUFBQUEsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhCLENBQStCdUMsS0FBL0IsQ0FDRyxzREFBcURBLEtBQU0sRUFEOUQ7QUFHRDs7QUFDRCxhQUFPZixRQUFRLENBQUNpQixhQUFULEVBQVA7QUFDRCxLQTdESCxFQXBKbUIsQ0FvTm5CO0FBQ0E7O0FBQ0EsU0FBSzNDLFNBQUwsQ0FBZWdDLElBQWYsQ0FBb0IrQyxTQUFwQixDQUE4QkMsUUFBOUIsQ0FDRTtBQUNFckUsTUFBQUEsSUFBSSxFQUFFLCtCQURSO0FBRUVFLE1BQUFBLFFBQVEsRUFBRTtBQUNSQyxRQUFBQSxLQUFLLEVBQUVDLHFCQUFPQyxNQUFQLENBQWM7QUFDbkJDLFVBQUFBLE9BQU8sRUFBRUYscUJBQU9HLEtBQVAsQ0FDUEgscUJBQU9JLE1BQVAsQ0FBYztBQUNaTixZQUFBQSxRQUFRLEVBQUVPO0FBREUsV0FBZCxDQURPO0FBRFUsU0FBZDtBQURDLE9BRlo7QUFXRUUsTUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFFBQUFBLFlBQVksRUFBRTtBQURQO0FBWFgsS0FERixFQWdCRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsV0FBSzVCLHFCQUFMLENBQTJCeUMsUUFBM0IsQ0FBb0NkLE9BQXBDLEVBQTZDd0QsS0FBN0M7QUFDQSxZQUFNL0MsY0FBYyxHQUFHLEtBQUtsQyxTQUFMLENBQWVnQyxJQUFmLENBQW9CQyxRQUFwQixDQUE2QkMsY0FBcEQ7QUFDQSxhQUFPUixRQUFRLENBQUN3RCxVQUFULENBQW9CO0FBQ3pCckMsUUFBQUEsSUFBSSxFQUFHO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQlgsY0FBZTtBQUMxQztBQU5tQyxPQUFwQixDQUFQO0FBUUQsS0EzQkgsRUF0Tm1CLENBb1BuQjs7QUFDQSxTQUFLbEMsU0FBTCxDQUFlZ0MsSUFBZixDQUFvQitDLFNBQXBCLENBQThCQyxRQUE5QixDQUNFO0FBQ0VyRSxNQUFBQSxJQUFJLEVBQUUsa0NBRFI7QUFFRUUsTUFBQUEsUUFBUSxFQUFFLEtBRlo7QUFHRVMsTUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFFBQUFBLFlBQVksRUFBRTtBQURQO0FBSFgsS0FERixFQVFFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxXQUFLNUIscUJBQUwsQ0FBMkJ5QyxRQUEzQixDQUFvQ2QsT0FBcEMsRUFBNkN3RCxLQUE3QztBQUNBLGFBQU92RCxRQUFRLENBQUN5RCxRQUFULENBQWtCO0FBQ3ZCdEMsUUFBQUEsSUFBSSxFQUFHO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWJpQyxPQUFsQixDQUFQO0FBZUQsS0F6QkgsRUFyUG1CLENBaVJuQjtBQUNBO0FBQ0E7O0FBQ0EsU0FBSzdDLFNBQUwsQ0FBZWdDLElBQWYsQ0FBb0IrQyxTQUFwQixDQUE4QkMsUUFBOUIsQ0FDRTtBQUNFckUsTUFBQUEsSUFBSSxFQUFFLGdDQURSO0FBRUVFLE1BQUFBLFFBQVEsRUFBRTtBQUNSQyxRQUFBQSxLQUFLLEVBQUVDLHFCQUFPQyxNQUFQLENBQWM7QUFDbkJDLFVBQUFBLE9BQU8sRUFBRUYscUJBQU8rQixHQUFQO0FBRFUsU0FBZDtBQURDLE9BRlo7QUFPRXhCLE1BQUFBLE9BQU8sRUFBRTtBQUNQQyxRQUFBQSxZQUFZLEVBQUU7QUFEUDtBQVBYLEtBREYsRUFZRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsWUFBTVEsY0FBYyxHQUFHLEtBQUtsQyxTQUFMLENBQWVnQyxJQUFmLENBQW9CQyxRQUFwQixDQUE2QkMsY0FBcEQ7QUFDQSxhQUFPUixRQUFRLENBQUN3RCxVQUFULENBQW9CO0FBQ3pCckMsUUFBQUEsSUFBSSxFQUFHO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQlgsY0FBZTtBQUMxQztBQU5tQyxPQUFwQixDQUFQO0FBUUQsS0F0QkgsRUFwUm1CLENBNlNuQjtBQUNBOztBQUNBLFNBQUtsQyxTQUFMLENBQWVnQyxJQUFmLENBQW9CK0MsU0FBcEIsQ0FBOEJDLFFBQTlCLENBQ0U7QUFDRXJFLE1BQUFBLElBQUksRUFBRSxtQ0FEUjtBQUVFRSxNQUFBQSxRQUFRLEVBQUUsS0FGWjtBQUdFUyxNQUFBQSxPQUFPLEVBQUU7QUFDUEMsUUFBQUEsWUFBWSxFQUFFO0FBRFA7QUFIWCxLQURGLEVBUUUsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLGFBQU9BLFFBQVEsQ0FBQ3lELFFBQVQsQ0FBa0I7QUFDdkJ0QyxRQUFBQSxJQUFJLEVBQUc7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUGlDLE9BQWxCLENBQVA7QUFTRCxLQWxCSDtBQXFCQSxTQUFLakQsTUFBTCxDQUFZYyxHQUFaLENBQ0U7QUFDRUMsTUFBQUEsSUFBSSxFQUFFeUUsd0JBRFI7QUFFRXZFLE1BQUFBLFFBQVEsRUFBRTtBQUZaLEtBREYsRUFLRSxPQUFPVyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsVUFBSTtBQUNGLGNBQU0yRCxRQUFRLEdBQUcsTUFBTSxLQUFLdEYsY0FBTCxDQUFvQnVGLFFBQXBCLENBQTZCN0QsT0FBN0IsQ0FBdkI7QUFDQSxjQUFNLHdDQUNKQSxPQURJLEVBRUosS0FBS3hCLDBCQUFMLENBQWdDdUIsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhELENBRkksQ0FBTjtBQUlBLGFBQUtKLHFCQUFMLENBQTJCeUMsUUFBM0IsQ0FBb0NkLE9BQXBDLEVBQTZDd0QsS0FBN0MsR0FORSxDQU9GOztBQUNBLGNBQU1NLFdBQVcsR0FDZkYsUUFBUSxDQUFDRyxjQUFULElBQTJCLEtBQUt4RixTQUFMLENBQWVnQyxJQUFmLENBQW9CQyxRQUFwQixDQUE2QkMsY0FBeEQsSUFBMEUsR0FENUU7QUFFQSxlQUFPUixRQUFRLENBQUNHLFVBQVQsQ0FBb0I7QUFDekJDLFVBQUFBLE9BQU8sRUFBRTtBQUNQQyxZQUFBQSxRQUFRLEVBQUV3RDtBQURIO0FBRGdCLFNBQXBCLENBQVA7QUFLRCxPQWZELENBZUUsT0FBTzlDLEtBQVAsRUFBYztBQUNkakIsUUFBQUEsT0FBTyxDQUFDa0IsZUFBUixDQUF3QnhDLE1BQXhCLENBQStCdUMsS0FBL0IsQ0FBc0MsdUJBQXNCQSxLQUFNLEVBQWxFO0FBQ0EsZUFBT2YsUUFBUSxDQUFDcUIsVUFBVCxFQUFQO0FBQ0Q7QUFDRixLQXpCSDtBQTJCRDs7QUFsWHlCIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcclxuICpcclxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxyXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cclxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxyXG4gKlxyXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuICpcclxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcclxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xyXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xyXG5pbXBvcnQgeyBJUm91dGVyLCBTZXNzaW9uU3RvcmFnZUZhY3RvcnksIExvZ2dlciB9IGZyb20gJy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XHJcbmltcG9ydCB7IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB9IGZyb20gJy4uLy4uLy4uL3Nlc3Npb24vc2VjdXJpdHlfY29va2llJztcclxuaW1wb3J0IHsgU2VjdXJpdHlQbHVnaW5Db25maWdUeXBlIH0gZnJvbSAnLi4vLi4vLi4nO1xyXG5pbXBvcnQgeyBTZWN1cml0eUNsaWVudCB9IGZyb20gJy4uLy4uLy4uL2JhY2tlbmQvb3BlbnNlYXJjaF9zZWN1cml0eV9jbGllbnQnO1xyXG5pbXBvcnQgeyBDb3JlU2V0dXAgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyB2YWxpZGF0ZU5leHRVcmwgfSBmcm9tICcuLi8uLi8uLi91dGlscy9uZXh0X3VybCc7XHJcbmltcG9ydCB7IEF1dGhUeXBlLCBTQU1MX0FVVEhfTE9HSU4sIFNBTUxfQVVUSF9MT0dPVVQgfSBmcm9tICcuLi8uLi8uLi8uLi9jb21tb24nO1xyXG5cclxuaW1wb3J0IHtcclxuICBjbGVhclNwbGl0Q29va2llcyxcclxuICBFeHRyYUF1dGhTdG9yYWdlT3B0aW9ucyxcclxuICBzZXRFeHRyYUF1dGhTdG9yYWdlLFxyXG59IGZyb20gJy4uLy4uLy4uL3Nlc3Npb24vY29va2llX3NwbGl0dGVyJztcclxuXHJcbmV4cG9ydCBjbGFzcyBTYW1sQXV0aFJvdXRlcyB7XHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IHJvdXRlcjogSVJvdXRlcixcclxuICAgIC8vIEB0cy1pZ25vcmU6IHVudXNlZCB2YXJpYWJsZVxyXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb25maWc6IFNlY3VyaXR5UGx1Z2luQ29uZmlnVHlwZSxcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgc2Vzc2lvblN0b3JhZ2VGYWN0b3J5OiBTZXNzaW9uU3RvcmFnZUZhY3Rvcnk8U2VjdXJpdHlTZXNzaW9uQ29va2llPixcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgc2VjdXJpdHlDbGllbnQ6IFNlY3VyaXR5Q2xpZW50LFxyXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb3JlU2V0dXA6IENvcmVTZXR1cFxyXG4gICkge31cclxuXHJcbiAgcHJpdmF0ZSBnZXRFeHRyYUF1dGhTdG9yYWdlT3B0aW9ucyhsb2dnZXI/OiBMb2dnZXIpOiBFeHRyYUF1dGhTdG9yYWdlT3B0aW9ucyB7XHJcbiAgICAvLyBJZiB3ZSdyZSBoZXJlLCB3ZSB3aWxsIGFsd2F5cyBoYXZlIHRoZSBvcGVuaWQgY29uZmlndXJhdGlvblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgY29va2llUHJlZml4OiB0aGlzLmNvbmZpZy5zYW1sLmV4dHJhX3N0b3JhZ2UuY29va2llX3ByZWZpeCxcclxuICAgICAgYWRkaXRpb25hbENvb2tpZXM6IHRoaXMuY29uZmlnLnNhbWwuZXh0cmFfc3RvcmFnZS5hZGRpdGlvbmFsX2Nvb2tpZXMsXHJcbiAgICAgIGxvZ2dlcixcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgc2V0dXBSb3V0ZXMoKSB7XHJcbiAgICB0aGlzLnJvdXRlci5nZXQoXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBTQU1MX0FVVEhfTE9HSU4sXHJcbiAgICAgICAgdmFsaWRhdGU6IHtcclxuICAgICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcclxuICAgICAgICAgICAgbmV4dFVybDogc2NoZW1hLm1heWJlKFxyXG4gICAgICAgICAgICAgIHNjaGVtYS5zdHJpbmcoe1xyXG4gICAgICAgICAgICAgICAgdmFsaWRhdGU6IHZhbGlkYXRlTmV4dFVybCxcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgICByZWRpcmVjdEhhc2g6IHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICAgIH0pLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb3B0aW9uczoge1xyXG4gICAgICAgICAgYXV0aFJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVxdWVzdC5hdXRoLmlzQXV0aGVudGljYXRlZCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlZGlyZWN0ZWQoe1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgbG9jYXRpb246IGAke3RoaXMuY29yZVNldHVwLmh0dHAuYmFzZVBhdGguc2VydmVyQmFzZVBhdGh9L2FwcC9vcGVuc2VhcmNoLWRhc2hib2FyZHNgLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3Qgc2FtbEhlYWRlciA9IGF3YWl0IHRoaXMuc2VjdXJpdHlDbGllbnQuZ2V0U2FtbEhlYWRlcihyZXF1ZXN0KTtcclxuICAgICAgICAgIC8vIGNvbnN0IHsgbmV4dFVybCA9ICcvJyB9ID0gcmVxdWVzdC5xdWVyeTtcclxuICAgICAgICAgIGNvbnN0IGNvb2tpZTogU2VjdXJpdHlTZXNzaW9uQ29va2llID0ge1xyXG4gICAgICAgICAgICBzYW1sOiB7XHJcbiAgICAgICAgICAgICAgbmV4dFVybDogcmVxdWVzdC5xdWVyeS5uZXh0VXJsLFxyXG4gICAgICAgICAgICAgIHJlcXVlc3RJZDogc2FtbEhlYWRlci5yZXF1ZXN0SWQsXHJcbiAgICAgICAgICAgICAgcmVkaXJlY3RIYXNoOiByZXF1ZXN0LnF1ZXJ5LnJlZGlyZWN0SGFzaCA9PT0gJ3RydWUnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIHRoaXMuc2Vzc2lvblN0b3JhZ2VGYWN0b3J5LmFzU2NvcGVkKHJlcXVlc3QpLnNldChjb29raWUpO1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlZGlyZWN0ZWQoe1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgbG9jYXRpb246IHNhbWxIZWFkZXIubG9jYXRpb24sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29udGV4dC5zZWN1cml0eV9wbHVnaW4ubG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gZ2V0IHNhbWwgaGVhZGVyOiAke2Vycm9yfWApO1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmludGVybmFsRXJyb3IoKTsgLy8gVE9ETzogcmVkaXJlY3QgdG8gZXJyb3IgcGFnZT9cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgdGhpcy5yb3V0ZXIucG9zdChcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IGAvX29wZW5kaXN0cm8vX3NlY3VyaXR5L3NhbWwvYWNzYCxcclxuICAgICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb3B0aW9uczoge1xyXG4gICAgICAgICAgYXV0aFJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgICBsZXQgcmVxdWVzdElkOiBzdHJpbmcgPSAnJztcclxuICAgICAgICBsZXQgbmV4dFVybDogc3RyaW5nID0gJy8nO1xyXG4gICAgICAgIGxldCByZWRpcmVjdEhhc2g6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgY29va2llID0gYXdhaXQgdGhpcy5zZXNzaW9uU3RvcmFnZUZhY3RvcnkuYXNTY29wZWQocmVxdWVzdCkuZ2V0KCk7XHJcbiAgICAgICAgICBpZiAoY29va2llKSB7XHJcbiAgICAgICAgICAgIHJlcXVlc3RJZCA9IGNvb2tpZS5zYW1sPy5yZXF1ZXN0SWQgfHwgJyc7XHJcbiAgICAgICAgICAgIG5leHRVcmwgPVxyXG4gICAgICAgICAgICAgIGNvb2tpZS5zYW1sPy5uZXh0VXJsIHx8XHJcbiAgICAgICAgICAgICAgYCR7dGhpcy5jb3JlU2V0dXAuaHR0cC5iYXNlUGF0aC5zZXJ2ZXJCYXNlUGF0aH0vYXBwL29wZW5zZWFyY2gtZGFzaGJvYXJkc2A7XHJcbiAgICAgICAgICAgIHJlZGlyZWN0SGFzaCA9IGNvb2tpZS5zYW1sPy5yZWRpcmVjdEhhc2ggfHwgZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBpZiAoIXJlcXVlc3RJZCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCh7XHJcbiAgICAgICAgICAgICAgYm9keTogJ0ludmFsaWQgcmVxdWVzdElkJyxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIHBhcnNlIGNvb2tpZTogJHtlcnJvcn1gKTtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgY3JlZGVudGlhbHMgPSBhd2FpdCB0aGlzLnNlY3VyaXR5Q2xpZW50LmF1dGhUb2tlbihcclxuICAgICAgICAgICAgcmVxdWVzdElkLFxyXG4gICAgICAgICAgICByZXF1ZXN0LmJvZHkuU0FNTFJlc3BvbnNlLFxyXG4gICAgICAgICAgICB1bmRlZmluZWRcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgdGhpcy5zZWN1cml0eUNsaWVudC5hdXRoZW50aWNhdGVXaXRoSGVhZGVyKFxyXG4gICAgICAgICAgICByZXF1ZXN0LFxyXG4gICAgICAgICAgICAnYXV0aG9yaXphdGlvbicsXHJcbiAgICAgICAgICAgIGNyZWRlbnRpYWxzLmF1dGhvcml6YXRpb25cclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgbGV0IGV4cGlyeVRpbWUgPSBEYXRlLm5vdygpICsgdGhpcy5jb25maWcuc2Vzc2lvbi50dGw7XHJcbiAgICAgICAgICBjb25zdCBbaGVhZGVyRW5jb2RlZCwgcGF5bG9hZEVuY29kZWQsIHNpZ25hdHVyZV0gPSBjcmVkZW50aWFscy5hdXRob3JpemF0aW9uLnNwbGl0KCcuJyk7XHJcbiAgICAgICAgICBpZiAoIXBheWxvYWRFbmNvZGVkKSB7XHJcbiAgICAgICAgICAgIGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmxvZ2dlci5lcnJvcignSldUIHRva2VuIHBheWxvYWQgbm90IGZvdW5kJyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zdCB0b2tlblBheWxvYWQgPSBKU09OLnBhcnNlKEJ1ZmZlci5mcm9tKHBheWxvYWRFbmNvZGVkLCAnYmFzZTY0JykudG9TdHJpbmcoKSk7XHJcblxyXG4gICAgICAgICAgaWYgKHRva2VuUGF5bG9hZC5leHApIHtcclxuICAgICAgICAgICAgZXhwaXJ5VGltZSA9IHBhcnNlSW50KHRva2VuUGF5bG9hZC5leHAsIDEwKSAqIDEwMDA7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgY29uc3QgY29va2llOiBTZWN1cml0eVNlc3Npb25Db29raWUgPSB7XHJcbiAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VyLnVzZXJuYW1lLFxyXG4gICAgICAgICAgICBjcmVkZW50aWFsczoge1xyXG4gICAgICAgICAgICAgIGF1dGhIZWFkZXJWYWx1ZUV4dHJhOiB0cnVlLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhdXRoVHlwZTogQXV0aFR5cGUuU0FNTCwgLy8gVE9ETzogY3JlYXRlIGNvbnN0YW50XHJcbiAgICAgICAgICAgIGV4cGlyeVRpbWUsXHJcbiAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgIHNldEV4dHJhQXV0aFN0b3JhZ2UoXHJcbiAgICAgICAgICAgIHJlcXVlc3QsXHJcbiAgICAgICAgICAgIGNyZWRlbnRpYWxzLmF1dGhvcml6YXRpb24sXHJcbiAgICAgICAgICAgIHRoaXMuZ2V0RXh0cmFBdXRoU3RvcmFnZU9wdGlvbnMoY29udGV4dC5zZWN1cml0eV9wbHVnaW4ubG9nZ2VyKVxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICB0aGlzLnNlc3Npb25TdG9yYWdlRmFjdG9yeS5hc1Njb3BlZChyZXF1ZXN0KS5zZXQoY29va2llKTtcclxuXHJcbiAgICAgICAgICBpZiAocmVkaXJlY3RIYXNoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5yZWRpcmVjdGVkKHtcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICBsb2NhdGlvbjogYCR7XHJcbiAgICAgICAgICAgICAgICAgIHRoaXMuY29yZVNldHVwLmh0dHAuYmFzZVBhdGguc2VydmVyQmFzZVBhdGhcclxuICAgICAgICAgICAgICAgIH0vYXV0aC9zYW1sL3JlZGlyZWN0VXJsRnJhZ21lbnQ/bmV4dFVybD0ke2VzY2FwZShuZXh0VXJsKX1gLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlZGlyZWN0ZWQoe1xyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgIGxvY2F0aW9uOiBuZXh0VXJsLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5sb2dnZXIuZXJyb3IoXHJcbiAgICAgICAgICAgIGBTQU1MIFNQIGluaXRpYXRlZCBhdXRoZW50aWNhdGlvbiB3b3JrZmxvdyBmYWlsZWQ6ICR7ZXJyb3J9YFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5pbnRlcm5hbEVycm9yKCk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgdGhpcy5yb3V0ZXIucG9zdChcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IGAvX29wZW5kaXN0cm8vX3NlY3VyaXR5L3NhbWwvYWNzL2lkcGluaXRpYXRlZGAsXHJcbiAgICAgICAgdmFsaWRhdGU6IHtcclxuICAgICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9wdGlvbnM6IHtcclxuICAgICAgICAgIGF1dGhSZXF1aXJlZDogZmFsc2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYWNzRW5kcG9pbnQgPSBgJHt0aGlzLmNvcmVTZXR1cC5odHRwLmJhc2VQYXRoLnNlcnZlckJhc2VQYXRofS9fb3BlbmRpc3Ryby9fc2VjdXJpdHkvc2FtbC9hY3MvaWRwaW5pdGlhdGVkYDtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgY3JlZGVudGlhbHMgPSBhd2FpdCB0aGlzLnNlY3VyaXR5Q2xpZW50LmF1dGhUb2tlbihcclxuICAgICAgICAgICAgdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICByZXF1ZXN0LmJvZHkuU0FNTFJlc3BvbnNlLFxyXG4gICAgICAgICAgICBhY3NFbmRwb2ludFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCB0aGlzLnNlY3VyaXR5Q2xpZW50LmF1dGhlbnRpY2F0ZVdpdGhIZWFkZXIoXHJcbiAgICAgICAgICAgIHJlcXVlc3QsXHJcbiAgICAgICAgICAgICdhdXRob3JpemF0aW9uJyxcclxuICAgICAgICAgICAgY3JlZGVudGlhbHMuYXV0aG9yaXphdGlvblxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBsZXQgZXhwaXJ5VGltZSA9IERhdGUubm93KCkgKyB0aGlzLmNvbmZpZy5zZXNzaW9uLnR0bDtcclxuICAgICAgICAgIGNvbnN0IFtoZWFkZXJFbmNvZGVkLCBwYXlsb2FkRW5jb2RlZCwgc2lnbmF0dXJlXSA9IGNyZWRlbnRpYWxzLmF1dGhvcml6YXRpb24uc3BsaXQoJy4nKTtcclxuICAgICAgICAgIGlmICghcGF5bG9hZEVuY29kZWQpIHtcclxuICAgICAgICAgICAgY29udGV4dC5zZWN1cml0eV9wbHVnaW4ubG9nZ2VyLmVycm9yKCdKV1QgdG9rZW4gcGF5bG9hZCBub3QgZm91bmQnKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNvbnN0IHRva2VuUGF5bG9hZCA9IEpTT04ucGFyc2UoQnVmZmVyLmZyb20ocGF5bG9hZEVuY29kZWQsICdiYXNlNjQnKS50b1N0cmluZygpKTtcclxuICAgICAgICAgIGlmICh0b2tlblBheWxvYWQuZXhwKSB7XHJcbiAgICAgICAgICAgIGV4cGlyeVRpbWUgPSBwYXJzZUludCh0b2tlblBheWxvYWQuZXhwLCAxMCkgKiAxMDAwO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGNvbnN0IGNvb2tpZTogU2VjdXJpdHlTZXNzaW9uQ29va2llID0ge1xyXG4gICAgICAgICAgICB1c2VybmFtZTogdXNlci51c2VybmFtZSxcclxuICAgICAgICAgICAgY3JlZGVudGlhbHM6IHtcclxuICAgICAgICAgICAgICBhdXRoSGVhZGVyVmFsdWVFeHRyYTogdHJ1ZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXV0aFR5cGU6IEF1dGhUeXBlLlNBTUwsIC8vIFRPRE86IGNyZWF0ZSBjb25zdGFudFxyXG4gICAgICAgICAgICBleHBpcnlUaW1lLFxyXG4gICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICBzZXRFeHRyYUF1dGhTdG9yYWdlKFxyXG4gICAgICAgICAgICByZXF1ZXN0LFxyXG4gICAgICAgICAgICBjcmVkZW50aWFscy5hdXRob3JpemF0aW9uLFxyXG4gICAgICAgICAgICB0aGlzLmdldEV4dHJhQXV0aFN0b3JhZ2VPcHRpb25zKGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmxvZ2dlcilcclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgdGhpcy5zZXNzaW9uU3RvcmFnZUZhY3RvcnkuYXNTY29wZWQocmVxdWVzdCkuc2V0KGNvb2tpZSk7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UucmVkaXJlY3RlZCh7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBsb2NhdGlvbjogYCR7dGhpcy5jb3JlU2V0dXAuaHR0cC5iYXNlUGF0aC5zZXJ2ZXJCYXNlUGF0aH0vYXBwL29wZW5zZWFyY2gtZGFzaGJvYXJkc2AsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29udGV4dC5zZWN1cml0eV9wbHVnaW4ubG9nZ2VyLmVycm9yKFxyXG4gICAgICAgICAgICBgU0FNTCBJRFAgaW5pdGlhdGVkIGF1dGhlbnRpY2F0aW9uIHdvcmtmbG93IGZhaWxlZDogJHtlcnJvcn1gXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuaW50ZXJuYWxFcnJvcigpO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIGNhcHR1cmVVcmxGcmFnbWVudCBpcyB0aGUgZmlyc3Qgcm91dGUgdGhhdCB3aWxsIGJlIGludm9rZWQgaW4gdGhlIFNQIGluaXRpYXRlZCBsb2dpbi5cclxuICAgIC8vIFRoaXMgcm91dGUgd2lsbCBleGVjdXRlIHRoZSBjYXB0dXJlVXJsRnJhZ21lbnQuanMgc2NyaXB0LlxyXG4gICAgdGhpcy5jb3JlU2V0dXAuaHR0cC5yZXNvdXJjZXMucmVnaXN0ZXIoXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAnL2F1dGgvc2FtbC9jYXB0dXJlVXJsRnJhZ21lbnQnLFxyXG4gICAgICAgIHZhbGlkYXRlOiB7XHJcbiAgICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgICAgIG5leHRVcmw6IHNjaGVtYS5tYXliZShcclxuICAgICAgICAgICAgICBzY2hlbWEuc3RyaW5nKHtcclxuICAgICAgICAgICAgICAgIHZhbGlkYXRlOiB2YWxpZGF0ZU5leHRVcmwsXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH0pLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb3B0aW9uczoge1xyXG4gICAgICAgICAgYXV0aFJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgICB0aGlzLnNlc3Npb25TdG9yYWdlRmFjdG9yeS5hc1Njb3BlZChyZXF1ZXN0KS5jbGVhcigpO1xyXG4gICAgICAgIGNvbnN0IHNlcnZlckJhc2VQYXRoID0gdGhpcy5jb3JlU2V0dXAuaHR0cC5iYXNlUGF0aC5zZXJ2ZXJCYXNlUGF0aDtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UucmVuZGVySHRtbCh7XHJcbiAgICAgICAgICBib2R5OiBgXHJcbiAgICAgICAgICAgIDwhRE9DVFlQRSBodG1sPlxyXG4gICAgICAgICAgICA8dGl0bGU+T1NEIFNBTUwgQ2FwdHVyZTwvdGl0bGU+XHJcbiAgICAgICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiZGF0YTosXCI+XHJcbiAgICAgICAgICAgIDxzY3JpcHQgc3JjPVwiJHtzZXJ2ZXJCYXNlUGF0aH0vYXV0aC9zYW1sL2NhcHR1cmVVcmxGcmFnbWVudC5qc1wiPjwvc2NyaXB0PlxyXG4gICAgICAgICAgYCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICAvLyBUaGlzIHNjcmlwdCB3aWxsIHN0b3JlIHRoZSBVUkwgSGFzaCBpbiBicm93c2VyJ3MgbG9jYWwgc3RvcmFnZS5cclxuICAgIHRoaXMuY29yZVNldHVwLmh0dHAucmVzb3VyY2VzLnJlZ2lzdGVyKFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogJy9hdXRoL3NhbWwvY2FwdHVyZVVybEZyYWdtZW50LmpzJyxcclxuICAgICAgICB2YWxpZGF0ZTogZmFsc2UsXHJcbiAgICAgICAgb3B0aW9uczoge1xyXG4gICAgICAgICAgYXV0aFJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgICB0aGlzLnNlc3Npb25TdG9yYWdlRmFjdG9yeS5hc1Njb3BlZChyZXF1ZXN0KS5jbGVhcigpO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5yZW5kZXJKcyh7XHJcbiAgICAgICAgICBib2R5OiBgbGV0IHNhbWxIYXNoPXdpbmRvdy5sb2NhdGlvbi5oYXNoLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgbGV0IHJlZGlyZWN0SGFzaCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgIGlmIChzYW1sSGFzaCAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnc2FtbEhhc2gnKTtcclxuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3NhbWxIYXNoJywgc2FtbEhhc2gpO1xyXG4gICAgICAgICAgICAgICAgICAgICByZWRpcmVjdEhhc2ggPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaCk7XHJcbiAgICAgICAgICAgICAgICAgbGV0IG5leHRVcmwgPSBwYXJhbXMuZ2V0KFwibmV4dFVybFwiKTtcclxuICAgICAgICAgICAgICAgICBmaW5hbFVybCA9IFwibG9naW4/bmV4dFVybD1cIiArIGVuY29kZVVSSUNvbXBvbmVudChuZXh0VXJsKTtcclxuICAgICAgICAgICAgICAgICBmaW5hbFVybCArPSBcIiZyZWRpcmVjdEhhc2g9XCIgKyBlbmNvZGVVUklDb21wb25lbnQocmVkaXJlY3RIYXNoKTtcclxuICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVwbGFjZShmaW5hbFVybCk7XHJcbiAgICAgICAgICAgICAgICBgLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vICBPbmNlIHRoZSBVc2VyIGlzIGF1dGhlbnRpY2F0ZWQgdmlhIHRoZSAnX29wZW5kaXN0cm8vX3NlY3VyaXR5L3NhbWwvYWNzJyByb3V0ZSxcclxuICAgIC8vICB0aGUgYnJvd3NlciB3aWxsIGJlIHJlZGlyZWN0ZWQgdG8gJy9hdXRoL3NhbWwvcmVkaXJlY3RVcmxGcmFnbWVudCcgcm91dGUsXHJcbiAgICAvLyAgd2hpY2ggd2lsbCBleGVjdXRlIHRoZSByZWRpcmVjdFVybEZyYWdtZW50LmpzLlxyXG4gICAgdGhpcy5jb3JlU2V0dXAuaHR0cC5yZXNvdXJjZXMucmVnaXN0ZXIoXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAnL2F1dGgvc2FtbC9yZWRpcmVjdFVybEZyYWdtZW50JyxcclxuICAgICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICAgICAgICBuZXh0VXJsOiBzY2hlbWEuYW55KCksXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9wdGlvbnM6IHtcclxuICAgICAgICAgIGF1dGhSZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgICBjb25zdCBzZXJ2ZXJCYXNlUGF0aCA9IHRoaXMuY29yZVNldHVwLmh0dHAuYmFzZVBhdGguc2VydmVyQmFzZVBhdGg7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlbmRlckh0bWwoe1xyXG4gICAgICAgICAgYm9keTogYFxyXG4gICAgICAgICAgICA8IURPQ1RZUEUgaHRtbD5cclxuICAgICAgICAgICAgPHRpdGxlPk9TRCBTQU1MIFN1Y2Nlc3M8L3RpdGxlPlxyXG4gICAgICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cImRhdGE6LFwiPlxyXG4gICAgICAgICAgICA8c2NyaXB0IHNyYz1cIiR7c2VydmVyQmFzZVBhdGh9L2F1dGgvc2FtbC9yZWRpcmVjdFVybEZyYWdtZW50LmpzXCI+PC9zY3JpcHQ+XHJcbiAgICAgICAgICBgLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIFRoaXMgc2NyaXB0IHdpbGwgcG9wIHRoZSBIYXNoIGZyb20gbG9jYWwgc3RvcmFnZSBpZiBpdCBleGlzdHMuXHJcbiAgICAvLyBBbmQgZm9yd2FyZCB0aGUgYnJvd3NlciB0byB0aGUgbmV4dCB1cmwuXHJcbiAgICB0aGlzLmNvcmVTZXR1cC5odHRwLnJlc291cmNlcy5yZWdpc3RlcihcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6ICcvYXV0aC9zYW1sL3JlZGlyZWN0VXJsRnJhZ21lbnQuanMnLFxyXG4gICAgICAgIHZhbGlkYXRlOiBmYWxzZSxcclxuICAgICAgICBvcHRpb25zOiB7XHJcbiAgICAgICAgICBhdXRoUmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlbmRlckpzKHtcclxuICAgICAgICAgIGJvZHk6IGBsZXQgc2FtbEhhc2g9d2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzYW1sSGFzaCcpO1xyXG4gICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnc2FtbEhhc2gnKTtcclxuICAgICAgICAgICAgICAgICBsZXQgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh3aW5kb3cubG9jYXRpb24uc2VhcmNoKTtcclxuICAgICAgICAgICAgICAgICBsZXQgbmV4dFVybCA9IHBhcmFtcy5nZXQoXCJuZXh0VXJsXCIpO1xyXG4gICAgICAgICAgICAgICAgIGZpbmFsVXJsID0gbmV4dFVybCArIHNhbWxIYXNoO1xyXG4gICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZXBsYWNlKGZpbmFsVXJsKTtcclxuICAgICAgICAgICAgICAgIGAsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgdGhpcy5yb3V0ZXIuZ2V0KFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogU0FNTF9BVVRIX0xPR09VVCxcclxuICAgICAgICB2YWxpZGF0ZTogZmFsc2UsXHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBhdXRoSW5mbyA9IGF3YWl0IHRoaXMuc2VjdXJpdHlDbGllbnQuYXV0aGluZm8ocmVxdWVzdCk7XHJcbiAgICAgICAgICBhd2FpdCBjbGVhclNwbGl0Q29va2llcyhcclxuICAgICAgICAgICAgcmVxdWVzdCxcclxuICAgICAgICAgICAgdGhpcy5nZXRFeHRyYUF1dGhTdG9yYWdlT3B0aW9ucyhjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5sb2dnZXIpXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgdGhpcy5zZXNzaW9uU3RvcmFnZUZhY3RvcnkuYXNTY29wZWQocmVxdWVzdCkuY2xlYXIoKTtcclxuICAgICAgICAgIC8vIFRPRE86IG5lZWQgYSBkZWZhdWx0IGxvZ291dCBwYWdlXHJcbiAgICAgICAgICBjb25zdCByZWRpcmVjdFVybCA9XHJcbiAgICAgICAgICAgIGF1dGhJbmZvLnNzb19sb2dvdXRfdXJsIHx8IHRoaXMuY29yZVNldHVwLmh0dHAuYmFzZVBhdGguc2VydmVyQmFzZVBhdGggfHwgJy8nO1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlZGlyZWN0ZWQoe1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgbG9jYXRpb246IHJlZGlyZWN0VXJsLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmxvZ2dlci5lcnJvcihgU0FNTCBsb2dvdXQgZmFpbGVkOiAke2Vycm9yfWApO1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3QoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgfVxyXG59XHJcbiJdfQ==