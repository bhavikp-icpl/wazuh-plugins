"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhCorePlugin = void 0;

var _pluginServices = require("./plugin-services");

var controllers = _interopRequireWildcard(require("./controllers"));

var services = _interopRequireWildcard(require("./services"));

var _securityFactory = require("./services/security-factory");

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WazuhCorePlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);

    this.logger = initializerContext.logger.get();
  }

  async setup(core, plugins) {
    this.logger.debug('wazuh_core: Setup');
    const wazuhSecurity = await (0, _securityFactory.SecurityObj)(plugins);
    return {
      wazuhSecurity
    };
  }

  start(core) {
    this.logger.debug('wazuhCore: Started');
    (0, _pluginServices.setCore)(core);
    return {
      controllers,
      services
    };
  }

  stop() {}

}

exports.WazuhCorePlugin = WazuhCorePlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBsdWdpbi50cyJdLCJuYW1lcyI6WyJXYXp1aENvcmVQbHVnaW4iLCJjb25zdHJ1Y3RvciIsImluaXRpYWxpemVyQ29udGV4dCIsImxvZ2dlciIsImdldCIsInNldHVwIiwiY29yZSIsInBsdWdpbnMiLCJkZWJ1ZyIsIndhenVoU2VjdXJpdHkiLCJzdGFydCIsImNvbnRyb2xsZXJzIiwic2VydmljZXMiLCJzdG9wIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBU0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7Ozs7Ozs7O0FBRU8sTUFBTUEsZUFBTixDQUFvRjtBQUd6RkMsRUFBQUEsV0FBVyxDQUFDQyxrQkFBRCxFQUErQztBQUFBOztBQUN4RCxTQUFLQyxNQUFMLEdBQWNELGtCQUFrQixDQUFDQyxNQUFuQixDQUEwQkMsR0FBMUIsRUFBZDtBQUNEOztBQUVpQixRQUFMQyxLQUFLLENBQUNDLElBQUQsRUFBa0JDLE9BQWxCLEVBQXVFO0FBQ3ZGLFNBQUtKLE1BQUwsQ0FBWUssS0FBWixDQUFrQixtQkFBbEI7QUFFQSxVQUFNQyxhQUFhLEdBQUcsTUFBTSxrQ0FBWUYsT0FBWixDQUE1QjtBQUVBLFdBQU87QUFDTEUsTUFBQUE7QUFESyxLQUFQO0FBR0Q7O0FBRU1DLEVBQUFBLEtBQUssQ0FBQ0osSUFBRCxFQUF3QztBQUNsRCxTQUFLSCxNQUFMLENBQVlLLEtBQVosQ0FBa0Isb0JBQWxCO0FBRUEsaUNBQVFGLElBQVI7QUFFQSxXQUFPO0FBQ0xLLE1BQUFBLFdBREs7QUFFTEMsTUFBQUE7QUFGSyxLQUFQO0FBSUQ7O0FBRU1DLEVBQUFBLElBQUksR0FBRyxDQUFFOztBQTVCeUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQsXG4gIENvcmVTZXR1cCxcbiAgQ29yZVN0YXJ0LFxuICBQbHVnaW4sXG4gIExvZ2dlcixcbn0gZnJvbSAnb3BlbnNlYXJjaC1kYXNoYm9hcmRzL3NlcnZlcic7XG5cbmltcG9ydCB7IFBsdWdpblNldHVwLCBXYXp1aENvcmVQbHVnaW5TZXR1cCwgV2F6dWhDb3JlUGx1Z2luU3RhcnQgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IHNldENvcmUgfSBmcm9tICcuL3BsdWdpbi1zZXJ2aWNlcyc7XG5pbXBvcnQgKiBhcyBjb250cm9sbGVycyBmcm9tICcuL2NvbnRyb2xsZXJzJztcbmltcG9ydCAqIGFzIHNlcnZpY2VzIGZyb20gJy4vc2VydmljZXMnO1xuaW1wb3J0IHsgU2VjdXJpdHlPYmogfSBmcm9tICcuL3NlcnZpY2VzL3NlY3VyaXR5LWZhY3RvcnknO1xuXG5leHBvcnQgY2xhc3MgV2F6dWhDb3JlUGx1Z2luIGltcGxlbWVudHMgUGx1Z2luPFdhenVoQ29yZVBsdWdpblNldHVwLCBXYXp1aENvcmVQbHVnaW5TdGFydD4ge1xuICBwcml2YXRlIHJlYWRvbmx5IGxvZ2dlcjogTG9nZ2VyO1xuXG4gIGNvbnN0cnVjdG9yKGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gICAgdGhpcy5sb2dnZXIgPSBpbml0aWFsaXplckNvbnRleHQubG9nZ2VyLmdldCgpO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIHNldHVwKGNvcmU6IENvcmVTZXR1cCwgcGx1Z2luczogUGx1Z2luU2V0dXApOiBQcm9taXNlPFdhenVoQ29yZVBsdWdpblNldHVwPiB7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoJ3dhenVoX2NvcmU6IFNldHVwJyk7XG5cbiAgICBjb25zdCB3YXp1aFNlY3VyaXR5ID0gYXdhaXQgU2VjdXJpdHlPYmoocGx1Z2lucyk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgd2F6dWhTZWN1cml0eSxcbiAgICB9O1xuICB9XG5cbiAgcHVibGljIHN0YXJ0KGNvcmU6IENvcmVTdGFydCk6IFdhenVoQ29yZVBsdWdpblN0YXJ0IHtcbiAgICB0aGlzLmxvZ2dlci5kZWJ1Zygnd2F6dWhDb3JlOiBTdGFydGVkJyk7XG5cbiAgICBzZXRDb3JlKGNvcmUpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbnRyb2xsZXJzLFxuICAgICAgc2VydmljZXMsXG4gICAgfTtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wKCkge31cbn1cbiJdfQ==