"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// eslint-disable-next-line import/no-default-export
function _default(Client, config, components) {
  const ca = components.clientAction.factory;

  if (!Client.prototype.opensearch_security) {
    Client.prototype.opensearch_security = components.clientAction.namespaceFactory();
  }

  Client.prototype.opensearch_security.prototype.restapiinfo = ca({
    url: {
      fmt: '/_plugins/_security/api/permissionsinfo'
    }
  });
  /**
   * list all field mappings for all indices.
   */

  Client.prototype.opensearch_security.prototype.indices = ca({
    url: {
      fmt: '/_all/_mapping/field/*'
    }
  });
  /**
   * Returns a Security resource configuration.
   *
   * Sample response:
   *
   * {
   *   "user": {
   *     "hash": "#123123"
   *   }
   * }
   */

  Client.prototype.opensearch_security.prototype.listResource = ca({
    url: {
      fmt: '/_plugins/_security/api/<%=resourceName%>',
      req: {
        resourceName: {
          type: 'string',
          required: true
        }
      }
    }
  });
  /**
   * Creates a Security resource instance.
   *
   * At the moment Security does not support conflict detection,
   * so this method can be effectively used to both create and update resource.
   *
   * Sample response:
   *
   * {
   *   "status": "CREATED",
   *   "message": "User username created"
   * }
   */

  Client.prototype.opensearch_security.prototype.saveResource = ca({
    method: 'PUT',
    needBody: true,
    url: {
      fmt: '/_plugins/_security/api/<%=resourceName%>/<%=id%>',
      req: {
        resourceName: {
          type: 'string',
          required: true
        },
        id: {
          type: 'string',
          required: true
        }
      }
    }
  });
  /**
   * Updates a resource.
   * Resource identification is expected to computed from headers. Eg: auth headers.
   *
   * Sample response:
   * {
   *   "status": "OK",
   *   "message": "Username updated."
   * }
   */

  Client.prototype.opensearch_security.prototype.saveResourceWithoutId = ca({
    method: 'PUT',
    needBody: true,
    url: {
      fmt: '/_plugins/_security/api/<%=resourceName%>',
      req: {
        resourceName: {
          type: 'string',
          required: true
        }
      }
    }
  });
  /**
   * Returns a Security resource instance.
   *
   * Sample response:
   *
   * {
   *   "user": {
   *     "hash": '#123123'
   *   }
   * }
   */

  Client.prototype.opensearch_security.prototype.getResource = ca({
    method: 'GET',
    url: {
      fmt: '/_plugins/_security/api/<%=resourceName%>/<%=id%>',
      req: {
        resourceName: {
          type: 'string',
          required: true
        },
        id: {
          type: 'string',
          required: true
        }
      }
    }
  });
  /**
   * Deletes a Security resource instance.
   */

  Client.prototype.opensearch_security.prototype.deleteResource = ca({
    method: 'DELETE',
    url: {
      fmt: '/_plugins/_security/api/<%=resourceName%>/<%=id%>',
      req: {
        resourceName: {
          type: 'string',
          required: true
        },
        id: {
          type: 'string',
          required: true
        }
      }
    }
  });
  /**
   * Deletes a Security resource instance.
   */

  Client.prototype.opensearch_security.prototype.clearCache = ca({
    method: 'DELETE',
    url: {
      fmt: '/_plugins/_security/api/cache'
    }
  });
  /**
   * Validate query.
   */

  Client.prototype.opensearch_security.prototype.validateDls = ca({
    method: 'POST',
    needBody: true,
    url: {
      fmt: '/_validate/query?explain=true'
    }
  });
  /**
   * Gets index mapping.
   */

  Client.prototype.opensearch_security.prototype.getIndexMappings = ca({
    method: 'GET',
    needBody: true,
    url: {
      fmt: '/<%=index%>/_mapping',
      req: {
        index: {
          type: 'string',
          required: true
        }
      }
    }
  });
  /**
   * Gets audit log configuration.
   */

  Client.prototype.opensearch_security.prototype.getAudit = ca({
    method: 'GET',
    url: {
      fmt: '/_plugins/_security/api/audit'
    }
  });
  /**
   * Updates audit log configuration.
   */

  Client.prototype.opensearch_security.prototype.saveAudit = ca({
    method: 'PUT',
    needBody: true,
    url: {
      fmt: '/_plugins/_security/api/audit/config'
    }
  });
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9wZW5zZWFyY2hfc2VjdXJpdHlfY29uZmlndXJhdGlvbl9wbHVnaW4udHMiXSwibmFtZXMiOlsiQ2xpZW50IiwiY29uZmlnIiwiY29tcG9uZW50cyIsImNhIiwiY2xpZW50QWN0aW9uIiwiZmFjdG9yeSIsInByb3RvdHlwZSIsIm9wZW5zZWFyY2hfc2VjdXJpdHkiLCJuYW1lc3BhY2VGYWN0b3J5IiwicmVzdGFwaWluZm8iLCJ1cmwiLCJmbXQiLCJpbmRpY2VzIiwibGlzdFJlc291cmNlIiwicmVxIiwicmVzb3VyY2VOYW1lIiwidHlwZSIsInJlcXVpcmVkIiwic2F2ZVJlc291cmNlIiwibWV0aG9kIiwibmVlZEJvZHkiLCJpZCIsInNhdmVSZXNvdXJjZVdpdGhvdXRJZCIsImdldFJlc291cmNlIiwiZGVsZXRlUmVzb3VyY2UiLCJjbGVhckNhY2hlIiwidmFsaWRhdGVEbHMiLCJnZXRJbmRleE1hcHBpbmdzIiwiaW5kZXgiLCJnZXRBdWRpdCIsInNhdmVBdWRpdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNlLGtCQUFVQSxNQUFWLEVBQXVCQyxNQUF2QixFQUFvQ0MsVUFBcEMsRUFBcUQ7QUFDbEUsUUFBTUMsRUFBRSxHQUFHRCxVQUFVLENBQUNFLFlBQVgsQ0FBd0JDLE9BQW5DOztBQUVBLE1BQUksQ0FBQ0wsTUFBTSxDQUFDTSxTQUFQLENBQWlCQyxtQkFBdEIsRUFBMkM7QUFDekNQLElBQUFBLE1BQU0sQ0FBQ00sU0FBUCxDQUFpQkMsbUJBQWpCLEdBQXVDTCxVQUFVLENBQUNFLFlBQVgsQ0FBd0JJLGdCQUF4QixFQUF2QztBQUNEOztBQUVEUixFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NHLFdBQS9DLEdBQTZETixFQUFFLENBQUM7QUFDOURPLElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQUR5RCxHQUFELENBQS9EO0FBTUE7QUFDRjtBQUNBOztBQUNFWCxFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NNLE9BQS9DLEdBQXlEVCxFQUFFLENBQUM7QUFDMURPLElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQURxRCxHQUFELENBQTNEO0FBTUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRVgsRUFBQUEsTUFBTSxDQUFDTSxTQUFQLENBQWlCQyxtQkFBakIsQ0FBcUNELFNBQXJDLENBQStDTyxZQUEvQyxHQUE4RFYsRUFBRSxDQUFDO0FBQy9ETyxJQUFBQSxHQUFHLEVBQUU7QUFDSEMsTUFBQUEsR0FBRyxFQUFFLDJDQURGO0FBRUhHLE1BQUFBLEdBQUcsRUFBRTtBQUNIQyxRQUFBQSxZQUFZLEVBQUU7QUFDWkMsVUFBQUEsSUFBSSxFQUFFLFFBRE07QUFFWkMsVUFBQUEsUUFBUSxFQUFFO0FBRkU7QUFEWDtBQUZGO0FBRDBELEdBQUQsQ0FBaEU7QUFZQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRWpCLEVBQUFBLE1BQU0sQ0FBQ00sU0FBUCxDQUFpQkMsbUJBQWpCLENBQXFDRCxTQUFyQyxDQUErQ1ksWUFBL0MsR0FBOERmLEVBQUUsQ0FBQztBQUMvRGdCLElBQUFBLE1BQU0sRUFBRSxLQUR1RDtBQUUvREMsSUFBQUEsUUFBUSxFQUFFLElBRnFEO0FBRy9EVixJQUFBQSxHQUFHLEVBQUU7QUFDSEMsTUFBQUEsR0FBRyxFQUFFLG1EQURGO0FBRUhHLE1BQUFBLEdBQUcsRUFBRTtBQUNIQyxRQUFBQSxZQUFZLEVBQUU7QUFDWkMsVUFBQUEsSUFBSSxFQUFFLFFBRE07QUFFWkMsVUFBQUEsUUFBUSxFQUFFO0FBRkUsU0FEWDtBQUtISSxRQUFBQSxFQUFFLEVBQUU7QUFDRkwsVUFBQUEsSUFBSSxFQUFFLFFBREo7QUFFRkMsVUFBQUEsUUFBUSxFQUFFO0FBRlI7QUFMRDtBQUZGO0FBSDBELEdBQUQsQ0FBaEU7QUFrQkE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0VqQixFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NnQixxQkFBL0MsR0FBdUVuQixFQUFFLENBQUM7QUFDeEVnQixJQUFBQSxNQUFNLEVBQUUsS0FEZ0U7QUFFeEVDLElBQUFBLFFBQVEsRUFBRSxJQUY4RDtBQUd4RVYsSUFBQUEsR0FBRyxFQUFFO0FBQ0hDLE1BQUFBLEdBQUcsRUFBRSwyQ0FERjtBQUVIRyxNQUFBQSxHQUFHLEVBQUU7QUFDSEMsUUFBQUEsWUFBWSxFQUFFO0FBQ1pDLFVBQUFBLElBQUksRUFBRSxRQURNO0FBRVpDLFVBQUFBLFFBQVEsRUFBRTtBQUZFO0FBRFg7QUFGRjtBQUhtRSxHQUFELENBQXpFO0FBY0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRWpCLEVBQUFBLE1BQU0sQ0FBQ00sU0FBUCxDQUFpQkMsbUJBQWpCLENBQXFDRCxTQUFyQyxDQUErQ2lCLFdBQS9DLEdBQTZEcEIsRUFBRSxDQUFDO0FBQzlEZ0IsSUFBQUEsTUFBTSxFQUFFLEtBRHNEO0FBRTlEVCxJQUFBQSxHQUFHLEVBQUU7QUFDSEMsTUFBQUEsR0FBRyxFQUFFLG1EQURGO0FBRUhHLE1BQUFBLEdBQUcsRUFBRTtBQUNIQyxRQUFBQSxZQUFZLEVBQUU7QUFDWkMsVUFBQUEsSUFBSSxFQUFFLFFBRE07QUFFWkMsVUFBQUEsUUFBUSxFQUFFO0FBRkUsU0FEWDtBQUtISSxRQUFBQSxFQUFFLEVBQUU7QUFDRkwsVUFBQUEsSUFBSSxFQUFFLFFBREo7QUFFRkMsVUFBQUEsUUFBUSxFQUFFO0FBRlI7QUFMRDtBQUZGO0FBRnlELEdBQUQsQ0FBL0Q7QUFpQkE7QUFDRjtBQUNBOztBQUNFakIsRUFBQUEsTUFBTSxDQUFDTSxTQUFQLENBQWlCQyxtQkFBakIsQ0FBcUNELFNBQXJDLENBQStDa0IsY0FBL0MsR0FBZ0VyQixFQUFFLENBQUM7QUFDakVnQixJQUFBQSxNQUFNLEVBQUUsUUFEeUQ7QUFFakVULElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUUsbURBREY7QUFFSEcsTUFBQUEsR0FBRyxFQUFFO0FBQ0hDLFFBQUFBLFlBQVksRUFBRTtBQUNaQyxVQUFBQSxJQUFJLEVBQUUsUUFETTtBQUVaQyxVQUFBQSxRQUFRLEVBQUU7QUFGRSxTQURYO0FBS0hJLFFBQUFBLEVBQUUsRUFBRTtBQUNGTCxVQUFBQSxJQUFJLEVBQUUsUUFESjtBQUVGQyxVQUFBQSxRQUFRLEVBQUU7QUFGUjtBQUxEO0FBRkY7QUFGNEQsR0FBRCxDQUFsRTtBQWlCQTtBQUNGO0FBQ0E7O0FBQ0VqQixFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NtQixVQUEvQyxHQUE0RHRCLEVBQUUsQ0FBQztBQUM3RGdCLElBQUFBLE1BQU0sRUFBRSxRQURxRDtBQUU3RFQsSUFBQUEsR0FBRyxFQUFFO0FBQ0hDLE1BQUFBLEdBQUcsRUFBRTtBQURGO0FBRndELEdBQUQsQ0FBOUQ7QUFPQTtBQUNGO0FBQ0E7O0FBQ0VYLEVBQUFBLE1BQU0sQ0FBQ00sU0FBUCxDQUFpQkMsbUJBQWpCLENBQXFDRCxTQUFyQyxDQUErQ29CLFdBQS9DLEdBQTZEdkIsRUFBRSxDQUFDO0FBQzlEZ0IsSUFBQUEsTUFBTSxFQUFFLE1BRHNEO0FBRTlEQyxJQUFBQSxRQUFRLEVBQUUsSUFGb0Q7QUFHOURWLElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQUh5RCxHQUFELENBQS9EO0FBUUE7QUFDRjtBQUNBOztBQUNFWCxFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NxQixnQkFBL0MsR0FBa0V4QixFQUFFLENBQUM7QUFDbkVnQixJQUFBQSxNQUFNLEVBQUUsS0FEMkQ7QUFFbkVDLElBQUFBLFFBQVEsRUFBRSxJQUZ5RDtBQUduRVYsSUFBQUEsR0FBRyxFQUFFO0FBQ0hDLE1BQUFBLEdBQUcsRUFBRSxzQkFERjtBQUVIRyxNQUFBQSxHQUFHLEVBQUU7QUFDSGMsUUFBQUEsS0FBSyxFQUFFO0FBQ0xaLFVBQUFBLElBQUksRUFBRSxRQUREO0FBRUxDLFVBQUFBLFFBQVEsRUFBRTtBQUZMO0FBREo7QUFGRjtBQUg4RCxHQUFELENBQXBFO0FBY0E7QUFDRjtBQUNBOztBQUNFakIsRUFBQUEsTUFBTSxDQUFDTSxTQUFQLENBQWlCQyxtQkFBakIsQ0FBcUNELFNBQXJDLENBQStDdUIsUUFBL0MsR0FBMEQxQixFQUFFLENBQUM7QUFDM0RnQixJQUFBQSxNQUFNLEVBQUUsS0FEbUQ7QUFFM0RULElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQUZzRCxHQUFELENBQTVEO0FBT0E7QUFDRjtBQUNBOztBQUNFWCxFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0N3QixTQUEvQyxHQUEyRDNCLEVBQUUsQ0FBQztBQUM1RGdCLElBQUFBLE1BQU0sRUFBRSxLQURvRDtBQUU1REMsSUFBQUEsUUFBUSxFQUFFLElBRmtEO0FBRzVEVixJQUFBQSxHQUFHLEVBQUU7QUFDSEMsTUFBQUEsR0FBRyxFQUFFO0FBREY7QUFIdUQsR0FBRCxDQUE3RDtBQU9EIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcclxuICpcclxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxyXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cclxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxyXG4gKlxyXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuICpcclxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcclxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xyXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLWRlZmF1bHQtZXhwb3J0XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIChDbGllbnQ6IGFueSwgY29uZmlnOiBhbnksIGNvbXBvbmVudHM6IGFueSkge1xyXG4gIGNvbnN0IGNhID0gY29tcG9uZW50cy5jbGllbnRBY3Rpb24uZmFjdG9yeTtcclxuXHJcbiAgaWYgKCFDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkpIHtcclxuICAgIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eSA9IGNvbXBvbmVudHMuY2xpZW50QWN0aW9uLm5hbWVzcGFjZUZhY3RvcnkoKTtcclxuICB9XHJcblxyXG4gIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eS5wcm90b3R5cGUucmVzdGFwaWluZm8gPSBjYSh7XHJcbiAgICB1cmw6IHtcclxuICAgICAgZm10OiAnL19wbHVnaW5zL19zZWN1cml0eS9hcGkvcGVybWlzc2lvbnNpbmZvJyxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIGxpc3QgYWxsIGZpZWxkIG1hcHBpbmdzIGZvciBhbGwgaW5kaWNlcy5cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmluZGljZXMgPSBjYSh7XHJcbiAgICB1cmw6IHtcclxuICAgICAgZm10OiAnL19hbGwvX21hcHBpbmcvZmllbGQvKicsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIGEgU2VjdXJpdHkgcmVzb3VyY2UgY29uZmlndXJhdGlvbi5cclxuICAgKlxyXG4gICAqIFNhbXBsZSByZXNwb25zZTpcclxuICAgKlxyXG4gICAqIHtcclxuICAgKiAgIFwidXNlclwiOiB7XHJcbiAgICogICAgIFwiaGFzaFwiOiBcIiMxMjMxMjNcIlxyXG4gICAqICAgfVxyXG4gICAqIH1cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmxpc3RSZXNvdXJjZSA9IGNhKHtcclxuICAgIHVybDoge1xyXG4gICAgICBmbXQ6ICcvX3BsdWdpbnMvX3NlY3VyaXR5L2FwaS88JT1yZXNvdXJjZU5hbWUlPicsXHJcbiAgICAgIHJlcToge1xyXG4gICAgICAgIHJlc291cmNlTmFtZToge1xyXG4gICAgICAgICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogQ3JlYXRlcyBhIFNlY3VyaXR5IHJlc291cmNlIGluc3RhbmNlLlxyXG4gICAqXHJcbiAgICogQXQgdGhlIG1vbWVudCBTZWN1cml0eSBkb2VzIG5vdCBzdXBwb3J0IGNvbmZsaWN0IGRldGVjdGlvbixcclxuICAgKiBzbyB0aGlzIG1ldGhvZCBjYW4gYmUgZWZmZWN0aXZlbHkgdXNlZCB0byBib3RoIGNyZWF0ZSBhbmQgdXBkYXRlIHJlc291cmNlLlxyXG4gICAqXHJcbiAgICogU2FtcGxlIHJlc3BvbnNlOlxyXG4gICAqXHJcbiAgICoge1xyXG4gICAqICAgXCJzdGF0dXNcIjogXCJDUkVBVEVEXCIsXHJcbiAgICogICBcIm1lc3NhZ2VcIjogXCJVc2VyIHVzZXJuYW1lIGNyZWF0ZWRcIlxyXG4gICAqIH1cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLnNhdmVSZXNvdXJjZSA9IGNhKHtcclxuICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICBuZWVkQm9keTogdHJ1ZSxcclxuICAgIHVybDoge1xyXG4gICAgICBmbXQ6ICcvX3BsdWdpbnMvX3NlY3VyaXR5L2FwaS88JT1yZXNvdXJjZU5hbWUlPi88JT1pZCU+JyxcclxuICAgICAgcmVxOiB7XHJcbiAgICAgICAgcmVzb3VyY2VOYW1lOiB7XHJcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJyxcclxuICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaWQ6IHtcclxuICAgICAgICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFVwZGF0ZXMgYSByZXNvdXJjZS5cclxuICAgKiBSZXNvdXJjZSBpZGVudGlmaWNhdGlvbiBpcyBleHBlY3RlZCB0byBjb21wdXRlZCBmcm9tIGhlYWRlcnMuIEVnOiBhdXRoIGhlYWRlcnMuXHJcbiAgICpcclxuICAgKiBTYW1wbGUgcmVzcG9uc2U6XHJcbiAgICoge1xyXG4gICAqICAgXCJzdGF0dXNcIjogXCJPS1wiLFxyXG4gICAqICAgXCJtZXNzYWdlXCI6IFwiVXNlcm5hbWUgdXBkYXRlZC5cIlxyXG4gICAqIH1cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLnNhdmVSZXNvdXJjZVdpdGhvdXRJZCA9IGNhKHtcclxuICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICBuZWVkQm9keTogdHJ1ZSxcclxuICAgIHVybDoge1xyXG4gICAgICBmbXQ6ICcvX3BsdWdpbnMvX3NlY3VyaXR5L2FwaS88JT1yZXNvdXJjZU5hbWUlPicsXHJcbiAgICAgIHJlcToge1xyXG4gICAgICAgIHJlc291cmNlTmFtZToge1xyXG4gICAgICAgICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBhIFNlY3VyaXR5IHJlc291cmNlIGluc3RhbmNlLlxyXG4gICAqXHJcbiAgICogU2FtcGxlIHJlc3BvbnNlOlxyXG4gICAqXHJcbiAgICoge1xyXG4gICAqICAgXCJ1c2VyXCI6IHtcclxuICAgKiAgICAgXCJoYXNoXCI6ICcjMTIzMTIzJ1xyXG4gICAqICAgfVxyXG4gICAqIH1cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmdldFJlc291cmNlID0gY2Eoe1xyXG4gICAgbWV0aG9kOiAnR0VUJyxcclxuICAgIHVybDoge1xyXG4gICAgICBmbXQ6ICcvX3BsdWdpbnMvX3NlY3VyaXR5L2FwaS88JT1yZXNvdXJjZU5hbWUlPi88JT1pZCU+JyxcclxuICAgICAgcmVxOiB7XHJcbiAgICAgICAgcmVzb3VyY2VOYW1lOiB7XHJcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJyxcclxuICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaWQ6IHtcclxuICAgICAgICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIERlbGV0ZXMgYSBTZWN1cml0eSByZXNvdXJjZSBpbnN0YW5jZS5cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmRlbGV0ZVJlc291cmNlID0gY2Eoe1xyXG4gICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgIHVybDoge1xyXG4gICAgICBmbXQ6ICcvX3BsdWdpbnMvX3NlY3VyaXR5L2FwaS88JT1yZXNvdXJjZU5hbWUlPi88JT1pZCU+JyxcclxuICAgICAgcmVxOiB7XHJcbiAgICAgICAgcmVzb3VyY2VOYW1lOiB7XHJcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJyxcclxuICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaWQ6IHtcclxuICAgICAgICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIERlbGV0ZXMgYSBTZWN1cml0eSByZXNvdXJjZSBpbnN0YW5jZS5cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmNsZWFyQ2FjaGUgPSBjYSh7XHJcbiAgICBtZXRob2Q6ICdERUxFVEUnLFxyXG4gICAgdXJsOiB7XHJcbiAgICAgIGZtdDogJy9fcGx1Z2lucy9fc2VjdXJpdHkvYXBpL2NhY2hlJyxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFZhbGlkYXRlIHF1ZXJ5LlxyXG4gICAqL1xyXG4gIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eS5wcm90b3R5cGUudmFsaWRhdGVEbHMgPSBjYSh7XHJcbiAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgIG5lZWRCb2R5OiB0cnVlLFxyXG4gICAgdXJsOiB7XHJcbiAgICAgIGZtdDogJy9fdmFsaWRhdGUvcXVlcnk/ZXhwbGFpbj10cnVlJyxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgaW5kZXggbWFwcGluZy5cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmdldEluZGV4TWFwcGluZ3MgPSBjYSh7XHJcbiAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgbmVlZEJvZHk6IHRydWUsXHJcbiAgICB1cmw6IHtcclxuICAgICAgZm10OiAnLzwlPWluZGV4JT4vX21hcHBpbmcnLFxyXG4gICAgICByZXE6IHtcclxuICAgICAgICBpbmRleDoge1xyXG4gICAgICAgICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyBhdWRpdCBsb2cgY29uZmlndXJhdGlvbi5cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmdldEF1ZGl0ID0gY2Eoe1xyXG4gICAgbWV0aG9kOiAnR0VUJyxcclxuICAgIHVybDoge1xyXG4gICAgICBmbXQ6ICcvX3BsdWdpbnMvX3NlY3VyaXR5L2FwaS9hdWRpdCcsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICAvKipcclxuICAgKiBVcGRhdGVzIGF1ZGl0IGxvZyBjb25maWd1cmF0aW9uLlxyXG4gICAqL1xyXG4gIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eS5wcm90b3R5cGUuc2F2ZUF1ZGl0ID0gY2Eoe1xyXG4gICAgbWV0aG9kOiAnUFVUJyxcclxuICAgIG5lZWRCb2R5OiB0cnVlLFxyXG4gICAgdXJsOiB7XHJcbiAgICAgIGZtdDogJy9fcGx1Z2lucy9fc2VjdXJpdHkvYXBpL2F1ZGl0L2NvbmZpZycsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG59XHJcbiJdfQ==