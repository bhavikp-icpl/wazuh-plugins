"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.wazuhApiClient = void 0;

var ApiInterceptor = _interopRequireWildcard(require("./api-interceptor"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const wazuhApiClient = {
  client: {
    asInternalUser: {
      authenticate: async apiHostID => await ApiInterceptor.authenticate(apiHostID),
      request: async (method, path, data, options) => await ApiInterceptor.requestAsInternalUser(method, path, data, options)
    }
  }
};
exports.wazuhApiClient = wazuhApiClient;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS1jbGllbnQudHMiXSwibmFtZXMiOlsid2F6dWhBcGlDbGllbnQiLCJjbGllbnQiLCJhc0ludGVybmFsVXNlciIsImF1dGhlbnRpY2F0ZSIsImFwaUhvc3RJRCIsIkFwaUludGVyY2VwdG9yIiwicmVxdWVzdCIsIm1ldGhvZCIsInBhdGgiLCJkYXRhIiwib3B0aW9ucyIsInJlcXVlc3RBc0ludGVybmFsVXNlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBOzs7Ozs7QUFHTyxNQUFNQSxjQUFjLEdBQUc7QUFDMUJDLEVBQUFBLE1BQU0sRUFBRTtBQUNOQyxJQUFBQSxjQUFjLEVBQUU7QUFDZEMsTUFBQUEsWUFBWSxFQUFFLE1BQU9DLFNBQVAsSUFDWixNQUFNQyxjQUFjLENBQUNGLFlBQWYsQ0FBNEJDLFNBQTVCLENBRk07QUFHZEUsTUFBQUEsT0FBTyxFQUFFLE9BQU9DLE1BQVAsRUFBdUJDLElBQXZCLEVBQXFDQyxJQUFyQyxFQUFnREMsT0FBaEQsS0FDUCxNQUFNTCxjQUFjLENBQUNNLHFCQUFmLENBQ0pKLE1BREksRUFFSkMsSUFGSSxFQUdKQyxJQUhJLEVBSUpDLE9BSkk7QUFKTTtBQURWO0FBRGtCLENBQXZCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICAqIGFzIEFwaUludGVyY2VwdG9yIGZyb20gJy4vYXBpLWludGVyY2VwdG9yJztcbmltcG9ydCB7IEFQSUludGVyY2VwdG9yUmVxdWVzdE9wdGlvbnNJbnRlcm5hbFVzZXIgfSBmcm9tICcuL2FwaS1pbnRlcmNlcHRvcic7XG5cbmV4cG9ydCBjb25zdCB3YXp1aEFwaUNsaWVudCA9IHtcbiAgICBjbGllbnQ6IHtcbiAgICAgIGFzSW50ZXJuYWxVc2VyOiB7XG4gICAgICAgIGF1dGhlbnRpY2F0ZTogYXN5bmMgKGFwaUhvc3RJRDogc3RyaW5nKSA9PlxuICAgICAgICAgIGF3YWl0IEFwaUludGVyY2VwdG9yLmF1dGhlbnRpY2F0ZShhcGlIb3N0SUQpLFxuICAgICAgICByZXF1ZXN0OiBhc3luYyAobWV0aG9kOiBzdHJpbmcsIHBhdGg6IHN0cmluZywgZGF0YTogYW55LCBvcHRpb25zOiBBUElJbnRlcmNlcHRvclJlcXVlc3RPcHRpb25zSW50ZXJuYWxVc2VyKSA9PlxuICAgICAgICAgIGF3YWl0IEFwaUludGVyY2VwdG9yLnJlcXVlc3RBc0ludGVybmFsVXNlcihcbiAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICApLFxuICAgICAgfSxcbiAgICB9LFxuICB9OyJdfQ==