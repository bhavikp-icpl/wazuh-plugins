"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// eslint-disable-next-line import/no-default-export
function _default(Client, config, components) {
  const ca = components.clientAction.factory;

  if (!Client.prototype.opensearch_security) {
    Client.prototype.opensearch_security = components.clientAction.namespaceFactory();
  }
  /**
   * Gets auth info.
   */


  Client.prototype.opensearch_security.prototype.authinfo = ca({
    url: {
      fmt: '/_plugins/_security/authinfo'
    }
  });
  Client.prototype.opensearch_security.prototype.dashboardsinfo = ca({
    url: {
      fmt: '/_plugins/_security/dashboardsinfo'
    }
  });
  /**
   * Gets tenant info and opensearch-dashboards server info.
   *
   * e.g.
   * {
   *   "user_name": "admin",
   *   "not_fail_on_forbidden_enabled": false,
   *   "opensearch_dashboards_mt_enabled": true,
   *   "opensearch_dashboards_index": ".opensearch_dashboards",
   *   "opensearch_dashboards_server_user": "kibanaserver"
   * }
   */

  Client.prototype.opensearch_security.prototype.multitenancyinfo = ca({
    url: {
      fmt: '/_plugins/_security/dashboardsinfo'
    }
  });
  /**
   * Gets tenant info. The output looks like:
   * {
   *   ".opensearch_dashboards_92668751_admin":"__private__"
   * }
   */

  Client.prototype.opensearch_security.prototype.tenantinfo = ca({
    url: {
      fmt: '/_plugins/_security/tenantinfo'
    }
  });
  /**
   * Gets SAML token.
   */

  Client.prototype.opensearch_security.prototype.authtoken = ca({
    method: 'POST',
    needBody: true,
    url: {
      fmt: '/_plugins/_security/api/authtoken'
    }
  });
  Client.prototype.opensearch_security.prototype.tenancy_configs = ca({
    method: 'PUT',
    needBody: true,
    url: {
      fmt: '/_plugins/_security/api/tenancy/config'
    }
  });
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9wZW5zZWFyY2hfc2VjdXJpdHlfcGx1Z2luLnRzIl0sIm5hbWVzIjpbIkNsaWVudCIsImNvbmZpZyIsImNvbXBvbmVudHMiLCJjYSIsImNsaWVudEFjdGlvbiIsImZhY3RvcnkiLCJwcm90b3R5cGUiLCJvcGVuc2VhcmNoX3NlY3VyaXR5IiwibmFtZXNwYWNlRmFjdG9yeSIsImF1dGhpbmZvIiwidXJsIiwiZm10IiwiZGFzaGJvYXJkc2luZm8iLCJtdWx0aXRlbmFuY3lpbmZvIiwidGVuYW50aW5mbyIsImF1dGh0b2tlbiIsIm1ldGhvZCIsIm5lZWRCb2R5IiwidGVuYW5jeV9jb25maWdzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ2Usa0JBQVVBLE1BQVYsRUFBdUJDLE1BQXZCLEVBQW9DQyxVQUFwQyxFQUFxRDtBQUNsRSxRQUFNQyxFQUFFLEdBQUdELFVBQVUsQ0FBQ0UsWUFBWCxDQUF3QkMsT0FBbkM7O0FBRUEsTUFBSSxDQUFDTCxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUF0QixFQUEyQztBQUN6Q1AsSUFBQUEsTUFBTSxDQUFDTSxTQUFQLENBQWlCQyxtQkFBakIsR0FBdUNMLFVBQVUsQ0FBQ0UsWUFBWCxDQUF3QkksZ0JBQXhCLEVBQXZDO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFUixFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NHLFFBQS9DLEdBQTBETixFQUFFLENBQUM7QUFDM0RPLElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQURzRCxHQUFELENBQTVEO0FBTUFYLEVBQUFBLE1BQU0sQ0FBQ00sU0FBUCxDQUFpQkMsbUJBQWpCLENBQXFDRCxTQUFyQyxDQUErQ00sY0FBL0MsR0FBZ0VULEVBQUUsQ0FBQztBQUNqRU8sSUFBQUEsR0FBRyxFQUFFO0FBQ0hDLE1BQUFBLEdBQUcsRUFBRTtBQURGO0FBRDRELEdBQUQsQ0FBbEU7QUFNQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0VYLEVBQUFBLE1BQU0sQ0FBQ00sU0FBUCxDQUFpQkMsbUJBQWpCLENBQXFDRCxTQUFyQyxDQUErQ08sZ0JBQS9DLEdBQWtFVixFQUFFLENBQUM7QUFDbkVPLElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQUQ4RCxHQUFELENBQXBFO0FBTUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNFWCxFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NRLFVBQS9DLEdBQTREWCxFQUFFLENBQUM7QUFDN0RPLElBQUFBLEdBQUcsRUFBRTtBQUNIQyxNQUFBQSxHQUFHLEVBQUU7QUFERjtBQUR3RCxHQUFELENBQTlEO0FBTUE7QUFDRjtBQUNBOztBQUNFWCxFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NTLFNBQS9DLEdBQTJEWixFQUFFLENBQUM7QUFDNURhLElBQUFBLE1BQU0sRUFBRSxNQURvRDtBQUU1REMsSUFBQUEsUUFBUSxFQUFFLElBRmtEO0FBRzVEUCxJQUFBQSxHQUFHLEVBQUU7QUFDSEMsTUFBQUEsR0FBRyxFQUFFO0FBREY7QUFIdUQsR0FBRCxDQUE3RDtBQVFBWCxFQUFBQSxNQUFNLENBQUNNLFNBQVAsQ0FBaUJDLG1CQUFqQixDQUFxQ0QsU0FBckMsQ0FBK0NZLGVBQS9DLEdBQWlFZixFQUFFLENBQUM7QUFDbEVhLElBQUFBLE1BQU0sRUFBRSxLQUQwRDtBQUVsRUMsSUFBQUEsUUFBUSxFQUFFLElBRndEO0FBR2xFUCxJQUFBQSxHQUFHLEVBQUU7QUFDSEMsTUFBQUEsR0FBRyxFQUFFO0FBREY7QUFINkQsR0FBRCxDQUFuRTtBQU9EIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcclxuICpcclxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxyXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cclxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxyXG4gKlxyXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuICpcclxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcclxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xyXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLWRlZmF1bHQtZXhwb3J0XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIChDbGllbnQ6IGFueSwgY29uZmlnOiBhbnksIGNvbXBvbmVudHM6IGFueSkge1xyXG4gIGNvbnN0IGNhID0gY29tcG9uZW50cy5jbGllbnRBY3Rpb24uZmFjdG9yeTtcclxuXHJcbiAgaWYgKCFDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkpIHtcclxuICAgIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eSA9IGNvbXBvbmVudHMuY2xpZW50QWN0aW9uLm5hbWVzcGFjZUZhY3RvcnkoKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgYXV0aCBpbmZvLlxyXG4gICAqL1xyXG4gIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eS5wcm90b3R5cGUuYXV0aGluZm8gPSBjYSh7XHJcbiAgICB1cmw6IHtcclxuICAgICAgZm10OiAnL19wbHVnaW5zL19zZWN1cml0eS9hdXRoaW5mbycsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmRhc2hib2FyZHNpbmZvID0gY2Eoe1xyXG4gICAgdXJsOiB7XHJcbiAgICAgIGZtdDogJy9fcGx1Z2lucy9fc2VjdXJpdHkvZGFzaGJvYXJkc2luZm8nLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyB0ZW5hbnQgaW5mbyBhbmQgb3BlbnNlYXJjaC1kYXNoYm9hcmRzIHNlcnZlciBpbmZvLlxyXG4gICAqXHJcbiAgICogZS5nLlxyXG4gICAqIHtcclxuICAgKiAgIFwidXNlcl9uYW1lXCI6IFwiYWRtaW5cIixcclxuICAgKiAgIFwibm90X2ZhaWxfb25fZm9yYmlkZGVuX2VuYWJsZWRcIjogZmFsc2UsXHJcbiAgICogICBcIm9wZW5zZWFyY2hfZGFzaGJvYXJkc19tdF9lbmFibGVkXCI6IHRydWUsXHJcbiAgICogICBcIm9wZW5zZWFyY2hfZGFzaGJvYXJkc19pbmRleFwiOiBcIi5vcGVuc2VhcmNoX2Rhc2hib2FyZHNcIixcclxuICAgKiAgIFwib3BlbnNlYXJjaF9kYXNoYm9hcmRzX3NlcnZlcl91c2VyXCI6IFwia2liYW5hc2VydmVyXCJcclxuICAgKiB9XHJcbiAgICovXHJcbiAgQ2xpZW50LnByb3RvdHlwZS5vcGVuc2VhcmNoX3NlY3VyaXR5LnByb3RvdHlwZS5tdWx0aXRlbmFuY3lpbmZvID0gY2Eoe1xyXG4gICAgdXJsOiB7XHJcbiAgICAgIGZtdDogJy9fcGx1Z2lucy9fc2VjdXJpdHkvZGFzaGJvYXJkc2luZm8nLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyB0ZW5hbnQgaW5mby4gVGhlIG91dHB1dCBsb29rcyBsaWtlOlxyXG4gICAqIHtcclxuICAgKiAgIFwiLm9wZW5zZWFyY2hfZGFzaGJvYXJkc185MjY2ODc1MV9hZG1pblwiOlwiX19wcml2YXRlX19cIlxyXG4gICAqIH1cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLnRlbmFudGluZm8gPSBjYSh7XHJcbiAgICB1cmw6IHtcclxuICAgICAgZm10OiAnL19wbHVnaW5zL19zZWN1cml0eS90ZW5hbnRpbmZvJyxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgU0FNTCB0b2tlbi5cclxuICAgKi9cclxuICBDbGllbnQucHJvdG90eXBlLm9wZW5zZWFyY2hfc2VjdXJpdHkucHJvdG90eXBlLmF1dGh0b2tlbiA9IGNhKHtcclxuICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgbmVlZEJvZHk6IHRydWUsXHJcbiAgICB1cmw6IHtcclxuICAgICAgZm10OiAnL19wbHVnaW5zL19zZWN1cml0eS9hcGkvYXV0aHRva2VuJyxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIENsaWVudC5wcm90b3R5cGUub3BlbnNlYXJjaF9zZWN1cml0eS5wcm90b3R5cGUudGVuYW5jeV9jb25maWdzID0gY2Eoe1xyXG4gICAgbWV0aG9kOiAnUFVUJyxcclxuICAgIG5lZWRCb2R5OiB0cnVlLFxyXG4gICAgdXJsOiB7XHJcbiAgICAgIGZtdDogJy9fcGx1Z2lucy9fc2VjdXJpdHkvYXBpL3RlbmFuY3kvY29uZmlnJyxcclxuICAgIH0sXHJcbiAgfSk7XHJcbn1cclxuIl19