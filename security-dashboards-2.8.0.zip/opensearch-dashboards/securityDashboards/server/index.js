"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "SecurityPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.SecurityPluginSetup;
  }
});
Object.defineProperty(exports, "SecurityPluginStart", {
  enumerable: true,
  get: function () {
    return _types.SecurityPluginStart;
  }
});
exports.configSchema = exports.config = void 0;
exports.plugin = plugin;

var _configSchema = require("@osd/config-schema");

var _plugin = require("./plugin");

var _types = require("./types");

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
const validateAuthType = value => {
  const supportedAuthTypes = ['', 'basicauth', 'jwt', 'openid', 'saml', 'proxy', 'kerberos', 'proxycache'];
  value.forEach(authVal => {
    if (!supportedAuthTypes.includes(authVal.toLowerCase())) {
      throw new Error(`Unsupported authentication type: ${authVal}. Allowed auth.type are ${supportedAuthTypes}.`);
    }
  });
};

const configSchema = _configSchema.schema.object({
  enabled: _configSchema.schema.boolean({
    defaultValue: true
  }),
  allow_client_certificates: _configSchema.schema.boolean({
    defaultValue: false
  }),
  readonly_mode: _configSchema.schema.object({
    roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  }),
  clusterPermissions: _configSchema.schema.object({
    include: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  }),
  indexPermissions: _configSchema.schema.object({
    include: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  }),
  disabledTransportCategories: _configSchema.schema.object({
    exclude: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  }),
  disabledRestCategories: _configSchema.schema.object({
    exclude: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  }),
  cookie: _configSchema.schema.object({
    secure: _configSchema.schema.boolean({
      defaultValue: false
    }),
    name: _configSchema.schema.string({
      defaultValue: 'security_authentication'
    }),
    password: _configSchema.schema.string({
      defaultValue: 'security_cookie_default_password',
      minLength: 32
    }),
    ttl: _configSchema.schema.number({
      defaultValue: 60 * 60 * 1000
    }),
    domain: _configSchema.schema.nullable(_configSchema.schema.string()),
    isSameSite: _configSchema.schema.oneOf([_configSchema.schema.literal('Strict'), _configSchema.schema.literal('Lax'), _configSchema.schema.literal('None'), _configSchema.schema.literal(false)], {
      defaultValue: false
    })
  }),
  session: _configSchema.schema.object({
    ttl: _configSchema.schema.number({
      defaultValue: 60 * 60 * 1000
    }),
    keepalive: _configSchema.schema.boolean({
      defaultValue: true
    })
  }),
  auth: _configSchema.schema.object({
    type: _configSchema.schema.oneOf([_configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: [''],

      validate(value) {
        if (!value || value.length === 0) {
          return `Authentication type is not configured properly. At least one authentication type must be selected.`;
        }

        if (value.length > 1) {
          const includeBasicAuth = value.find(element => {
            return element.toLowerCase() === 'basicauth';
          });

          if (!includeBasicAuth) {
            return `Authentication type is not configured properly. basicauth is mandatory.`;
          }
        }

        validateAuthType(value);
      }

    }), _configSchema.schema.string({
      defaultValue: '',

      validate(value) {
        const valArray = [];
        valArray.push(value);
        validateAuthType(valArray);
      }

    })], {
      defaultValue: ''
    }),
    anonymous_auth_enabled: _configSchema.schema.boolean({
      defaultValue: false
    }),
    unauthenticated_routes: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: ['/api/reporting/stats']
    }),
    forbidden_usernames: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    logout_url: _configSchema.schema.string({
      defaultValue: ''
    }),
    multiple_auth_enabled: _configSchema.schema.boolean({
      defaultValue: false
    })
  }),
  basicauth: _configSchema.schema.object({
    enabled: _configSchema.schema.boolean({
      defaultValue: true
    }),
    unauthenticated_routes: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    forbidden_usernames: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    header_trumps_session: _configSchema.schema.boolean({
      defaultValue: false
    }),
    alternative_login: _configSchema.schema.object({
      headers: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
        defaultValue: []
      }),
      show_for_parameter: _configSchema.schema.string({
        defaultValue: ''
      }),
      valid_redirects: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
        defaultValue: []
      }),
      button_text: _configSchema.schema.string({
        defaultValue: 'Log in with provider'
      }),
      buttonstyle: _configSchema.schema.string({
        defaultValue: ''
      })
    }),
    loadbalancer_url: _configSchema.schema.maybe(_configSchema.schema.string()),
    login: _configSchema.schema.object({
      title: _configSchema.schema.string({
        defaultValue: ''
      }),
      subtitle: _configSchema.schema.string({
        defaultValue: ''
      }),
      showbrandimage: _configSchema.schema.boolean({
        defaultValue: true
      }),
      brandimage: _configSchema.schema.string({
        defaultValue: ''
      }),
      // TODO: update brand image
      buttonstyle: _configSchema.schema.string({
        defaultValue: ''
      })
    })
  }),
  multitenancy: _configSchema.schema.object({
    enabled: _configSchema.schema.boolean({
      defaultValue: false
    }),
    show_roles: _configSchema.schema.boolean({
      defaultValue: false
    }),
    enable_filter: _configSchema.schema.boolean({
      defaultValue: false
    }),
    debug: _configSchema.schema.boolean({
      defaultValue: false
    }),
    enable_aggregation_view: _configSchema.schema.boolean({
      defaultValue: false
    }),
    tenants: _configSchema.schema.object({
      enable_private: _configSchema.schema.boolean({
        defaultValue: true
      }),
      enable_global: _configSchema.schema.boolean({
        defaultValue: true
      }),
      preferred: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
        defaultValue: []
      })
    })
  }),
  configuration: _configSchema.schema.object({
    enabled: _configSchema.schema.boolean({
      defaultValue: true
    })
  }),
  accountinfo: _configSchema.schema.object({
    enabled: _configSchema.schema.boolean({
      defaultValue: false
    })
  }),
  openid: _configSchema.schema.maybe(_configSchema.schema.object({
    connect_url: _configSchema.schema.maybe(_configSchema.schema.string()),
    header: _configSchema.schema.string({
      defaultValue: 'Authorization'
    }),
    // TODO: test if siblingRef() works here
    // client_id is required when auth.type is openid
    client_id: _configSchema.schema.conditional(_configSchema.schema.siblingRef('auth.type'), 'openid', _configSchema.schema.string(), _configSchema.schema.maybe(_configSchema.schema.string())),
    client_secret: _configSchema.schema.string({
      defaultValue: ''
    }),
    scope: _configSchema.schema.string({
      defaultValue: 'openid profile email address phone'
    }),
    base_redirect_url: _configSchema.schema.string({
      defaultValue: ''
    }),
    logout_url: _configSchema.schema.string({
      defaultValue: ''
    }),
    root_ca: _configSchema.schema.string({
      defaultValue: ''
    }),
    verify_hostnames: _configSchema.schema.boolean({
      defaultValue: true
    }),
    refresh_tokens: _configSchema.schema.boolean({
      defaultValue: true
    }),
    trust_dynamic_headers: _configSchema.schema.boolean({
      defaultValue: false
    }),
    extra_storage: _configSchema.schema.object({
      cookie_prefix: _configSchema.schema.string({
        defaultValue: 'security_authentication_oidc',
        minLength: 2
      }),
      additional_cookies: _configSchema.schema.number({
        min: 1,
        defaultValue: 5
      })
    })
  })),
  saml: _configSchema.schema.object({
    extra_storage: _configSchema.schema.object({
      cookie_prefix: _configSchema.schema.string({
        defaultValue: 'security_authentication_saml',
        minLength: 2
      }),
      additional_cookies: _configSchema.schema.number({
        min: 0,
        defaultValue: 3
      })
    })
  }),
  proxycache: _configSchema.schema.maybe(_configSchema.schema.object({
    // when auth.type is proxycache, user_header, roles_header and proxy_header_ip are required
    user_header: _configSchema.schema.conditional(_configSchema.schema.siblingRef('auth.type'), 'proxycache', _configSchema.schema.string(), _configSchema.schema.maybe(_configSchema.schema.string())),
    roles_header: _configSchema.schema.conditional(_configSchema.schema.siblingRef('auth.type'), 'proxycache', _configSchema.schema.string(), _configSchema.schema.maybe(_configSchema.schema.string())),
    proxy_header: _configSchema.schema.maybe(_configSchema.schema.string({
      defaultValue: 'x-forwarded-for'
    })),
    proxy_header_ip: _configSchema.schema.conditional(_configSchema.schema.siblingRef('auth.type'), 'proxycache', _configSchema.schema.string(), _configSchema.schema.maybe(_configSchema.schema.string())),
    login_endpoint: _configSchema.schema.maybe(_configSchema.schema.string({
      defaultValue: ''
    }))
  })),
  jwt: _configSchema.schema.maybe(_configSchema.schema.object({
    enabled: _configSchema.schema.boolean({
      defaultValue: false
    }),
    login_endpoint: _configSchema.schema.maybe(_configSchema.schema.string()),
    url_param: _configSchema.schema.string({
      defaultValue: 'authorization'
    }),
    header: _configSchema.schema.string({
      defaultValue: 'Authorization'
    })
  })),
  ui: _configSchema.schema.object({
    basicauth: _configSchema.schema.object({
      // the login config here is the same as old config `_security.basicauth.login`
      // Since we are now rendering login page to browser app, so move these config to browser side.
      login: _configSchema.schema.object({
        title: _configSchema.schema.string({
          defaultValue: ''
        }),
        subtitle: _configSchema.schema.string({
          defaultValue: ''
        }),
        showbrandimage: _configSchema.schema.boolean({
          defaultValue: true
        }),
        brandimage: _configSchema.schema.string({
          defaultValue: ''
        }),
        buttonstyle: _configSchema.schema.string({
          defaultValue: ''
        })
      })
    }),
    anonymous: _configSchema.schema.object({
      login: _configSchema.schema.object({
        buttonname: _configSchema.schema.string({
          defaultValue: 'Log in as anonymous'
        }),
        showbrandimage: _configSchema.schema.boolean({
          defaultValue: false
        }),
        brandimage: _configSchema.schema.string({
          defaultValue: ''
        }),
        buttonstyle: _configSchema.schema.string({
          defaultValue: ''
        })
      })
    }),
    openid: _configSchema.schema.object({
      login: _configSchema.schema.object({
        buttonname: _configSchema.schema.string({
          defaultValue: 'Log in with single sign-on'
        }),
        showbrandimage: _configSchema.schema.boolean({
          defaultValue: false
        }),
        brandimage: _configSchema.schema.string({
          defaultValue: ''
        }),
        buttonstyle: _configSchema.schema.string({
          defaultValue: ''
        })
      })
    }),
    saml: _configSchema.schema.object({
      login: _configSchema.schema.object({
        buttonname: _configSchema.schema.string({
          defaultValue: 'Log in with single sign-on'
        }),
        showbrandimage: _configSchema.schema.boolean({
          defaultValue: false
        }),
        brandimage: _configSchema.schema.string({
          defaultValue: ''
        }),
        buttonstyle: _configSchema.schema.string({
          defaultValue: ''
        })
      })
    }),
    autologout: _configSchema.schema.boolean({
      defaultValue: true
    }),
    backend_configurable: _configSchema.schema.boolean({
      defaultValue: true
    })
  })
});

exports.configSchema = configSchema;
const config = {
  exposeToBrowser: {
    enabled: true,
    auth: true,
    ui: true,
    multitenancy: true,
    readonly_mode: true,
    clusterPermissions: true,
    indexPermissions: true,
    disabledTransportCategories: true,
    disabledRestCategories: true
  },
  schema: configSchema,
  deprecations: ({
    rename,
    unused
  }) => [rename('basicauth.login.title', 'ui.basicauth.login.title'), rename('basicauth.login.subtitle', 'ui.basicauth.login.subtitle'), rename('basicauth.login.showbrandimage', 'ui.basicauth.login.showbrandimage'), rename('basicauth.login.brandimage', 'ui.basicauth.login.brandimage'), rename('basicauth.login.buttonstyle', 'ui.basicauth.login.buttonstyle')]
}; //  This exports static code and TypeScript types,
//  as well as, OpenSearchDashboards Platform `plugin()` initializer.

exports.config = config;

function plugin(initializerContext) {
  return new _plugin.SecurityPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInZhbGlkYXRlQXV0aFR5cGUiLCJ2YWx1ZSIsInN1cHBvcnRlZEF1dGhUeXBlcyIsImZvckVhY2giLCJhdXRoVmFsIiwiaW5jbHVkZXMiLCJ0b0xvd2VyQ2FzZSIsIkVycm9yIiwiY29uZmlnU2NoZW1hIiwic2NoZW1hIiwib2JqZWN0IiwiZW5hYmxlZCIsImJvb2xlYW4iLCJkZWZhdWx0VmFsdWUiLCJhbGxvd19jbGllbnRfY2VydGlmaWNhdGVzIiwicmVhZG9ubHlfbW9kZSIsInJvbGVzIiwiYXJyYXlPZiIsInN0cmluZyIsImNsdXN0ZXJQZXJtaXNzaW9ucyIsImluY2x1ZGUiLCJpbmRleFBlcm1pc3Npb25zIiwiZGlzYWJsZWRUcmFuc3BvcnRDYXRlZ29yaWVzIiwiZXhjbHVkZSIsImRpc2FibGVkUmVzdENhdGVnb3JpZXMiLCJjb29raWUiLCJzZWN1cmUiLCJuYW1lIiwicGFzc3dvcmQiLCJtaW5MZW5ndGgiLCJ0dGwiLCJudW1iZXIiLCJkb21haW4iLCJudWxsYWJsZSIsImlzU2FtZVNpdGUiLCJvbmVPZiIsImxpdGVyYWwiLCJzZXNzaW9uIiwia2VlcGFsaXZlIiwiYXV0aCIsInR5cGUiLCJ2YWxpZGF0ZSIsImxlbmd0aCIsImluY2x1ZGVCYXNpY0F1dGgiLCJmaW5kIiwiZWxlbWVudCIsInZhbEFycmF5IiwicHVzaCIsImFub255bW91c19hdXRoX2VuYWJsZWQiLCJ1bmF1dGhlbnRpY2F0ZWRfcm91dGVzIiwiZm9yYmlkZGVuX3VzZXJuYW1lcyIsImxvZ291dF91cmwiLCJtdWx0aXBsZV9hdXRoX2VuYWJsZWQiLCJiYXNpY2F1dGgiLCJoZWFkZXJfdHJ1bXBzX3Nlc3Npb24iLCJhbHRlcm5hdGl2ZV9sb2dpbiIsImhlYWRlcnMiLCJzaG93X2Zvcl9wYXJhbWV0ZXIiLCJ2YWxpZF9yZWRpcmVjdHMiLCJidXR0b25fdGV4dCIsImJ1dHRvbnN0eWxlIiwibG9hZGJhbGFuY2VyX3VybCIsIm1heWJlIiwibG9naW4iLCJ0aXRsZSIsInN1YnRpdGxlIiwic2hvd2JyYW5kaW1hZ2UiLCJicmFuZGltYWdlIiwibXVsdGl0ZW5hbmN5Iiwic2hvd19yb2xlcyIsImVuYWJsZV9maWx0ZXIiLCJkZWJ1ZyIsImVuYWJsZV9hZ2dyZWdhdGlvbl92aWV3IiwidGVuYW50cyIsImVuYWJsZV9wcml2YXRlIiwiZW5hYmxlX2dsb2JhbCIsInByZWZlcnJlZCIsImNvbmZpZ3VyYXRpb24iLCJhY2NvdW50aW5mbyIsIm9wZW5pZCIsImNvbm5lY3RfdXJsIiwiaGVhZGVyIiwiY2xpZW50X2lkIiwiY29uZGl0aW9uYWwiLCJzaWJsaW5nUmVmIiwiY2xpZW50X3NlY3JldCIsInNjb3BlIiwiYmFzZV9yZWRpcmVjdF91cmwiLCJyb290X2NhIiwidmVyaWZ5X2hvc3RuYW1lcyIsInJlZnJlc2hfdG9rZW5zIiwidHJ1c3RfZHluYW1pY19oZWFkZXJzIiwiZXh0cmFfc3RvcmFnZSIsImNvb2tpZV9wcmVmaXgiLCJhZGRpdGlvbmFsX2Nvb2tpZXMiLCJtaW4iLCJzYW1sIiwicHJveHljYWNoZSIsInVzZXJfaGVhZGVyIiwicm9sZXNfaGVhZGVyIiwicHJveHlfaGVhZGVyIiwicHJveHlfaGVhZGVyX2lwIiwibG9naW5fZW5kcG9pbnQiLCJqd3QiLCJ1cmxfcGFyYW0iLCJ1aSIsImFub255bW91cyIsImJ1dHRvbm5hbWUiLCJhdXRvbG9nb3V0IiwiYmFja2VuZF9jb25maWd1cmFibGUiLCJjb25maWciLCJleHBvc2VUb0Jyb3dzZXIiLCJkZXByZWNhdGlvbnMiLCJyZW5hbWUiLCJ1bnVzZWQiLCJwbHVnaW4iLCJpbml0aWFsaXplckNvbnRleHQiLCJTZWN1cml0eVBsdWdpbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFlQTs7QUFFQTs7QUEyUkE7O0FBNVNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNQSxNQUFNQSxnQkFBZ0IsR0FBSUMsS0FBRCxJQUFxQjtBQUM1QyxRQUFNQyxrQkFBa0IsR0FBRyxDQUN6QixFQUR5QixFQUV6QixXQUZ5QixFQUd6QixLQUh5QixFQUl6QixRQUp5QixFQUt6QixNQUx5QixFQU16QixPQU55QixFQU96QixVQVB5QixFQVF6QixZQVJ5QixDQUEzQjtBQVdBRCxFQUFBQSxLQUFLLENBQUNFLE9BQU4sQ0FBZUMsT0FBRCxJQUFhO0FBQ3pCLFFBQUksQ0FBQ0Ysa0JBQWtCLENBQUNHLFFBQW5CLENBQTRCRCxPQUFPLENBQUNFLFdBQVIsRUFBNUIsQ0FBTCxFQUF5RDtBQUN2RCxZQUFNLElBQUlDLEtBQUosQ0FDSCxvQ0FBbUNILE9BQVEsMkJBQTBCRixrQkFBbUIsR0FEckYsQ0FBTjtBQUdEO0FBQ0YsR0FORDtBQU9ELENBbkJEOztBQXFCTyxNQUFNTSxZQUFZLEdBQUdDLHFCQUFPQyxNQUFQLENBQWM7QUFDeENDLEVBQUFBLE9BQU8sRUFBRUYscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxJQUFBQSxZQUFZLEVBQUU7QUFBaEIsR0FBZixDQUQrQjtBQUV4Q0MsRUFBQUEseUJBQXlCLEVBQUVMLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsSUFBQUEsWUFBWSxFQUFFO0FBQWhCLEdBQWYsQ0FGYTtBQUd4Q0UsRUFBQUEsYUFBYSxFQUFFTixxQkFBT0MsTUFBUCxDQUFjO0FBQzNCTSxJQUFBQSxLQUFLLEVBQUVQLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDO0FBRG9CLEdBQWQsQ0FIeUI7QUFNeENNLEVBQUFBLGtCQUFrQixFQUFFVixxQkFBT0MsTUFBUCxDQUFjO0FBQ2hDVSxJQUFBQSxPQUFPLEVBQUVYLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDO0FBRHVCLEdBQWQsQ0FOb0I7QUFTeENRLEVBQUFBLGdCQUFnQixFQUFFWixxQkFBT0MsTUFBUCxDQUFjO0FBQzlCVSxJQUFBQSxPQUFPLEVBQUVYLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDO0FBRHFCLEdBQWQsQ0FUc0I7QUFZeENTLEVBQUFBLDJCQUEyQixFQUFFYixxQkFBT0MsTUFBUCxDQUFjO0FBQ3pDYSxJQUFBQSxPQUFPLEVBQUVkLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDO0FBRGdDLEdBQWQsQ0FaVztBQWV4Q1csRUFBQUEsc0JBQXNCLEVBQUVmLHFCQUFPQyxNQUFQLENBQWM7QUFDcENhLElBQUFBLE9BQU8sRUFBRWQscUJBQU9RLE9BQVAsQ0FBZVIscUJBQU9TLE1BQVAsRUFBZixFQUFnQztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBaEM7QUFEMkIsR0FBZCxDQWZnQjtBQWtCeENZLEVBQUFBLE1BQU0sRUFBRWhCLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJnQixJQUFBQSxNQUFNLEVBQUVqQixxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmLENBRFk7QUFFcEJjLElBQUFBLElBQUksRUFBRWxCLHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWQsQ0FGYztBQUdwQmUsSUFBQUEsUUFBUSxFQUFFbkIscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUUsa0NBQWhCO0FBQW9EZ0IsTUFBQUEsU0FBUyxFQUFFO0FBQS9ELEtBQWQsQ0FIVTtBQUlwQkMsSUFBQUEsR0FBRyxFQUFFckIscUJBQU9zQixNQUFQLENBQWM7QUFBRWxCLE1BQUFBLFlBQVksRUFBRSxLQUFLLEVBQUwsR0FBVTtBQUExQixLQUFkLENBSmU7QUFLcEJtQixJQUFBQSxNQUFNLEVBQUV2QixxQkFBT3dCLFFBQVAsQ0FBZ0J4QixxQkFBT1MsTUFBUCxFQUFoQixDQUxZO0FBTXBCZ0IsSUFBQUEsVUFBVSxFQUFFekIscUJBQU8wQixLQUFQLENBQ1YsQ0FDRTFCLHFCQUFPMkIsT0FBUCxDQUFlLFFBQWYsQ0FERixFQUVFM0IscUJBQU8yQixPQUFQLENBQWUsS0FBZixDQUZGLEVBR0UzQixxQkFBTzJCLE9BQVAsQ0FBZSxNQUFmLENBSEYsRUFJRTNCLHFCQUFPMkIsT0FBUCxDQUFlLEtBQWYsQ0FKRixDQURVLEVBT1Y7QUFBRXZCLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQVBVO0FBTlEsR0FBZCxDQWxCZ0M7QUFrQ3hDd0IsRUFBQUEsT0FBTyxFQUFFNUIscUJBQU9DLE1BQVAsQ0FBYztBQUNyQm9CLElBQUFBLEdBQUcsRUFBRXJCLHFCQUFPc0IsTUFBUCxDQUFjO0FBQUVsQixNQUFBQSxZQUFZLEVBQUUsS0FBSyxFQUFMLEdBQVU7QUFBMUIsS0FBZCxDQURnQjtBQUVyQnlCLElBQUFBLFNBQVMsRUFBRTdCLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWY7QUFGVSxHQUFkLENBbEMrQjtBQXNDeEMwQixFQUFBQSxJQUFJLEVBQUU5QixxQkFBT0MsTUFBUCxDQUFjO0FBQ2xCOEIsSUFBQUEsSUFBSSxFQUFFL0IscUJBQU8wQixLQUFQLENBQ0osQ0FDRTFCLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFDOUJMLE1BQUFBLFlBQVksRUFBRSxDQUFDLEVBQUQsQ0FEZ0I7O0FBRTlCNEIsTUFBQUEsUUFBUSxDQUFDeEMsS0FBRCxFQUFrQjtBQUN4QixZQUFJLENBQUNBLEtBQUQsSUFBVUEsS0FBSyxDQUFDeUMsTUFBTixLQUFpQixDQUEvQixFQUFrQztBQUNoQyxpQkFBUSxvR0FBUjtBQUNEOztBQUVELFlBQUl6QyxLQUFLLENBQUN5QyxNQUFOLEdBQWUsQ0FBbkIsRUFBc0I7QUFDcEIsZ0JBQU1DLGdCQUFnQixHQUFHMUMsS0FBSyxDQUFDMkMsSUFBTixDQUFZQyxPQUFELElBQWE7QUFDL0MsbUJBQU9BLE9BQU8sQ0FBQ3ZDLFdBQVIsT0FBMEIsV0FBakM7QUFDRCxXQUZ3QixDQUF6Qjs7QUFJQSxjQUFJLENBQUNxQyxnQkFBTCxFQUF1QjtBQUNyQixtQkFBUSx5RUFBUjtBQUNEO0FBQ0Y7O0FBRUQzQyxRQUFBQSxnQkFBZ0IsQ0FBQ0MsS0FBRCxDQUFoQjtBQUNEOztBQWxCNkIsS0FBaEMsQ0FERixFQXFCRVEscUJBQU9TLE1BQVAsQ0FBYztBQUNaTCxNQUFBQSxZQUFZLEVBQUUsRUFERjs7QUFFWjRCLE1BQUFBLFFBQVEsQ0FBQ3hDLEtBQUQsRUFBUTtBQUNkLGNBQU02QyxRQUFrQixHQUFHLEVBQTNCO0FBQ0FBLFFBQUFBLFFBQVEsQ0FBQ0MsSUFBVCxDQUFjOUMsS0FBZDtBQUNBRCxRQUFBQSxnQkFBZ0IsQ0FBQzhDLFFBQUQsQ0FBaEI7QUFDRDs7QUFOVyxLQUFkLENBckJGLENBREksRUErQko7QUFBRWpDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQS9CSSxDQURZO0FBa0NsQm1DLElBQUFBLHNCQUFzQixFQUFFdkMscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZixDQWxDTjtBQW1DbEJvQyxJQUFBQSxzQkFBc0IsRUFBRXhDLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFDdERMLE1BQUFBLFlBQVksRUFBRSxDQUFDLHNCQUFEO0FBRHdDLEtBQWhDLENBbkNOO0FBc0NsQnFDLElBQUFBLG1CQUFtQixFQUFFekMscUJBQU9RLE9BQVAsQ0FBZVIscUJBQU9TLE1BQVAsRUFBZixFQUFnQztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBaEMsQ0F0Q0g7QUF1Q2xCc0MsSUFBQUEsVUFBVSxFQUFFMUMscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZCxDQXZDTTtBQXdDbEJ1QyxJQUFBQSxxQkFBcUIsRUFBRTNDLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWY7QUF4Q0wsR0FBZCxDQXRDa0M7QUFnRnhDd0MsRUFBQUEsU0FBUyxFQUFFNUMscUJBQU9DLE1BQVAsQ0FBYztBQUN2QkMsSUFBQUEsT0FBTyxFQUFFRixxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmLENBRGM7QUFFdkJvQyxJQUFBQSxzQkFBc0IsRUFBRXhDLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBRkQ7QUFHdkJxQyxJQUFBQSxtQkFBbUIsRUFBRXpDLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBSEU7QUFJdkJ5QyxJQUFBQSxxQkFBcUIsRUFBRTdDLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWYsQ0FKQTtBQUt2QjBDLElBQUFBLGlCQUFpQixFQUFFOUMscUJBQU9DLE1BQVAsQ0FBYztBQUMvQjhDLE1BQUFBLE9BQU8sRUFBRS9DLHFCQUFPUSxPQUFQLENBQWVSLHFCQUFPUyxNQUFQLEVBQWYsRUFBZ0M7QUFBRUwsUUFBQUEsWUFBWSxFQUFFO0FBQWhCLE9BQWhDLENBRHNCO0FBRS9CNEMsTUFBQUEsa0JBQWtCLEVBQUVoRCxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkLENBRlc7QUFHL0I2QyxNQUFBQSxlQUFlLEVBQUVqRCxxQkFBT1EsT0FBUCxDQUFlUixxQkFBT1MsTUFBUCxFQUFmLEVBQWdDO0FBQUVMLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFoQyxDQUhjO0FBSS9COEMsTUFBQUEsV0FBVyxFQUFFbEQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBZCxDQUprQjtBQUsvQitDLE1BQUFBLFdBQVcsRUFBRW5ELHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsUUFBQUEsWUFBWSxFQUFFO0FBQWhCLE9BQWQ7QUFMa0IsS0FBZCxDQUxJO0FBWXZCZ0QsSUFBQUEsZ0JBQWdCLEVBQUVwRCxxQkFBT3FELEtBQVAsQ0FBYXJELHFCQUFPUyxNQUFQLEVBQWIsQ0FaSztBQWF2QjZDLElBQUFBLEtBQUssRUFBRXRELHFCQUFPQyxNQUFQLENBQWM7QUFDbkJzRCxNQUFBQSxLQUFLLEVBQUV2RCxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkLENBRFk7QUFFbkJvRCxNQUFBQSxRQUFRLEVBQUV4RCxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkLENBRlM7QUFHbkJxRCxNQUFBQSxjQUFjLEVBQUV6RCxxQkFBT0csT0FBUCxDQUFlO0FBQUVDLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFmLENBSEc7QUFJbkJzRCxNQUFBQSxVQUFVLEVBQUUxRCxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkLENBSk87QUFJOEI7QUFDakQrQyxNQUFBQSxXQUFXLEVBQUVuRCxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkO0FBTE0sS0FBZDtBQWJnQixHQUFkLENBaEY2QjtBQXFHeEN1RCxFQUFBQSxZQUFZLEVBQUUzRCxxQkFBT0MsTUFBUCxDQUFjO0FBQzFCQyxJQUFBQSxPQUFPLEVBQUVGLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWYsQ0FEaUI7QUFFMUJ3RCxJQUFBQSxVQUFVLEVBQUU1RCxxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmLENBRmM7QUFHMUJ5RCxJQUFBQSxhQUFhLEVBQUU3RCxxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmLENBSFc7QUFJMUIwRCxJQUFBQSxLQUFLLEVBQUU5RCxxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmLENBSm1CO0FBSzFCMkQsSUFBQUEsdUJBQXVCLEVBQUUvRCxxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmLENBTEM7QUFNMUI0RCxJQUFBQSxPQUFPLEVBQUVoRSxxQkFBT0MsTUFBUCxDQUFjO0FBQ3JCZ0UsTUFBQUEsY0FBYyxFQUFFakUscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBZixDQURLO0FBRXJCOEQsTUFBQUEsYUFBYSxFQUFFbEUscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBZixDQUZNO0FBR3JCK0QsTUFBQUEsU0FBUyxFQUFFbkUscUJBQU9RLE9BQVAsQ0FBZVIscUJBQU9TLE1BQVAsRUFBZixFQUFnQztBQUFFTCxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBaEM7QUFIVSxLQUFkO0FBTmlCLEdBQWQsQ0FyRzBCO0FBaUh4Q2dFLEVBQUFBLGFBQWEsRUFBRXBFLHFCQUFPQyxNQUFQLENBQWM7QUFDM0JDLElBQUFBLE9BQU8sRUFBRUYscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZjtBQURrQixHQUFkLENBakh5QjtBQW9IeENpRSxFQUFBQSxXQUFXLEVBQUVyRSxxQkFBT0MsTUFBUCxDQUFjO0FBQ3pCQyxJQUFBQSxPQUFPLEVBQUVGLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWY7QUFEZ0IsR0FBZCxDQXBIMkI7QUF1SHhDa0UsRUFBQUEsTUFBTSxFQUFFdEUscUJBQU9xRCxLQUFQLENBQ05yRCxxQkFBT0MsTUFBUCxDQUFjO0FBQ1pzRSxJQUFBQSxXQUFXLEVBQUV2RSxxQkFBT3FELEtBQVAsQ0FBYXJELHFCQUFPUyxNQUFQLEVBQWIsQ0FERDtBQUVaK0QsSUFBQUEsTUFBTSxFQUFFeEUscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZCxDQUZJO0FBR1o7QUFDQTtBQUNBcUUsSUFBQUEsU0FBUyxFQUFFekUscUJBQU8wRSxXQUFQLENBQ1QxRSxxQkFBTzJFLFVBQVAsQ0FBa0IsV0FBbEIsQ0FEUyxFQUVULFFBRlMsRUFHVDNFLHFCQUFPUyxNQUFQLEVBSFMsRUFJVFQscUJBQU9xRCxLQUFQLENBQWFyRCxxQkFBT1MsTUFBUCxFQUFiLENBSlMsQ0FMQztBQVdabUUsSUFBQUEsYUFBYSxFQUFFNUUscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZCxDQVhIO0FBWVp5RSxJQUFBQSxLQUFLLEVBQUU3RSxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFkLENBWks7QUFhWjBFLElBQUFBLGlCQUFpQixFQUFFOUUscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZCxDQWJQO0FBY1pzQyxJQUFBQSxVQUFVLEVBQUUxQyxxQkFBT1MsTUFBUCxDQUFjO0FBQUVMLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFkLENBZEE7QUFlWjJFLElBQUFBLE9BQU8sRUFBRS9FLHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWQsQ0FmRztBQWdCWjRFLElBQUFBLGdCQUFnQixFQUFFaEYscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZixDQWhCTjtBQWlCWjZFLElBQUFBLGNBQWMsRUFBRWpGLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWYsQ0FqQko7QUFrQlo4RSxJQUFBQSxxQkFBcUIsRUFBRWxGLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWYsQ0FsQlg7QUFtQlorRSxJQUFBQSxhQUFhLEVBQUVuRixxQkFBT0MsTUFBUCxDQUFjO0FBQzNCbUYsTUFBQUEsYUFBYSxFQUFFcEYscUJBQU9TLE1BQVAsQ0FBYztBQUMzQkwsUUFBQUEsWUFBWSxFQUFFLDhCQURhO0FBRTNCZ0IsUUFBQUEsU0FBUyxFQUFFO0FBRmdCLE9BQWQsQ0FEWTtBQUszQmlFLE1BQUFBLGtCQUFrQixFQUFFckYscUJBQU9zQixNQUFQLENBQWM7QUFBRWdFLFFBQUFBLEdBQUcsRUFBRSxDQUFQO0FBQVVsRixRQUFBQSxZQUFZLEVBQUU7QUFBeEIsT0FBZDtBQUxPLEtBQWQ7QUFuQkgsR0FBZCxDQURNLENBdkhnQztBQW9KeENtRixFQUFBQSxJQUFJLEVBQUV2RixxQkFBT0MsTUFBUCxDQUFjO0FBQ2xCa0YsSUFBQUEsYUFBYSxFQUFFbkYscUJBQU9DLE1BQVAsQ0FBYztBQUMzQm1GLE1BQUFBLGFBQWEsRUFBRXBGLHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsUUFBQUEsWUFBWSxFQUFFLDhCQUFoQjtBQUFnRGdCLFFBQUFBLFNBQVMsRUFBRTtBQUEzRCxPQUFkLENBRFk7QUFFM0JpRSxNQUFBQSxrQkFBa0IsRUFBRXJGLHFCQUFPc0IsTUFBUCxDQUFjO0FBQUVnRSxRQUFBQSxHQUFHLEVBQUUsQ0FBUDtBQUFVbEYsUUFBQUEsWUFBWSxFQUFFO0FBQXhCLE9BQWQ7QUFGTyxLQUFkO0FBREcsR0FBZCxDQXBKa0M7QUEySnhDb0YsRUFBQUEsVUFBVSxFQUFFeEYscUJBQU9xRCxLQUFQLENBQ1ZyRCxxQkFBT0MsTUFBUCxDQUFjO0FBQ1o7QUFDQXdGLElBQUFBLFdBQVcsRUFBRXpGLHFCQUFPMEUsV0FBUCxDQUNYMUUscUJBQU8yRSxVQUFQLENBQWtCLFdBQWxCLENBRFcsRUFFWCxZQUZXLEVBR1gzRSxxQkFBT1MsTUFBUCxFQUhXLEVBSVhULHFCQUFPcUQsS0FBUCxDQUFhckQscUJBQU9TLE1BQVAsRUFBYixDQUpXLENBRkQ7QUFRWmlGLElBQUFBLFlBQVksRUFBRTFGLHFCQUFPMEUsV0FBUCxDQUNaMUUscUJBQU8yRSxVQUFQLENBQWtCLFdBQWxCLENBRFksRUFFWixZQUZZLEVBR1ozRSxxQkFBT1MsTUFBUCxFQUhZLEVBSVpULHFCQUFPcUQsS0FBUCxDQUFhckQscUJBQU9TLE1BQVAsRUFBYixDQUpZLENBUkY7QUFjWmtGLElBQUFBLFlBQVksRUFBRTNGLHFCQUFPcUQsS0FBUCxDQUFhckQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZCxDQUFiLENBZEY7QUFlWndGLElBQUFBLGVBQWUsRUFBRTVGLHFCQUFPMEUsV0FBUCxDQUNmMUUscUJBQU8yRSxVQUFQLENBQWtCLFdBQWxCLENBRGUsRUFFZixZQUZlLEVBR2YzRSxxQkFBT1MsTUFBUCxFQUhlLEVBSWZULHFCQUFPcUQsS0FBUCxDQUFhckQscUJBQU9TLE1BQVAsRUFBYixDQUplLENBZkw7QUFxQlpvRixJQUFBQSxjQUFjLEVBQUU3RixxQkFBT3FELEtBQVAsQ0FBYXJELHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWQsQ0FBYjtBQXJCSixHQUFkLENBRFUsQ0EzSjRCO0FBb0x4QzBGLEVBQUFBLEdBQUcsRUFBRTlGLHFCQUFPcUQsS0FBUCxDQUNIckQscUJBQU9DLE1BQVAsQ0FBYztBQUNaQyxJQUFBQSxPQUFPLEVBQUVGLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWYsQ0FERztBQUVaeUYsSUFBQUEsY0FBYyxFQUFFN0YscUJBQU9xRCxLQUFQLENBQWFyRCxxQkFBT1MsTUFBUCxFQUFiLENBRko7QUFHWnNGLElBQUFBLFNBQVMsRUFBRS9GLHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWQsQ0FIQztBQUlab0UsSUFBQUEsTUFBTSxFQUFFeEUscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBZDtBQUpJLEdBQWQsQ0FERyxDQXBMbUM7QUE0THhDNEYsRUFBQUEsRUFBRSxFQUFFaEcscUJBQU9DLE1BQVAsQ0FBYztBQUNoQjJDLElBQUFBLFNBQVMsRUFBRTVDLHFCQUFPQyxNQUFQLENBQWM7QUFDdkI7QUFDQTtBQUNBcUQsTUFBQUEsS0FBSyxFQUFFdEQscUJBQU9DLE1BQVAsQ0FBYztBQUNuQnNELFFBQUFBLEtBQUssRUFBRXZELHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsVUFBQUEsWUFBWSxFQUFFO0FBQWhCLFNBQWQsQ0FEWTtBQUVuQm9ELFFBQUFBLFFBQVEsRUFBRXhELHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsVUFBQUEsWUFBWSxFQUFFO0FBQWhCLFNBQWQsQ0FGUztBQUduQnFELFFBQUFBLGNBQWMsRUFBRXpELHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsVUFBQUEsWUFBWSxFQUFFO0FBQWhCLFNBQWYsQ0FIRztBQUluQnNELFFBQUFBLFVBQVUsRUFBRTFELHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsVUFBQUEsWUFBWSxFQUFFO0FBQWhCLFNBQWQsQ0FKTztBQUtuQitDLFFBQUFBLFdBQVcsRUFBRW5ELHFCQUFPUyxNQUFQLENBQWM7QUFBRUwsVUFBQUEsWUFBWSxFQUFFO0FBQWhCLFNBQWQ7QUFMTSxPQUFkO0FBSGdCLEtBQWQsQ0FESztBQVloQjZGLElBQUFBLFNBQVMsRUFBRWpHLHFCQUFPQyxNQUFQLENBQWM7QUFDdkJxRCxNQUFBQSxLQUFLLEVBQUV0RCxxQkFBT0MsTUFBUCxDQUFjO0FBQ25CaUcsUUFBQUEsVUFBVSxFQUFFbEcscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZCxDQURPO0FBRW5CcUQsUUFBQUEsY0FBYyxFQUFFekQscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZixDQUZHO0FBR25Cc0QsUUFBQUEsVUFBVSxFQUFFMUQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZCxDQUhPO0FBSW5CK0MsUUFBQUEsV0FBVyxFQUFFbkQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZDtBQUpNLE9BQWQ7QUFEZ0IsS0FBZCxDQVpLO0FBb0JoQmtFLElBQUFBLE1BQU0sRUFBRXRFLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJxRCxNQUFBQSxLQUFLLEVBQUV0RCxxQkFBT0MsTUFBUCxDQUFjO0FBQ25CaUcsUUFBQUEsVUFBVSxFQUFFbEcscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZCxDQURPO0FBRW5CcUQsUUFBQUEsY0FBYyxFQUFFekQscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZixDQUZHO0FBR25Cc0QsUUFBQUEsVUFBVSxFQUFFMUQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZCxDQUhPO0FBSW5CK0MsUUFBQUEsV0FBVyxFQUFFbkQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZDtBQUpNLE9BQWQ7QUFEYSxLQUFkLENBcEJRO0FBNEJoQm1GLElBQUFBLElBQUksRUFBRXZGLHFCQUFPQyxNQUFQLENBQWM7QUFDbEJxRCxNQUFBQSxLQUFLLEVBQUV0RCxxQkFBT0MsTUFBUCxDQUFjO0FBQ25CaUcsUUFBQUEsVUFBVSxFQUFFbEcscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZCxDQURPO0FBRW5CcUQsUUFBQUEsY0FBYyxFQUFFekQscUJBQU9HLE9BQVAsQ0FBZTtBQUFFQyxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZixDQUZHO0FBR25Cc0QsUUFBQUEsVUFBVSxFQUFFMUQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZCxDQUhPO0FBSW5CK0MsUUFBQUEsV0FBVyxFQUFFbkQscUJBQU9TLE1BQVAsQ0FBYztBQUFFTCxVQUFBQSxZQUFZLEVBQUU7QUFBaEIsU0FBZDtBQUpNLE9BQWQ7QUFEVyxLQUFkLENBNUJVO0FBb0NoQitGLElBQUFBLFVBQVUsRUFBRW5HLHFCQUFPRyxPQUFQLENBQWU7QUFBRUMsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWYsQ0FwQ0k7QUFxQ2hCZ0csSUFBQUEsb0JBQW9CLEVBQUVwRyxxQkFBT0csT0FBUCxDQUFlO0FBQUVDLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFmO0FBckNOLEdBQWQ7QUE1TG9DLENBQWQsQ0FBckI7OztBQXVPQSxNQUFNaUcsTUFBd0QsR0FBRztBQUN0RUMsRUFBQUEsZUFBZSxFQUFFO0FBQ2ZwRyxJQUFBQSxPQUFPLEVBQUUsSUFETTtBQUVmNEIsSUFBQUEsSUFBSSxFQUFFLElBRlM7QUFHZmtFLElBQUFBLEVBQUUsRUFBRSxJQUhXO0FBSWZyQyxJQUFBQSxZQUFZLEVBQUUsSUFKQztBQUtmckQsSUFBQUEsYUFBYSxFQUFFLElBTEE7QUFNZkksSUFBQUEsa0JBQWtCLEVBQUUsSUFOTDtBQU9mRSxJQUFBQSxnQkFBZ0IsRUFBRSxJQVBIO0FBUWZDLElBQUFBLDJCQUEyQixFQUFFLElBUmQ7QUFTZkUsSUFBQUEsc0JBQXNCLEVBQUU7QUFUVCxHQURxRDtBQVl0RWYsRUFBQUEsTUFBTSxFQUFFRCxZQVo4RDtBQWF0RXdHLEVBQUFBLFlBQVksRUFBRSxDQUFDO0FBQUVDLElBQUFBLE1BQUY7QUFBVUMsSUFBQUE7QUFBVixHQUFELEtBQXdCLENBQ3BDRCxNQUFNLENBQUMsdUJBQUQsRUFBMEIsMEJBQTFCLENBRDhCLEVBRXBDQSxNQUFNLENBQUMsMEJBQUQsRUFBNkIsNkJBQTdCLENBRjhCLEVBR3BDQSxNQUFNLENBQUMsZ0NBQUQsRUFBbUMsbUNBQW5DLENBSDhCLEVBSXBDQSxNQUFNLENBQUMsNEJBQUQsRUFBK0IsK0JBQS9CLENBSjhCLEVBS3BDQSxNQUFNLENBQUMsNkJBQUQsRUFBZ0MsZ0NBQWhDLENBTDhCO0FBYmdDLENBQWpFLEMsQ0FzQlA7QUFDQTs7OztBQUVPLFNBQVNFLE1BQVQsQ0FBZ0JDLGtCQUFoQixFQUE4RDtBQUNuRSxTQUFPLElBQUlDLHNCQUFKLENBQW1CRCxrQkFBbkIsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcclxuICpcclxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxyXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cclxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxyXG4gKlxyXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuICpcclxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcclxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xyXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG5pbXBvcnQgeyBzY2hlbWEsIFR5cGVPZiB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XHJcbmltcG9ydCB7IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCwgUGx1Z2luQ29uZmlnRGVzY3JpcHRvciB9IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XHJcbmltcG9ydCB7IFNlY3VyaXR5UGx1Z2luIH0gZnJvbSAnLi9wbHVnaW4nO1xyXG5cclxuY29uc3QgdmFsaWRhdGVBdXRoVHlwZSA9ICh2YWx1ZTogc3RyaW5nW10pID0+IHtcclxuICBjb25zdCBzdXBwb3J0ZWRBdXRoVHlwZXMgPSBbXHJcbiAgICAnJyxcclxuICAgICdiYXNpY2F1dGgnLFxyXG4gICAgJ2p3dCcsXHJcbiAgICAnb3BlbmlkJyxcclxuICAgICdzYW1sJyxcclxuICAgICdwcm94eScsXHJcbiAgICAna2VyYmVyb3MnLFxyXG4gICAgJ3Byb3h5Y2FjaGUnLFxyXG4gIF07XHJcblxyXG4gIHZhbHVlLmZvckVhY2goKGF1dGhWYWwpID0+IHtcclxuICAgIGlmICghc3VwcG9ydGVkQXV0aFR5cGVzLmluY2x1ZGVzKGF1dGhWYWwudG9Mb3dlckNhc2UoKSkpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgIGBVbnN1cHBvcnRlZCBhdXRoZW50aWNhdGlvbiB0eXBlOiAke2F1dGhWYWx9LiBBbGxvd2VkIGF1dGgudHlwZSBhcmUgJHtzdXBwb3J0ZWRBdXRoVHlwZXN9LmBcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9KTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBjb25maWdTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcclxuICBlbmFibGVkOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogdHJ1ZSB9KSxcclxuICBhbGxvd19jbGllbnRfY2VydGlmaWNhdGVzOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogZmFsc2UgfSksXHJcbiAgcmVhZG9ubHlfbW9kZTogc2NoZW1hLm9iamVjdCh7XHJcbiAgICByb2xlczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgfSksXHJcbiAgY2x1c3RlclBlcm1pc3Npb25zOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGluY2x1ZGU6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxyXG4gIH0pLFxyXG4gIGluZGV4UGVybWlzc2lvbnM6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgaW5jbHVkZTogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgfSksXHJcbiAgZGlzYWJsZWRUcmFuc3BvcnRDYXRlZ29yaWVzOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGV4Y2x1ZGU6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxyXG4gIH0pLFxyXG4gIGRpc2FibGVkUmVzdENhdGVnb3JpZXM6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgZXhjbHVkZTogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgfSksXHJcbiAgY29va2llOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIHNlY3VyZTogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgbmFtZTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ3NlY3VyaXR5X2F1dGhlbnRpY2F0aW9uJyB9KSxcclxuICAgIHBhc3N3b3JkOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnc2VjdXJpdHlfY29va2llX2RlZmF1bHRfcGFzc3dvcmQnLCBtaW5MZW5ndGg6IDMyIH0pLFxyXG4gICAgdHRsOiBzY2hlbWEubnVtYmVyKHsgZGVmYXVsdFZhbHVlOiA2MCAqIDYwICogMTAwMCB9KSxcclxuICAgIGRvbWFpbjogc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICBpc1NhbWVTaXRlOiBzY2hlbWEub25lT2YoXHJcbiAgICAgIFtcclxuICAgICAgICBzY2hlbWEubGl0ZXJhbCgnU3RyaWN0JyksXHJcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0xheCcpLFxyXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdOb25lJyksXHJcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoZmFsc2UpLFxyXG4gICAgICBdLFxyXG4gICAgICB7IGRlZmF1bHRWYWx1ZTogZmFsc2UgfVxyXG4gICAgKSxcclxuICB9KSxcclxuICBzZXNzaW9uOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIHR0bDogc2NoZW1hLm51bWJlcih7IGRlZmF1bHRWYWx1ZTogNjAgKiA2MCAqIDEwMDAgfSksXHJcbiAgICBrZWVwYWxpdmU6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gIH0pLFxyXG4gIGF1dGg6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgdHlwZTogc2NoZW1hLm9uZU9mKFxyXG4gICAgICBbXHJcbiAgICAgICAgc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7XHJcbiAgICAgICAgICBkZWZhdWx0VmFsdWU6IFsnJ10sXHJcbiAgICAgICAgICB2YWxpZGF0ZSh2YWx1ZTogc3RyaW5nW10pIHtcclxuICAgICAgICAgICAgaWYgKCF2YWx1ZSB8fCB2YWx1ZS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICByZXR1cm4gYEF1dGhlbnRpY2F0aW9uIHR5cGUgaXMgbm90IGNvbmZpZ3VyZWQgcHJvcGVybHkuIEF0IGxlYXN0IG9uZSBhdXRoZW50aWNhdGlvbiB0eXBlIG11c3QgYmUgc2VsZWN0ZWQuYDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICBjb25zdCBpbmNsdWRlQmFzaWNBdXRoID0gdmFsdWUuZmluZCgoZWxlbWVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQudG9Mb3dlckNhc2UoKSA9PT0gJ2Jhc2ljYXV0aCc7XHJcbiAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgIGlmICghaW5jbHVkZUJhc2ljQXV0aCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBBdXRoZW50aWNhdGlvbiB0eXBlIGlzIG5vdCBjb25maWd1cmVkIHByb3Blcmx5LiBiYXNpY2F1dGggaXMgbWFuZGF0b3J5LmA7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB2YWxpZGF0ZUF1dGhUeXBlKHZhbHVlKTtcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgc2NoZW1hLnN0cmluZyh7XHJcbiAgICAgICAgICBkZWZhdWx0VmFsdWU6ICcnLFxyXG4gICAgICAgICAgdmFsaWRhdGUodmFsdWUpIHtcclxuICAgICAgICAgICAgY29uc3QgdmFsQXJyYXk6IHN0cmluZ1tdID0gW107XHJcbiAgICAgICAgICAgIHZhbEFycmF5LnB1c2godmFsdWUpO1xyXG4gICAgICAgICAgICB2YWxpZGF0ZUF1dGhUeXBlKHZhbEFycmF5KTtcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIF0sXHJcbiAgICAgIHsgZGVmYXVsdFZhbHVlOiAnJyB9XHJcbiAgICApLFxyXG4gICAgYW5vbnltb3VzX2F1dGhfZW5hYmxlZDogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgdW5hdXRoZW50aWNhdGVkX3JvdXRlczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7XHJcbiAgICAgIGRlZmF1bHRWYWx1ZTogWycvYXBpL3JlcG9ydGluZy9zdGF0cyddLFxyXG4gICAgfSksXHJcbiAgICBmb3JiaWRkZW5fdXNlcm5hbWVzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcclxuICAgIGxvZ291dF91cmw6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgbXVsdGlwbGVfYXV0aF9lbmFibGVkOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogZmFsc2UgfSksXHJcbiAgfSksXHJcbiAgYmFzaWNhdXRoOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gICAgdW5hdXRoZW50aWNhdGVkX3JvdXRlczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgICBmb3JiaWRkZW5fdXNlcm5hbWVzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcclxuICAgIGhlYWRlcl90cnVtcHNfc2Vzc2lvbjogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgYWx0ZXJuYXRpdmVfbG9naW46IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICBoZWFkZXJzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcclxuICAgICAgc2hvd19mb3JfcGFyYW1ldGVyOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgdmFsaWRfcmVkaXJlY3RzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcclxuICAgICAgYnV0dG9uX3RleHQ6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICdMb2cgaW4gd2l0aCBwcm92aWRlcicgfSksXHJcbiAgICAgIGJ1dHRvbnN0eWxlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgIH0pLFxyXG4gICAgbG9hZGJhbGFuY2VyX3VybDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICBsb2dpbjogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgIHRpdGxlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgc3VidGl0bGU6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgICBzaG93YnJhbmRpbWFnZTogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IHRydWUgfSksXHJcbiAgICAgIGJyYW5kaW1hZ2U6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLCAvLyBUT0RPOiB1cGRhdGUgYnJhbmQgaW1hZ2VcclxuICAgICAgYnV0dG9uc3R5bGU6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgfSksXHJcbiAgfSksXHJcbiAgbXVsdGl0ZW5hbmN5OiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSxcclxuICAgIHNob3dfcm9sZXM6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSxcclxuICAgIGVuYWJsZV9maWx0ZXI6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSxcclxuICAgIGRlYnVnOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogZmFsc2UgfSksXHJcbiAgICBlbmFibGVfYWdncmVnYXRpb25fdmlldzogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgdGVuYW50czogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgIGVuYWJsZV9wcml2YXRlOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogdHJ1ZSB9KSxcclxuICAgICAgZW5hYmxlX2dsb2JhbDogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IHRydWUgfSksXHJcbiAgICAgIHByZWZlcnJlZDogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXHJcbiAgICB9KSxcclxuICB9KSxcclxuICBjb25maWd1cmF0aW9uOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gIH0pLFxyXG4gIGFjY291bnRpbmZvOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSxcclxuICB9KSxcclxuICBvcGVuaWQ6IHNjaGVtYS5tYXliZShcclxuICAgIHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICBjb25uZWN0X3VybDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXHJcbiAgICAgIGhlYWRlcjogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ0F1dGhvcml6YXRpb24nIH0pLFxyXG4gICAgICAvLyBUT0RPOiB0ZXN0IGlmIHNpYmxpbmdSZWYoKSB3b3JrcyBoZXJlXHJcbiAgICAgIC8vIGNsaWVudF9pZCBpcyByZXF1aXJlZCB3aGVuIGF1dGgudHlwZSBpcyBvcGVuaWRcclxuICAgICAgY2xpZW50X2lkOiBzY2hlbWEuY29uZGl0aW9uYWwoXHJcbiAgICAgICAgc2NoZW1hLnNpYmxpbmdSZWYoJ2F1dGgudHlwZScpLFxyXG4gICAgICAgICdvcGVuaWQnLFxyXG4gICAgICAgIHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKVxyXG4gICAgICApLFxyXG4gICAgICBjbGllbnRfc2VjcmV0OiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgc2NvcGU6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICdvcGVuaWQgcHJvZmlsZSBlbWFpbCBhZGRyZXNzIHBob25lJyB9KSxcclxuICAgICAgYmFzZV9yZWRpcmVjdF91cmw6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgICBsb2dvdXRfdXJsOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgcm9vdF9jYTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJycgfSksXHJcbiAgICAgIHZlcmlmeV9ob3N0bmFtZXM6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gICAgICByZWZyZXNoX3Rva2Vuczogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IHRydWUgfSksXHJcbiAgICAgIHRydXN0X2R5bmFtaWNfaGVhZGVyczogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgICBleHRyYV9zdG9yYWdlOiBzY2hlbWEub2JqZWN0KHtcclxuICAgICAgICBjb29raWVfcHJlZml4OiBzY2hlbWEuc3RyaW5nKHtcclxuICAgICAgICAgIGRlZmF1bHRWYWx1ZTogJ3NlY3VyaXR5X2F1dGhlbnRpY2F0aW9uX29pZGMnLFxyXG4gICAgICAgICAgbWluTGVuZ3RoOiAyLFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIGFkZGl0aW9uYWxfY29va2llczogc2NoZW1hLm51bWJlcih7IG1pbjogMSwgZGVmYXVsdFZhbHVlOiA1IH0pLFxyXG4gICAgICB9KSxcclxuICAgIH0pXHJcbiAgKSxcclxuICBzYW1sOiBzY2hlbWEub2JqZWN0KHtcclxuICAgIGV4dHJhX3N0b3JhZ2U6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICBjb29raWVfcHJlZml4OiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnc2VjdXJpdHlfYXV0aGVudGljYXRpb25fc2FtbCcsIG1pbkxlbmd0aDogMiB9KSxcclxuICAgICAgYWRkaXRpb25hbF9jb29raWVzOiBzY2hlbWEubnVtYmVyKHsgbWluOiAwLCBkZWZhdWx0VmFsdWU6IDMgfSksXHJcbiAgICB9KSxcclxuICB9KSxcclxuXHJcbiAgcHJveHljYWNoZTogc2NoZW1hLm1heWJlKFxyXG4gICAgc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgIC8vIHdoZW4gYXV0aC50eXBlIGlzIHByb3h5Y2FjaGUsIHVzZXJfaGVhZGVyLCByb2xlc19oZWFkZXIgYW5kIHByb3h5X2hlYWRlcl9pcCBhcmUgcmVxdWlyZWRcclxuICAgICAgdXNlcl9oZWFkZXI6IHNjaGVtYS5jb25kaXRpb25hbChcclxuICAgICAgICBzY2hlbWEuc2libGluZ1JlZignYXV0aC50eXBlJyksXHJcbiAgICAgICAgJ3Byb3h5Y2FjaGUnLFxyXG4gICAgICAgIHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKVxyXG4gICAgICApLFxyXG4gICAgICByb2xlc19oZWFkZXI6IHNjaGVtYS5jb25kaXRpb25hbChcclxuICAgICAgICBzY2hlbWEuc2libGluZ1JlZignYXV0aC50eXBlJyksXHJcbiAgICAgICAgJ3Byb3h5Y2FjaGUnLFxyXG4gICAgICAgIHNjaGVtYS5zdHJpbmcoKSxcclxuICAgICAgICBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKVxyXG4gICAgICApLFxyXG4gICAgICBwcm94eV9oZWFkZXI6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAneC1mb3J3YXJkZWQtZm9yJyB9KSksXHJcbiAgICAgIHByb3h5X2hlYWRlcl9pcDogc2NoZW1hLmNvbmRpdGlvbmFsKFxyXG4gICAgICAgIHNjaGVtYS5zaWJsaW5nUmVmKCdhdXRoLnR5cGUnKSxcclxuICAgICAgICAncHJveHljYWNoZScsXHJcbiAgICAgICAgc2NoZW1hLnN0cmluZygpLFxyXG4gICAgICAgIHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpXHJcbiAgICAgICksXHJcbiAgICAgIGxvZ2luX2VuZHBvaW50OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJycgfSkpLFxyXG4gICAgfSlcclxuICApLFxyXG4gIGp3dDogc2NoZW1hLm1heWJlKFxyXG4gICAgc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgIGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSxcclxuICAgICAgbG9naW5fZW5kcG9pbnQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxyXG4gICAgICB1cmxfcGFyYW06IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICdhdXRob3JpemF0aW9uJyB9KSxcclxuICAgICAgaGVhZGVyOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnQXV0aG9yaXphdGlvbicgfSksXHJcbiAgICB9KVxyXG4gICksXHJcbiAgdWk6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgYmFzaWNhdXRoOiBzY2hlbWEub2JqZWN0KHtcclxuICAgICAgLy8gdGhlIGxvZ2luIGNvbmZpZyBoZXJlIGlzIHRoZSBzYW1lIGFzIG9sZCBjb25maWcgYF9zZWN1cml0eS5iYXNpY2F1dGgubG9naW5gXHJcbiAgICAgIC8vIFNpbmNlIHdlIGFyZSBub3cgcmVuZGVyaW5nIGxvZ2luIHBhZ2UgdG8gYnJvd3NlciBhcHAsIHNvIG1vdmUgdGhlc2UgY29uZmlnIHRvIGJyb3dzZXIgc2lkZS5cclxuICAgICAgbG9naW46IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICAgIHRpdGxlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgICBzdWJ0aXRsZTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJycgfSksXHJcbiAgICAgICAgc2hvd2JyYW5kaW1hZ2U6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gICAgICAgIGJyYW5kaW1hZ2U6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgICAgIGJ1dHRvbnN0eWxlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgfSksXHJcbiAgICB9KSxcclxuICAgIGFub255bW91czogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgIGxvZ2luOiBzY2hlbWEub2JqZWN0KHtcclxuICAgICAgICBidXR0b25uYW1lOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnTG9nIGluIGFzIGFub255bW91cycgfSksXHJcbiAgICAgICAgc2hvd2JyYW5kaW1hZ2U6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSxcclxuICAgICAgICBicmFuZGltYWdlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgICBidXR0b25zdHlsZTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJycgfSksXHJcbiAgICAgIH0pLFxyXG4gICAgfSksXHJcbiAgICBvcGVuaWQ6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICBsb2dpbjogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgYnV0dG9ubmFtZTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ0xvZyBpbiB3aXRoIHNpbmdsZSBzaWduLW9uJyB9KSxcclxuICAgICAgICBzaG93YnJhbmRpbWFnZTogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgICAgIGJyYW5kaW1hZ2U6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgICAgIGJ1dHRvbnN0eWxlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgfSksXHJcbiAgICB9KSxcclxuICAgIHNhbWw6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICBsb2dpbjogc2NoZW1hLm9iamVjdCh7XHJcbiAgICAgICAgYnV0dG9ubmFtZTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ0xvZyBpbiB3aXRoIHNpbmdsZSBzaWduLW9uJyB9KSxcclxuICAgICAgICBzaG93YnJhbmRpbWFnZTogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxyXG4gICAgICAgIGJyYW5kaW1hZ2U6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxyXG4gICAgICAgIGJ1dHRvbnN0eWxlOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcclxuICAgICAgfSksXHJcbiAgICB9KSxcclxuICAgIGF1dG9sb2dvdXQ6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gICAgYmFja2VuZF9jb25maWd1cmFibGU6IHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiB0cnVlIH0pLFxyXG4gIH0pLFxyXG59KTtcclxuXHJcbmV4cG9ydCB0eXBlIFNlY3VyaXR5UGx1Z2luQ29uZmlnVHlwZSA9IFR5cGVPZjx0eXBlb2YgY29uZmlnU2NoZW1hPjtcclxuXHJcbmV4cG9ydCBjb25zdCBjb25maWc6IFBsdWdpbkNvbmZpZ0Rlc2NyaXB0b3I8U2VjdXJpdHlQbHVnaW5Db25maWdUeXBlPiA9IHtcclxuICBleHBvc2VUb0Jyb3dzZXI6IHtcclxuICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICBhdXRoOiB0cnVlLFxyXG4gICAgdWk6IHRydWUsXHJcbiAgICBtdWx0aXRlbmFuY3k6IHRydWUsXHJcbiAgICByZWFkb25seV9tb2RlOiB0cnVlLFxyXG4gICAgY2x1c3RlclBlcm1pc3Npb25zOiB0cnVlLFxyXG4gICAgaW5kZXhQZXJtaXNzaW9uczogdHJ1ZSxcclxuICAgIGRpc2FibGVkVHJhbnNwb3J0Q2F0ZWdvcmllczogdHJ1ZSxcclxuICAgIGRpc2FibGVkUmVzdENhdGVnb3JpZXM6IHRydWUsXHJcbiAgfSxcclxuICBzY2hlbWE6IGNvbmZpZ1NjaGVtYSxcclxuICBkZXByZWNhdGlvbnM6ICh7IHJlbmFtZSwgdW51c2VkIH0pID0+IFtcclxuICAgIHJlbmFtZSgnYmFzaWNhdXRoLmxvZ2luLnRpdGxlJywgJ3VpLmJhc2ljYXV0aC5sb2dpbi50aXRsZScpLFxyXG4gICAgcmVuYW1lKCdiYXNpY2F1dGgubG9naW4uc3VidGl0bGUnLCAndWkuYmFzaWNhdXRoLmxvZ2luLnN1YnRpdGxlJyksXHJcbiAgICByZW5hbWUoJ2Jhc2ljYXV0aC5sb2dpbi5zaG93YnJhbmRpbWFnZScsICd1aS5iYXNpY2F1dGgubG9naW4uc2hvd2JyYW5kaW1hZ2UnKSxcclxuICAgIHJlbmFtZSgnYmFzaWNhdXRoLmxvZ2luLmJyYW5kaW1hZ2UnLCAndWkuYmFzaWNhdXRoLmxvZ2luLmJyYW5kaW1hZ2UnKSxcclxuICAgIHJlbmFtZSgnYmFzaWNhdXRoLmxvZ2luLmJ1dHRvbnN0eWxlJywgJ3VpLmJhc2ljYXV0aC5sb2dpbi5idXR0b25zdHlsZScpLFxyXG4gIF0sXHJcbn07XHJcblxyXG4vLyAgVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxyXG4vLyAgYXMgd2VsbCBhcywgT3BlblNlYXJjaERhc2hib2FyZHMgUGxhdGZvcm0gYHBsdWdpbigpYCBpbml0aWFsaXplci5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcclxuICByZXR1cm4gbmV3IFNlY3VyaXR5UGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCB7IFNlY3VyaXR5UGx1Z2luU2V0dXAsIFNlY3VyaXR5UGx1Z2luU3RhcnQgfSBmcm9tICcuL3R5cGVzJztcclxuIl19