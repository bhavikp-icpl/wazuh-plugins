"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.OpenSearchDashboardsSecurityFactory = void 0;

var _md = _interopRequireDefault(require("md5"));

var _constants = require("../../../../common/constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class OpenSearchDashboardsSecurityFactory {
  constructor() {
    _defineProperty(this, "platform", _constants.WAZUH_SECURITY_PLUGIN_OPENSEARCH_DASHBOARDS_SECURITY);
  }

  async getCurrentUser(request, context) {
    try {
      const params = {
        path: `/_opendistro/_security/api/account`,
        method: 'GET'
      };
      const {
        body: authContext
      } = await context.core.opensearch.client.asCurrentUser.transport.request(params);
      const username = this.getUserName(authContext);
      return {
        username,
        authContext,
        hashUsername: (0, _md.default)(username)
      };
    } catch (error) {
      throw error;
    }
  }

  getUserName(authContext) {
    return authContext['user_name'];
  }

}

exports.OpenSearchDashboardsSecurityFactory = OpenSearchDashboardsSecurityFactory;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9wZW5zZWFyY2gtZGFzaGJvYXJkcy1zZWN1cml0eS1mYWN0b3J5LnRzIl0sIm5hbWVzIjpbIk9wZW5TZWFyY2hEYXNoYm9hcmRzU2VjdXJpdHlGYWN0b3J5IiwiV0FaVUhfU0VDVVJJVFlfUExVR0lOX09QRU5TRUFSQ0hfREFTSEJPQVJEU19TRUNVUklUWSIsImdldEN1cnJlbnRVc2VyIiwicmVxdWVzdCIsImNvbnRleHQiLCJwYXJhbXMiLCJwYXRoIiwibWV0aG9kIiwiYm9keSIsImF1dGhDb250ZXh0IiwiY29yZSIsIm9wZW5zZWFyY2giLCJjbGllbnQiLCJhc0N1cnJlbnRVc2VyIiwidHJhbnNwb3J0IiwidXNlcm5hbWUiLCJnZXRVc2VyTmFtZSIsImhhc2hVc2VybmFtZSIsImVycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBRUE7O0FBQ0E7Ozs7OztBQUVPLE1BQU1BLG1DQUFOLENBQXNFO0FBQUE7QUFBQSxzQ0FDeERDLCtEQUR3RDtBQUFBOztBQUd2RCxRQUFkQyxjQUFjLENBQUNDLE9BQUQsRUFBdUNDLE9BQXZDLEVBQXVFO0FBQ3pGLFFBQUk7QUFDRixZQUFNQyxNQUFNLEdBQUc7QUFDYkMsUUFBQUEsSUFBSSxFQUFHLG9DQURNO0FBRWJDLFFBQUFBLE1BQU0sRUFBRTtBQUZLLE9BQWY7QUFLQSxZQUFNO0FBQ0pDLFFBQUFBLElBQUksRUFBRUM7QUFERixVQUVGLE1BQU1MLE9BQU8sQ0FBQ00sSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsYUFBL0IsQ0FBNkNDLFNBQTdDLENBQXVEWCxPQUF2RCxDQUErREUsTUFBL0QsQ0FGVjtBQUdBLFlBQU1VLFFBQVEsR0FBRyxLQUFLQyxXQUFMLENBQWlCUCxXQUFqQixDQUFqQjtBQUNBLGFBQU87QUFBRU0sUUFBQUEsUUFBRjtBQUFZTixRQUFBQSxXQUFaO0FBQXlCUSxRQUFBQSxZQUFZLEVBQUUsaUJBQUlGLFFBQUo7QUFBdkMsT0FBUDtBQUNELEtBWEQsQ0FXRSxPQUFPRyxLQUFQLEVBQWM7QUFDZCxZQUFNQSxLQUFOO0FBQ0Q7QUFDRjs7QUFFREYsRUFBQUEsV0FBVyxDQUFDUCxXQUFELEVBQW1CO0FBQzVCLFdBQU9BLFdBQVcsQ0FBQyxXQUFELENBQWxCO0FBQ0Q7O0FBdEIwRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElTZWN1cml0eUZhY3RvcnkgfSBmcm9tICcuLic7XG5pbXBvcnQgeyBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIFJlcXVlc3RIYW5kbGVyQ29udGV4dCB9IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IG1kNSBmcm9tICdtZDUnO1xuaW1wb3J0IHsgV0FaVUhfU0VDVVJJVFlfUExVR0lOX09QRU5TRUFSQ0hfREFTSEJPQVJEU19TRUNVUklUWSB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuXG5leHBvcnQgY2xhc3MgT3BlblNlYXJjaERhc2hib2FyZHNTZWN1cml0eUZhY3RvcnkgaW1wbGVtZW50cyBJU2VjdXJpdHlGYWN0b3J5IHtcbiAgcGxhdGZvcm06IHN0cmluZyA9IFdBWlVIX1NFQ1VSSVRZX1BMVUdJTl9PUEVOU0VBUkNIX0RBU0hCT0FSRFNfU0VDVVJJVFk7XG5cbiAgYXN5bmMgZ2V0Q3VycmVudFVzZXIocmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICBwYXRoOiBgL19vcGVuZGlzdHJvL19zZWN1cml0eS9hcGkvYWNjb3VudGAsXG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICB9O1xuXG4gICAgICBjb25zdCB7XG4gICAgICAgIGJvZHk6IGF1dGhDb250ZXh0LFxuICAgICAgfSA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnRyYW5zcG9ydC5yZXF1ZXN0KHBhcmFtcyk7XG4gICAgICBjb25zdCB1c2VybmFtZSA9IHRoaXMuZ2V0VXNlck5hbWUoYXV0aENvbnRleHQpO1xuICAgICAgcmV0dXJuIHsgdXNlcm5hbWUsIGF1dGhDb250ZXh0LCBoYXNoVXNlcm5hbWU6IG1kNSh1c2VybmFtZSkgfTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgZ2V0VXNlck5hbWUoYXV0aENvbnRleHQ6IGFueSkge1xuICAgIHJldHVybiBhdXRoQ29udGV4dFsndXNlcl9uYW1lJ107XG4gIH1cbn1cbiJdfQ==