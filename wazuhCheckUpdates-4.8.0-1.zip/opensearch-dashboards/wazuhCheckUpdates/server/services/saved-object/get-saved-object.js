"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getSavedObject = void 0;

var _pluginServices = require("../../plugin-services");

const getSavedObject = async (type, id) => {
  try {
    const client = (0, _pluginServices.getInternalSavedObjectsClient)();
    const responseGet = await client.get(type, id || type);
    const result = (responseGet === null || responseGet === void 0 ? void 0 : responseGet.attributes) || {};
    return result;
  } catch (error) {
    var _error$output;

    if ((error === null || error === void 0 ? void 0 : (_error$output = error.output) === null || _error$output === void 0 ? void 0 : _error$output.statusCode) === 404) {
      return {};
    }

    const message = error instanceof Error ? error.message : typeof error === 'string' ? error : 'Error trying to get saved object';
    const {
      services: {
        log
      }
    } = (0, _pluginServices.getWazuhCore)();
    log('wazuh-check-updates:getSavedObject', message);
    return Promise.reject(error);
  }
};

exports.getSavedObject = getSavedObject;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1zYXZlZC1vYmplY3QudHMiXSwibmFtZXMiOlsiZ2V0U2F2ZWRPYmplY3QiLCJ0eXBlIiwiaWQiLCJjbGllbnQiLCJyZXNwb25zZUdldCIsImdldCIsInJlc3VsdCIsImF0dHJpYnV0ZXMiLCJlcnJvciIsIm91dHB1dCIsInN0YXR1c0NvZGUiLCJtZXNzYWdlIiwiRXJyb3IiLCJzZXJ2aWNlcyIsImxvZyIsIlByb21pc2UiLCJyZWplY3QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7QUFHTyxNQUFNQSxjQUFjLEdBQUcsT0FBT0MsSUFBUCxFQUFxQkMsRUFBckIsS0FBK0Q7QUFDM0YsTUFBSTtBQUNGLFVBQU1DLE1BQU0sR0FBRyxvREFBZjtBQUVBLFVBQU1DLFdBQVcsR0FBRyxNQUFNRCxNQUFNLENBQUNFLEdBQVAsQ0FBV0osSUFBWCxFQUFpQkMsRUFBRSxJQUFJRCxJQUF2QixDQUExQjtBQUVBLFVBQU1LLE1BQU0sR0FBSSxDQUFBRixXQUFXLFNBQVgsSUFBQUEsV0FBVyxXQUFYLFlBQUFBLFdBQVcsQ0FBRUcsVUFBYixLQUEyQixFQUEzQztBQUNBLFdBQU9ELE1BQVA7QUFDRCxHQVBELENBT0UsT0FBT0UsS0FBUCxFQUFtQjtBQUFBOztBQUNuQixRQUFJLENBQUFBLEtBQUssU0FBTCxJQUFBQSxLQUFLLFdBQUwsNkJBQUFBLEtBQUssQ0FBRUMsTUFBUCxnRUFBZUMsVUFBZixNQUE4QixHQUFsQyxFQUF1QztBQUNyQyxhQUFPLEVBQVA7QUFDRDs7QUFDRCxVQUFNQyxPQUFPLEdBQ1hILEtBQUssWUFBWUksS0FBakIsR0FDSUosS0FBSyxDQUFDRyxPQURWLEdBRUksT0FBT0gsS0FBUCxLQUFpQixRQUFqQixHQUNBQSxLQURBLEdBRUEsa0NBTE47QUFPQSxVQUFNO0FBQ0pLLE1BQUFBLFFBQVEsRUFBRTtBQUFFQyxRQUFBQTtBQUFGO0FBRE4sUUFFRixtQ0FGSjtBQUlBQSxJQUFBQSxHQUFHLENBQUMsb0NBQUQsRUFBdUNILE9BQXZDLENBQUg7QUFDQSxXQUFPSSxPQUFPLENBQUNDLE1BQVIsQ0FBZVIsS0FBZixDQUFQO0FBQ0Q7QUFDRixDQTFCTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldEludGVybmFsU2F2ZWRPYmplY3RzQ2xpZW50LCBnZXRXYXp1aENvcmUgfSBmcm9tICcuLi8uLi9wbHVnaW4tc2VydmljZXMnO1xuaW1wb3J0IHsgc2F2ZWRPYmplY3RUeXBlIH0gZnJvbSAnLi4vLi4vLi4vY29tbW9uL3R5cGVzJztcblxuZXhwb3J0IGNvbnN0IGdldFNhdmVkT2JqZWN0ID0gYXN5bmMgKHR5cGU6IHN0cmluZywgaWQ/OiBzdHJpbmcpOiBQcm9taXNlPHNhdmVkT2JqZWN0VHlwZT4gPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IGdldEludGVybmFsU2F2ZWRPYmplY3RzQ2xpZW50KCk7XG5cbiAgICBjb25zdCByZXNwb25zZUdldCA9IGF3YWl0IGNsaWVudC5nZXQodHlwZSwgaWQgfHwgdHlwZSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSAocmVzcG9uc2VHZXQ/LmF0dHJpYnV0ZXMgfHwge30pIGFzIHNhdmVkT2JqZWN0VHlwZTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgaWYgKGVycm9yPy5vdXRwdXQ/LnN0YXR1c0NvZGUgPT09IDQwNCkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICBjb25zdCBtZXNzYWdlID1cbiAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgPyBlcnJvci5tZXNzYWdlXG4gICAgICAgIDogdHlwZW9mIGVycm9yID09PSAnc3RyaW5nJ1xuICAgICAgICA/IGVycm9yXG4gICAgICAgIDogJ0Vycm9yIHRyeWluZyB0byBnZXQgc2F2ZWQgb2JqZWN0JztcblxuICAgIGNvbnN0IHtcbiAgICAgIHNlcnZpY2VzOiB7IGxvZyB9LFxuICAgIH0gPSBnZXRXYXp1aENvcmUoKTtcblxuICAgIGxvZygnd2F6dWgtY2hlY2stdXBkYXRlczpnZXRTYXZlZE9iamVjdCcsIG1lc3NhZ2UpO1xuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gIH1cbn07XG4iXX0=