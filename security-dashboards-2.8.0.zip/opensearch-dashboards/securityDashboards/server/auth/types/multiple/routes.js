"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MultiAuthRoutes = void 0;

var _common = require("../../../../common");

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
class MultiAuthRoutes {
  constructor(router, sessionStorageFactory) {
    this.router = router;
    this.sessionStorageFactory = sessionStorageFactory;
  }

  setupRoutes() {
    this.router.get({
      path: _common.API_ENDPOINT_AUTHTYPE,
      validate: false
    }, async (context, request, response) => {
      const cookie = await this.sessionStorageFactory.asScoped(request).get();

      if (!cookie) {
        return response.badRequest({
          body: 'Invalid cookie'
        });
      }

      return response.ok({
        body: {
          currentAuthType: cookie === null || cookie === void 0 ? void 0 : cookie.authType
        }
      });
    });
  }

}

exports.MultiAuthRoutes = MultiAuthRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdXRlcy50cyJdLCJuYW1lcyI6WyJNdWx0aUF1dGhSb3V0ZXMiLCJjb25zdHJ1Y3RvciIsInJvdXRlciIsInNlc3Npb25TdG9yYWdlRmFjdG9yeSIsInNldHVwUm91dGVzIiwiZ2V0IiwicGF0aCIsIkFQSV9FTkRQT0lOVF9BVVRIVFlQRSIsInZhbGlkYXRlIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImNvb2tpZSIsImFzU2NvcGVkIiwiYmFkUmVxdWVzdCIsImJvZHkiLCJvayIsImN1cnJlbnRBdXRoVHlwZSIsImF1dGhUeXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBaUJBOztBQWpCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTU8sTUFBTUEsZUFBTixDQUFzQjtBQUMzQkMsRUFBQUEsV0FBVyxDQUNRQyxNQURSLEVBRVFDLHFCQUZSLEVBR1Q7QUFBQSxTQUZpQkQsTUFFakIsR0FGaUJBLE1BRWpCO0FBQUEsU0FEaUJDLHFCQUNqQixHQURpQkEscUJBQ2pCO0FBQUU7O0FBRUdDLEVBQUFBLFdBQVcsR0FBRztBQUNuQixTQUFLRixNQUFMLENBQVlHLEdBQVosQ0FDRTtBQUNFQyxNQUFBQSxJQUFJLEVBQUVDLDZCQURSO0FBRUVDLE1BQUFBLFFBQVEsRUFBRTtBQUZaLEtBREYsRUFLRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsWUFBTUMsTUFBTSxHQUFHLE1BQU0sS0FBS1QscUJBQUwsQ0FBMkJVLFFBQTNCLENBQW9DSCxPQUFwQyxFQUE2Q0wsR0FBN0MsRUFBckI7O0FBQ0EsVUFBSSxDQUFDTyxNQUFMLEVBQWE7QUFDWCxlQUFPRCxRQUFRLENBQUNHLFVBQVQsQ0FBb0I7QUFDekJDLFVBQUFBLElBQUksRUFBRTtBQURtQixTQUFwQixDQUFQO0FBR0Q7O0FBQ0QsYUFBT0osUUFBUSxDQUFDSyxFQUFULENBQVk7QUFDakJELFFBQUFBLElBQUksRUFBRTtBQUNKRSxVQUFBQSxlQUFlLEVBQUVMLE1BQUYsYUFBRUEsTUFBRix1QkFBRUEsTUFBTSxDQUFFTTtBQURyQjtBQURXLE9BQVosQ0FBUDtBQUtELEtBakJIO0FBbUJEOztBQTFCMEIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiAgIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xyXG4gKlxyXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXHJcbiAqICAgWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxyXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XHJcbiAqXHJcbiAqICAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxyXG4gKlxyXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxyXG4gKiAgIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXHJcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7IElSb3V0ZXIsIFNlc3Npb25TdG9yYWdlRmFjdG9yeSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XHJcbmltcG9ydCB7IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB9IGZyb20gJy4uLy4uLy4uL3Nlc3Npb24vc2VjdXJpdHlfY29va2llJztcclxuaW1wb3J0IHsgQVBJX0VORFBPSU5UX0FVVEhUWVBFIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tbW9uJztcclxuXHJcbmV4cG9ydCBjbGFzcyBNdWx0aUF1dGhSb3V0ZXMge1xyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJpdmF0ZSByZWFkb25seSByb3V0ZXI6IElSb3V0ZXIsXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IHNlc3Npb25TdG9yYWdlRmFjdG9yeTogU2Vzc2lvblN0b3JhZ2VGYWN0b3J5PFNlY3VyaXR5U2Vzc2lvbkNvb2tpZT5cclxuICApIHt9XHJcblxyXG4gIHB1YmxpYyBzZXR1cFJvdXRlcygpIHtcclxuICAgIHRoaXMucm91dGVyLmdldChcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IEFQSV9FTkRQT0lOVF9BVVRIVFlQRSxcclxuICAgICAgICB2YWxpZGF0ZTogZmFsc2UsXHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGNvb2tpZSA9IGF3YWl0IHRoaXMuc2Vzc2lvblN0b3JhZ2VGYWN0b3J5LmFzU2NvcGVkKHJlcXVlc3QpLmdldCgpO1xyXG4gICAgICAgIGlmICghY29va2llKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCh7XHJcbiAgICAgICAgICAgIGJvZHk6ICdJbnZhbGlkIGNvb2tpZScsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgY3VycmVudEF1dGhUeXBlOiBjb29raWU/LmF1dGhUeXBlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl19