"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION = exports.WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY = exports.WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING = exports.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS = exports.WAZUH_ROLE_ADMINISTRATOR_NAME = exports.WAZUH_ROLE_ADMINISTRATOR_ID = exports.WAZUH_QUEUE_CRON_FREQ = exports.WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME = exports.WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER = exports.WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS = exports.WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS = exports.WAZUH_MONITORING_TEMPLATE_NAME = exports.WAZUH_MONITORING_PREFIX = exports.WAZUH_MONITORING_PATTERN = exports.WAZUH_MONITORING_DEFAULT_INDICES_SHARDS = exports.WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS = exports.WAZUH_MONITORING_DEFAULT_FREQUENCY = exports.WAZUH_MONITORING_DEFAULT_ENABLED = exports.WAZUH_MONITORING_DEFAULT_CRON_FREQ = exports.WAZUH_MONITORING_DEFAULT_CREATION = exports.WAZUH_MODULES_ID = exports.WAZUH_MENU_TOOLS_SECTIONS_ID = exports.WAZUH_MENU_SETTINGS_SECTIONS_ID = exports.WAZUH_MENU_SECURITY_SECTIONS_ID = exports.WAZUH_MENU_MANAGEMENT_SECTIONS_ID = exports.WAZUH_LINK_SLACK = exports.WAZUH_LINK_GOOGLE_GROUPS = exports.WAZUH_LINK_GITHUB = exports.WAZUH_INDEX_TYPE_VULNERABILITIES = exports.WAZUH_INDEX_TYPE_STATISTICS = exports.WAZUH_INDEX_TYPE_MONITORING = exports.WAZUH_INDEX_TYPE_ALERTS = exports.WAZUH_INDEXER_NAME = exports.WAZUH_ERROR_DAEMONS_NOT_READY = exports.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH = exports.WAZUH_DATA_LOGS_RAW_PATH = exports.WAZUH_DATA_LOGS_RAW_FILENAME = exports.WAZUH_DATA_LOGS_PLAIN_PATH = exports.WAZUH_DATA_LOGS_PLAIN_FILENAME = exports.WAZUH_DATA_LOGS_DIRECTORY_PATH = exports.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH = exports.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH = exports.WAZUH_DATA_CONFIG_REGISTRY_PATH = exports.WAZUH_DATA_CONFIG_DIRECTORY_PATH = exports.WAZUH_DATA_CONFIG_APP_PATH = exports.WAZUH_DATA_ABSOLUTE_PATH = exports.WAZUH_CONFIGURATION_CACHE_TIME = exports.WAZUH_API_RESERVED_WUI_SECURITY_RULES = exports.WAZUH_API_RESERVED_ID_LOWER_THAN = exports.WAZUH_ALERTS_PREFIX = exports.WAZUH_ALERTS_PATTERN = exports.WAZUH_AGENTS_OS_TYPE = exports.UI_TOAST_COLOR = exports.UI_ORDER_AGENT_STATUS = exports.UI_LOGGER_LEVELS = exports.UI_LABEL_NAME_AGENT_STATUS = exports.UI_COLOR_STATUS = exports.UI_COLOR_AGENT_STATUS = exports.SettingCategory = exports.SEARCH_BAR_WQL_VALUE_SUGGESTIONS_DISPLAY_COUNT = exports.SEARCH_BAR_WQL_VALUE_SUGGESTIONS_COUNT = exports.SEARCH_BAR_DEBOUNCE_UPDATE_TIME = exports.REPORTS_PRIMARY_COLOR = exports.REPORTS_PAGE_HEADER_TEXT = exports.REPORTS_PAGE_FOOTER_TEXT = exports.REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH = exports.PLUGIN_VERSION_SHORT = exports.PLUGIN_VERSION = exports.PLUGIN_SETTINGS_CATEGORIES = exports.PLUGIN_SETTINGS = exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM = exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING = exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION = exports.PLUGIN_PLATFORM_URL_GUIDE_TITLE = exports.PLUGIN_PLATFORM_URL_GUIDE = exports.PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER = exports.PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS = exports.PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS = exports.PLUGIN_PLATFORM_REQUEST_HEADERS = exports.PLUGIN_PLATFORM_NAME = exports.PLUGIN_PLATFORM_INSTALLATION_USER_GROUP = exports.PLUGIN_PLATFORM_INSTALLATION_USER = exports.PLUGIN_PLATFORM_BASE_INSTALLATION_PATH = exports.PLUGIN_APP_NAME = exports.NOT_TIME_FIELD_NAME_INDEX_PATTERN = exports.MODULE_SCA_CHECK_RESULT_LABEL = exports.MAX_MB_LOG_FILES = exports.HTTP_STATUS_CODES = exports.HEALTH_CHECK_REDIRECTION_TIME = exports.HEALTH_CHECK = exports.EpluginSettingType = exports.ELASTIC_NAME = exports.DOCUMENTATION_WEB_BASE_URL = exports.CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES = exports.AUTHORIZED_AGENTS = exports.ASSETS_PUBLIC_URL = exports.ASSETS_BASE_URL_PREFIX = exports.API_NAME_AGENT_STATUS = exports.AGENT_SYNCED_STATUS = exports.AGENT_STATUS_CODE = void 0;
exports.WAZUH_VULNERABILITIES_PATTERN = exports.WAZUH_UI_LOGS_RAW_PATH = exports.WAZUH_UI_LOGS_RAW_FILENAME = exports.WAZUH_UI_LOGS_PLAIN_PATH = exports.WAZUH_UI_LOGS_PLAIN_FILENAME = exports.WAZUH_STATISTICS_TEMPLATE_NAME = exports.WAZUH_STATISTICS_PATTERN = exports.WAZUH_STATISTICS_DEFAULT_STATUS = exports.WAZUH_STATISTICS_DEFAULT_PREFIX = exports.WAZUH_STATISTICS_DEFAULT_NAME = exports.WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS = exports.WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS = exports.WAZUH_STATISTICS_DEFAULT_FREQUENCY = exports.WAZUH_STATISTICS_DEFAULT_CRON_FREQ = exports.WAZUH_STATISTICS_DEFAULT_CREATION = exports.WAZUH_SECURITY_PLUGIN_OPENSEARCH_DASHBOARDS_SECURITY = exports.WAZUH_SECURITY_PLUGINS = exports.WAZUH_SAMPLE_ALERT_PREFIX = exports.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS = exports.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS = exports.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS = void 0;

var _path = _interopRequireDefault(require("path"));

var _package = require("../package.json");

var _nodeCron = require("node-cron");

var _settingsValidator = require("../common/services/settings-validator");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Wazuh app - Wazuh Constants file
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
// Plugin
const PLUGIN_VERSION = _package.version;
exports.PLUGIN_VERSION = PLUGIN_VERSION;

const PLUGIN_VERSION_SHORT = _package.version.split('.').splice(0, 2).join('.'); // Index patterns - Wazuh alerts


exports.PLUGIN_VERSION_SHORT = PLUGIN_VERSION_SHORT;
const WAZUH_INDEX_TYPE_ALERTS = 'alerts';
exports.WAZUH_INDEX_TYPE_ALERTS = WAZUH_INDEX_TYPE_ALERTS;
const WAZUH_ALERTS_PREFIX = 'wazuh-alerts-';
exports.WAZUH_ALERTS_PREFIX = WAZUH_ALERTS_PREFIX;
const WAZUH_ALERTS_PATTERN = 'wazuh-alerts-*'; // Job - Wazuh monitoring

exports.WAZUH_ALERTS_PATTERN = WAZUH_ALERTS_PATTERN;
const WAZUH_INDEX_TYPE_MONITORING = 'monitoring';
exports.WAZUH_INDEX_TYPE_MONITORING = WAZUH_INDEX_TYPE_MONITORING;
const WAZUH_MONITORING_PREFIX = 'wazuh-monitoring-';
exports.WAZUH_MONITORING_PREFIX = WAZUH_MONITORING_PREFIX;
const WAZUH_MONITORING_PATTERN = 'wazuh-monitoring-*';
exports.WAZUH_MONITORING_PATTERN = WAZUH_MONITORING_PATTERN;
const WAZUH_MONITORING_TEMPLATE_NAME = 'wazuh-agent';
exports.WAZUH_MONITORING_TEMPLATE_NAME = WAZUH_MONITORING_TEMPLATE_NAME;
const WAZUH_MONITORING_DEFAULT_INDICES_SHARDS = 1;
exports.WAZUH_MONITORING_DEFAULT_INDICES_SHARDS = WAZUH_MONITORING_DEFAULT_INDICES_SHARDS;
const WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS = 0;
exports.WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS = WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS;
const WAZUH_MONITORING_DEFAULT_CREATION = 'w';
exports.WAZUH_MONITORING_DEFAULT_CREATION = WAZUH_MONITORING_DEFAULT_CREATION;
const WAZUH_MONITORING_DEFAULT_ENABLED = true;
exports.WAZUH_MONITORING_DEFAULT_ENABLED = WAZUH_MONITORING_DEFAULT_ENABLED;
const WAZUH_MONITORING_DEFAULT_FREQUENCY = 900;
exports.WAZUH_MONITORING_DEFAULT_FREQUENCY = WAZUH_MONITORING_DEFAULT_FREQUENCY;
const WAZUH_MONITORING_DEFAULT_CRON_FREQ = '0 * * * * *'; // Job - Wazuh statistics

exports.WAZUH_MONITORING_DEFAULT_CRON_FREQ = WAZUH_MONITORING_DEFAULT_CRON_FREQ;
const WAZUH_INDEX_TYPE_STATISTICS = 'statistics';
exports.WAZUH_INDEX_TYPE_STATISTICS = WAZUH_INDEX_TYPE_STATISTICS;
const WAZUH_STATISTICS_DEFAULT_PREFIX = 'wazuh';
exports.WAZUH_STATISTICS_DEFAULT_PREFIX = WAZUH_STATISTICS_DEFAULT_PREFIX;
const WAZUH_STATISTICS_DEFAULT_NAME = 'statistics';
exports.WAZUH_STATISTICS_DEFAULT_NAME = WAZUH_STATISTICS_DEFAULT_NAME;
const WAZUH_STATISTICS_PATTERN = `${WAZUH_STATISTICS_DEFAULT_PREFIX}-${WAZUH_STATISTICS_DEFAULT_NAME}-*`;
exports.WAZUH_STATISTICS_PATTERN = WAZUH_STATISTICS_PATTERN;
const WAZUH_STATISTICS_TEMPLATE_NAME = `${WAZUH_STATISTICS_DEFAULT_PREFIX}-${WAZUH_STATISTICS_DEFAULT_NAME}`;
exports.WAZUH_STATISTICS_TEMPLATE_NAME = WAZUH_STATISTICS_TEMPLATE_NAME;
const WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS = 1;
exports.WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS = WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS;
const WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS = 0;
exports.WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS = WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS;
const WAZUH_STATISTICS_DEFAULT_CREATION = 'w';
exports.WAZUH_STATISTICS_DEFAULT_CREATION = WAZUH_STATISTICS_DEFAULT_CREATION;
const WAZUH_STATISTICS_DEFAULT_STATUS = true;
exports.WAZUH_STATISTICS_DEFAULT_STATUS = WAZUH_STATISTICS_DEFAULT_STATUS;
const WAZUH_STATISTICS_DEFAULT_FREQUENCY = 900;
exports.WAZUH_STATISTICS_DEFAULT_FREQUENCY = WAZUH_STATISTICS_DEFAULT_FREQUENCY;
const WAZUH_STATISTICS_DEFAULT_CRON_FREQ = '0 */5 * * * *'; // Wazuh vulnerabilities

exports.WAZUH_STATISTICS_DEFAULT_CRON_FREQ = WAZUH_STATISTICS_DEFAULT_CRON_FREQ;
const WAZUH_VULNERABILITIES_PATTERN = 'wazuh-states-vulnerabilities-*';
exports.WAZUH_VULNERABILITIES_PATTERN = WAZUH_VULNERABILITIES_PATTERN;
const WAZUH_INDEX_TYPE_VULNERABILITIES = 'vulnerabilities'; // Job - Wazuh initialize

exports.WAZUH_INDEX_TYPE_VULNERABILITIES = WAZUH_INDEX_TYPE_VULNERABILITIES;
const WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME = 'wazuh-kibana'; // Permissions

exports.WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME = WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME;
const WAZUH_ROLE_ADMINISTRATOR_ID = 1;
exports.WAZUH_ROLE_ADMINISTRATOR_ID = WAZUH_ROLE_ADMINISTRATOR_ID;
const WAZUH_ROLE_ADMINISTRATOR_NAME = 'administrator'; // Sample data

exports.WAZUH_ROLE_ADMINISTRATOR_NAME = WAZUH_ROLE_ADMINISTRATOR_NAME;
const WAZUH_SAMPLE_ALERT_PREFIX = 'wazuh-alerts-4.x-';
exports.WAZUH_SAMPLE_ALERT_PREFIX = WAZUH_SAMPLE_ALERT_PREFIX;
const WAZUH_SAMPLE_ALERTS_INDEX_SHARDS = 1;
exports.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS = WAZUH_SAMPLE_ALERTS_INDEX_SHARDS;
const WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS = 0;
exports.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS = WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS;
const WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY = 'security';
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY = WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY;
const WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING = 'auditing-policy-monitoring';
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING = WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING;
const WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION = 'threat-detection';
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION = WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION;
const WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS = 3000;
exports.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS = WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS;
const WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS = {
  [WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY]: [{
    syscheck: true
  }, {
    aws: true
  }, {
    office: true
  }, {
    gcp: true
  }, {
    authentication: true
  }, {
    ssh: true
  }, {
    apache: true,
    alerts: 2000
  }, {
    web: true
  }, {
    windows: {
      service_control_manager: true
    },
    alerts: 1000
  }, {
    github: true
  }],
  [WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING]: [{
    rootcheck: true
  }, {
    audit: true
  }, {
    openscap: true
  }, {
    ciscat: true
  }],
  [WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION]: [{
    vulnerabilities: true
  }, {
    virustotal: true
  }, {
    osquery: true
  }, {
    docker: true
  }, {
    mitre: true
  }]
}; // Security

exports.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS = WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS;
const WAZUH_SECURITY_PLUGIN_OPENSEARCH_DASHBOARDS_SECURITY = 'OpenSearch Dashboards Security';
exports.WAZUH_SECURITY_PLUGIN_OPENSEARCH_DASHBOARDS_SECURITY = WAZUH_SECURITY_PLUGIN_OPENSEARCH_DASHBOARDS_SECURITY;
const WAZUH_SECURITY_PLUGINS = [WAZUH_SECURITY_PLUGIN_OPENSEARCH_DASHBOARDS_SECURITY]; // App configuration

exports.WAZUH_SECURITY_PLUGINS = WAZUH_SECURITY_PLUGINS;
const WAZUH_CONFIGURATION_CACHE_TIME = 10000; // time in ms;
// Reserved ids for Users/Role mapping

exports.WAZUH_CONFIGURATION_CACHE_TIME = WAZUH_CONFIGURATION_CACHE_TIME;
const WAZUH_API_RESERVED_ID_LOWER_THAN = 100;
exports.WAZUH_API_RESERVED_ID_LOWER_THAN = WAZUH_API_RESERVED_ID_LOWER_THAN;
const WAZUH_API_RESERVED_WUI_SECURITY_RULES = [1, 2]; // Wazuh data path

exports.WAZUH_API_RESERVED_WUI_SECURITY_RULES = WAZUH_API_RESERVED_WUI_SECURITY_RULES;
const WAZUH_DATA_PLUGIN_PLATFORM_BASE_PATH = 'data';

const WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH = _path.default.join(__dirname, '../../../', WAZUH_DATA_PLUGIN_PLATFORM_BASE_PATH);

exports.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH = WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH;

const WAZUH_DATA_ABSOLUTE_PATH = _path.default.join(WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH, 'wazuh'); // Wazuh data path - config


exports.WAZUH_DATA_ABSOLUTE_PATH = WAZUH_DATA_ABSOLUTE_PATH;

const WAZUH_DATA_CONFIG_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_ABSOLUTE_PATH, 'config');

exports.WAZUH_DATA_CONFIG_DIRECTORY_PATH = WAZUH_DATA_CONFIG_DIRECTORY_PATH;

const WAZUH_DATA_CONFIG_APP_PATH = _path.default.join(WAZUH_DATA_CONFIG_DIRECTORY_PATH, 'wazuh.yml');

exports.WAZUH_DATA_CONFIG_APP_PATH = WAZUH_DATA_CONFIG_APP_PATH;

const WAZUH_DATA_CONFIG_REGISTRY_PATH = _path.default.join(WAZUH_DATA_CONFIG_DIRECTORY_PATH, 'wazuh-registry.json'); // Wazuh data path - logs


exports.WAZUH_DATA_CONFIG_REGISTRY_PATH = WAZUH_DATA_CONFIG_REGISTRY_PATH;
const MAX_MB_LOG_FILES = 100;
exports.MAX_MB_LOG_FILES = MAX_MB_LOG_FILES;

const WAZUH_DATA_LOGS_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_ABSOLUTE_PATH, 'logs');

exports.WAZUH_DATA_LOGS_DIRECTORY_PATH = WAZUH_DATA_LOGS_DIRECTORY_PATH;
const WAZUH_DATA_LOGS_PLAIN_FILENAME = 'wazuhapp-plain.log';
exports.WAZUH_DATA_LOGS_PLAIN_FILENAME = WAZUH_DATA_LOGS_PLAIN_FILENAME;

const WAZUH_DATA_LOGS_PLAIN_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_DATA_LOGS_PLAIN_FILENAME);

exports.WAZUH_DATA_LOGS_PLAIN_PATH = WAZUH_DATA_LOGS_PLAIN_PATH;
const WAZUH_DATA_LOGS_RAW_FILENAME = 'wazuhapp.log';
exports.WAZUH_DATA_LOGS_RAW_FILENAME = WAZUH_DATA_LOGS_RAW_FILENAME;

const WAZUH_DATA_LOGS_RAW_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_DATA_LOGS_RAW_FILENAME); // Wazuh data path - UI logs


exports.WAZUH_DATA_LOGS_RAW_PATH = WAZUH_DATA_LOGS_RAW_PATH;
const WAZUH_UI_LOGS_PLAIN_FILENAME = 'wazuh-ui-plain.log';
exports.WAZUH_UI_LOGS_PLAIN_FILENAME = WAZUH_UI_LOGS_PLAIN_FILENAME;
const WAZUH_UI_LOGS_RAW_FILENAME = 'wazuh-ui.log';
exports.WAZUH_UI_LOGS_RAW_FILENAME = WAZUH_UI_LOGS_RAW_FILENAME;

const WAZUH_UI_LOGS_PLAIN_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_UI_LOGS_PLAIN_FILENAME);

exports.WAZUH_UI_LOGS_PLAIN_PATH = WAZUH_UI_LOGS_PLAIN_PATH;

const WAZUH_UI_LOGS_RAW_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_UI_LOGS_RAW_FILENAME); // Wazuh data path - downloads


exports.WAZUH_UI_LOGS_RAW_PATH = WAZUH_UI_LOGS_RAW_PATH;

const WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_ABSOLUTE_PATH, 'downloads');

exports.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH = WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH;

const WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH, 'reports'); // Queue


exports.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH = WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH;
const WAZUH_QUEUE_CRON_FREQ = '*/15 * * * * *'; // Every 15 seconds
// Wazuh errors

exports.WAZUH_QUEUE_CRON_FREQ = WAZUH_QUEUE_CRON_FREQ;
const WAZUH_ERROR_DAEMONS_NOT_READY = 'ERROR3099'; // Agents

exports.WAZUH_ERROR_DAEMONS_NOT_READY = WAZUH_ERROR_DAEMONS_NOT_READY;
let WAZUH_AGENTS_OS_TYPE;
exports.WAZUH_AGENTS_OS_TYPE = WAZUH_AGENTS_OS_TYPE;

(function (WAZUH_AGENTS_OS_TYPE) {
  WAZUH_AGENTS_OS_TYPE["WINDOWS"] = "windows";
  WAZUH_AGENTS_OS_TYPE["LINUX"] = "linux";
  WAZUH_AGENTS_OS_TYPE["SUNOS"] = "sunos";
  WAZUH_AGENTS_OS_TYPE["DARWIN"] = "darwin";
  WAZUH_AGENTS_OS_TYPE["OTHERS"] = "";
})(WAZUH_AGENTS_OS_TYPE || (exports.WAZUH_AGENTS_OS_TYPE = WAZUH_AGENTS_OS_TYPE = {}));

let WAZUH_MODULES_ID;
exports.WAZUH_MODULES_ID = WAZUH_MODULES_ID;

(function (WAZUH_MODULES_ID) {
  WAZUH_MODULES_ID["SECURITY_EVENTS"] = "general";
  WAZUH_MODULES_ID["INTEGRITY_MONITORING"] = "fim";
  WAZUH_MODULES_ID["AMAZON_WEB_SERVICES"] = "aws";
  WAZUH_MODULES_ID["OFFICE_365"] = "office";
  WAZUH_MODULES_ID["GOOGLE_CLOUD_PLATFORM"] = "gcp";
  WAZUH_MODULES_ID["POLICY_MONITORING"] = "pm";
  WAZUH_MODULES_ID["SECURITY_CONFIGURATION_ASSESSMENT"] = "sca";
  WAZUH_MODULES_ID["AUDITING"] = "audit";
  WAZUH_MODULES_ID["OPEN_SCAP"] = "oscap";
  WAZUH_MODULES_ID["VULNERABILITIES"] = "vuls";
  WAZUH_MODULES_ID["OSQUERY"] = "osquery";
  WAZUH_MODULES_ID["DOCKER"] = "docker";
  WAZUH_MODULES_ID["MITRE_ATTACK"] = "mitre";
  WAZUH_MODULES_ID["PCI_DSS"] = "pci";
  WAZUH_MODULES_ID["HIPAA"] = "hipaa";
  WAZUH_MODULES_ID["NIST_800_53"] = "nist";
  WAZUH_MODULES_ID["TSC"] = "tsc";
  WAZUH_MODULES_ID["CIS_CAT"] = "ciscat";
  WAZUH_MODULES_ID["VIRUSTOTAL"] = "virustotal";
  WAZUH_MODULES_ID["GDPR"] = "gdpr";
  WAZUH_MODULES_ID["GITHUB"] = "github";
})(WAZUH_MODULES_ID || (exports.WAZUH_MODULES_ID = WAZUH_MODULES_ID = {}));

let WAZUH_MENU_MANAGEMENT_SECTIONS_ID;
exports.WAZUH_MENU_MANAGEMENT_SECTIONS_ID = WAZUH_MENU_MANAGEMENT_SECTIONS_ID;

(function (WAZUH_MENU_MANAGEMENT_SECTIONS_ID) {
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["MANAGEMENT"] = "management";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["ADMINISTRATION"] = "administration";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["RULESET"] = "ruleset";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["RULES"] = "rules";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["DECODERS"] = "decoders";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["CDB_LISTS"] = "lists";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["GROUPS"] = "groups";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["CONFIGURATION"] = "configuration";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["STATUS_AND_REPORTS"] = "statusReports";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["STATUS"] = "status";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["CLUSTER"] = "monitoring";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["LOGS"] = "logs";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["REPORTING"] = "reporting";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["STATISTICS"] = "statistics";
})(WAZUH_MENU_MANAGEMENT_SECTIONS_ID || (exports.WAZUH_MENU_MANAGEMENT_SECTIONS_ID = WAZUH_MENU_MANAGEMENT_SECTIONS_ID = {}));

let WAZUH_MENU_TOOLS_SECTIONS_ID;
exports.WAZUH_MENU_TOOLS_SECTIONS_ID = WAZUH_MENU_TOOLS_SECTIONS_ID;

(function (WAZUH_MENU_TOOLS_SECTIONS_ID) {
  WAZUH_MENU_TOOLS_SECTIONS_ID["API_CONSOLE"] = "devTools";
  WAZUH_MENU_TOOLS_SECTIONS_ID["RULESET_TEST"] = "logtest";
})(WAZUH_MENU_TOOLS_SECTIONS_ID || (exports.WAZUH_MENU_TOOLS_SECTIONS_ID = WAZUH_MENU_TOOLS_SECTIONS_ID = {}));

let WAZUH_MENU_SECURITY_SECTIONS_ID;
exports.WAZUH_MENU_SECURITY_SECTIONS_ID = WAZUH_MENU_SECURITY_SECTIONS_ID;

(function (WAZUH_MENU_SECURITY_SECTIONS_ID) {
  WAZUH_MENU_SECURITY_SECTIONS_ID["USERS"] = "users";
  WAZUH_MENU_SECURITY_SECTIONS_ID["ROLES"] = "roles";
  WAZUH_MENU_SECURITY_SECTIONS_ID["POLICIES"] = "policies";
  WAZUH_MENU_SECURITY_SECTIONS_ID["ROLES_MAPPING"] = "roleMapping";
})(WAZUH_MENU_SECURITY_SECTIONS_ID || (exports.WAZUH_MENU_SECURITY_SECTIONS_ID = WAZUH_MENU_SECURITY_SECTIONS_ID = {}));

let WAZUH_MENU_SETTINGS_SECTIONS_ID;
exports.WAZUH_MENU_SETTINGS_SECTIONS_ID = WAZUH_MENU_SETTINGS_SECTIONS_ID;

(function (WAZUH_MENU_SETTINGS_SECTIONS_ID) {
  WAZUH_MENU_SETTINGS_SECTIONS_ID["SETTINGS"] = "settings";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["API_CONFIGURATION"] = "api";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["MODULES"] = "modules";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["SAMPLE_DATA"] = "sample_data";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["CONFIGURATION"] = "configuration";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["LOGS"] = "logs";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["MISCELLANEOUS"] = "miscellaneous";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["ABOUT"] = "about";
})(WAZUH_MENU_SETTINGS_SECTIONS_ID || (exports.WAZUH_MENU_SETTINGS_SECTIONS_ID = WAZUH_MENU_SETTINGS_SECTIONS_ID = {}));

const AUTHORIZED_AGENTS = 'authorized-agents'; // Wazuh links

exports.AUTHORIZED_AGENTS = AUTHORIZED_AGENTS;
const WAZUH_LINK_GITHUB = 'https://github.com/wazuh';
exports.WAZUH_LINK_GITHUB = WAZUH_LINK_GITHUB;
const WAZUH_LINK_GOOGLE_GROUPS = 'https://groups.google.com/forum/#!forum/wazuh';
exports.WAZUH_LINK_GOOGLE_GROUPS = WAZUH_LINK_GOOGLE_GROUPS;
const WAZUH_LINK_SLACK = 'https://wazuh.com/community/join-us-on-slack';
exports.WAZUH_LINK_SLACK = WAZUH_LINK_SLACK;
const HEALTH_CHECK = 'health-check'; // Health check

exports.HEALTH_CHECK = HEALTH_CHECK;
const HEALTH_CHECK_REDIRECTION_TIME = 300; //ms
// Plugin platform settings
// Default timeFilter set by the app

exports.HEALTH_CHECK_REDIRECTION_TIME = HEALTH_CHECK_REDIRECTION_TIME;
const WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER = {
  from: 'now-24h',
  to: 'now'
};
exports.WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER = WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER;
const PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER = 'timepicker:timeDefaults'; // Default maxBuckets set by the app

exports.PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER = PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER;
const WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS = 200000;
exports.WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS = WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS;
const PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS = 'timeline:max_buckets'; // Default metaFields set by the app

exports.PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS = PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS;
const WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS = ['_source', '_index'];
exports.WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS = WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS;
const PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS = 'metaFields'; // Logger

exports.PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS = PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS;
const UI_LOGGER_LEVELS = {
  WARNING: 'WARNING',
  INFO: 'INFO',
  ERROR: 'ERROR'
};
exports.UI_LOGGER_LEVELS = UI_LOGGER_LEVELS;
const UI_TOAST_COLOR = {
  SUCCESS: 'success',
  WARNING: 'warning',
  DANGER: 'danger'
}; // Assets

exports.UI_TOAST_COLOR = UI_TOAST_COLOR;
const ASSETS_BASE_URL_PREFIX = '/plugins/wazuh/assets/';
exports.ASSETS_BASE_URL_PREFIX = ASSETS_BASE_URL_PREFIX;
const ASSETS_PUBLIC_URL = '/plugins/wazuh/public/assets/'; // Reports

exports.ASSETS_PUBLIC_URL = ASSETS_PUBLIC_URL;
const REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH = 'images/logo_reports.png';
exports.REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH = REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH;
const REPORTS_PRIMARY_COLOR = '#256BD1';
exports.REPORTS_PRIMARY_COLOR = REPORTS_PRIMARY_COLOR;
const REPORTS_PAGE_FOOTER_TEXT = 'Copyright © 2023 Wazuh, Inc.';
exports.REPORTS_PAGE_FOOTER_TEXT = REPORTS_PAGE_FOOTER_TEXT;
const REPORTS_PAGE_HEADER_TEXT = 'info@wazuh.com\nhttps://wazuh.com'; // Plugin platform

exports.REPORTS_PAGE_HEADER_TEXT = REPORTS_PAGE_HEADER_TEXT;
const PLUGIN_PLATFORM_NAME = 'Wazuh dashboard';
exports.PLUGIN_PLATFORM_NAME = PLUGIN_PLATFORM_NAME;
const PLUGIN_PLATFORM_BASE_INSTALLATION_PATH = '/usr/share/wazuh-dashboard/data/wazuh/';
exports.PLUGIN_PLATFORM_BASE_INSTALLATION_PATH = PLUGIN_PLATFORM_BASE_INSTALLATION_PATH;
const PLUGIN_PLATFORM_INSTALLATION_USER = 'wazuh-dashboard';
exports.PLUGIN_PLATFORM_INSTALLATION_USER = PLUGIN_PLATFORM_INSTALLATION_USER;
const PLUGIN_PLATFORM_INSTALLATION_USER_GROUP = 'wazuh-dashboard';
exports.PLUGIN_PLATFORM_INSTALLATION_USER_GROUP = PLUGIN_PLATFORM_INSTALLATION_USER_GROUP;
const PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM = 'upgrade-guide';
exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM = PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM;
const PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING = 'user-manual/wazuh-dashboard/troubleshooting.html';
exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING = PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING;
const PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION = 'user-manual/wazuh-dashboard/config-file.html';
exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION = PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION;
const PLUGIN_PLATFORM_URL_GUIDE = 'https://opensearch.org/docs/2.10/about';
exports.PLUGIN_PLATFORM_URL_GUIDE = PLUGIN_PLATFORM_URL_GUIDE;
const PLUGIN_PLATFORM_URL_GUIDE_TITLE = 'OpenSearch guide';
exports.PLUGIN_PLATFORM_URL_GUIDE_TITLE = PLUGIN_PLATFORM_URL_GUIDE_TITLE;
const PLUGIN_PLATFORM_REQUEST_HEADERS = {
  'osd-xsrf': 'kibana'
}; // Plugin app

exports.PLUGIN_PLATFORM_REQUEST_HEADERS = PLUGIN_PLATFORM_REQUEST_HEADERS;
const PLUGIN_APP_NAME = 'Wazuh dashboard'; // UI

exports.PLUGIN_APP_NAME = PLUGIN_APP_NAME;
const UI_COLOR_STATUS = {
  success: '#007871',
  danger: '#BD271E',
  warning: '#FEC514',
  disabled: '#646A77',
  info: '#6092C0',
  default: '#000000'
};
exports.UI_COLOR_STATUS = UI_COLOR_STATUS;
const API_NAME_AGENT_STATUS = {
  ACTIVE: 'active',
  DISCONNECTED: 'disconnected',
  PENDING: 'pending',
  NEVER_CONNECTED: 'never_connected'
};
exports.API_NAME_AGENT_STATUS = API_NAME_AGENT_STATUS;
const UI_COLOR_AGENT_STATUS = {
  [API_NAME_AGENT_STATUS.ACTIVE]: UI_COLOR_STATUS.success,
  [API_NAME_AGENT_STATUS.DISCONNECTED]: UI_COLOR_STATUS.danger,
  [API_NAME_AGENT_STATUS.PENDING]: UI_COLOR_STATUS.warning,
  [API_NAME_AGENT_STATUS.NEVER_CONNECTED]: UI_COLOR_STATUS.disabled,
  default: UI_COLOR_STATUS.default
};
exports.UI_COLOR_AGENT_STATUS = UI_COLOR_AGENT_STATUS;
const UI_LABEL_NAME_AGENT_STATUS = {
  [API_NAME_AGENT_STATUS.ACTIVE]: 'Active',
  [API_NAME_AGENT_STATUS.DISCONNECTED]: 'Disconnected',
  [API_NAME_AGENT_STATUS.PENDING]: 'Pending',
  [API_NAME_AGENT_STATUS.NEVER_CONNECTED]: 'Never connected',
  default: 'Unknown'
};
exports.UI_LABEL_NAME_AGENT_STATUS = UI_LABEL_NAME_AGENT_STATUS;
const UI_ORDER_AGENT_STATUS = [API_NAME_AGENT_STATUS.ACTIVE, API_NAME_AGENT_STATUS.DISCONNECTED, API_NAME_AGENT_STATUS.PENDING, API_NAME_AGENT_STATUS.NEVER_CONNECTED];
exports.UI_ORDER_AGENT_STATUS = UI_ORDER_AGENT_STATUS;
const AGENT_SYNCED_STATUS = {
  SYNCED: 'synced',
  NOT_SYNCED: 'not synced'
}; // The status code can be seen here https://github.com/wazuh/wazuh/blob/686068a1f05d806b2e3b3d633a765320ae7ae114/src/wazuh_db/wdb.h#L55-L61

exports.AGENT_SYNCED_STATUS = AGENT_SYNCED_STATUS;
const AGENT_STATUS_CODE = [{
  STATUS_CODE: 0,
  STATUS_DESCRIPTION: 'Agent is connected'
}, {
  STATUS_CODE: 1,
  STATUS_DESCRIPTION: 'Invalid agent version'
}, {
  STATUS_CODE: 2,
  STATUS_DESCRIPTION: 'Error retrieving version'
}, {
  STATUS_CODE: 3,
  STATUS_DESCRIPTION: 'Shutdown message received'
}, {
  STATUS_CODE: 4,
  STATUS_DESCRIPTION: 'Disconnected because no keepalive received'
}, {
  STATUS_CODE: 5,
  STATUS_DESCRIPTION: 'Connection reset by manager'
}]; // Documentation

exports.AGENT_STATUS_CODE = AGENT_STATUS_CODE;
const DOCUMENTATION_WEB_BASE_URL = 'https://documentation.wazuh.com'; // Default Elasticsearch user name context

exports.DOCUMENTATION_WEB_BASE_URL = DOCUMENTATION_WEB_BASE_URL;
const ELASTIC_NAME = 'elastic'; // Default Wazuh indexer name

exports.ELASTIC_NAME = ELASTIC_NAME;
const WAZUH_INDEXER_NAME = 'Wazuh indexer'; // Not timeFieldName on index pattern

exports.WAZUH_INDEXER_NAME = WAZUH_INDEXER_NAME;
const NOT_TIME_FIELD_NAME_INDEX_PATTERN = 'not_time_field_name_index_pattern'; // Customization

exports.NOT_TIME_FIELD_NAME_INDEX_PATTERN = NOT_TIME_FIELD_NAME_INDEX_PATTERN;
const CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES = 1048576; // Plugin settings

exports.CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES = CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES;
let SettingCategory;
exports.SettingCategory = SettingCategory;

(function (SettingCategory) {
  SettingCategory[SettingCategory["GENERAL"] = 0] = "GENERAL";
  SettingCategory[SettingCategory["HEALTH_CHECK"] = 1] = "HEALTH_CHECK";
  SettingCategory[SettingCategory["MONITORING"] = 2] = "MONITORING";
  SettingCategory[SettingCategory["STATISTICS"] = 3] = "STATISTICS";
  SettingCategory[SettingCategory["VULNERABILITIES"] = 4] = "VULNERABILITIES";
  SettingCategory[SettingCategory["SECURITY"] = 5] = "SECURITY";
  SettingCategory[SettingCategory["CUSTOMIZATION"] = 6] = "CUSTOMIZATION";
})(SettingCategory || (exports.SettingCategory = SettingCategory = {}));

let EpluginSettingType;
exports.EpluginSettingType = EpluginSettingType;

(function (EpluginSettingType) {
  EpluginSettingType["text"] = "text";
  EpluginSettingType["textarea"] = "textarea";
  EpluginSettingType["switch"] = "switch";
  EpluginSettingType["number"] = "number";
  EpluginSettingType["editor"] = "editor";
  EpluginSettingType["select"] = "select";
  EpluginSettingType["filepicker"] = "filepicker";
})(EpluginSettingType || (exports.EpluginSettingType = EpluginSettingType = {}));

const PLUGIN_SETTINGS_CATEGORIES = {
  [SettingCategory.HEALTH_CHECK]: {
    title: 'Health check',
    description: "Checks will be executed by the app's Healthcheck.",
    renderOrder: SettingCategory.HEALTH_CHECK
  },
  [SettingCategory.GENERAL]: {
    title: 'General',
    description: 'Basic app settings related to alerts index pattern, hide the manager alerts in the dashboards, logs level and more.',
    renderOrder: SettingCategory.GENERAL
  },
  [SettingCategory.SECURITY]: {
    title: 'Security',
    description: 'Application security options such as unauthorized roles.',
    renderOrder: SettingCategory.SECURITY
  },
  [SettingCategory.MONITORING]: {
    title: 'Task:Monitoring',
    description: 'Options related to the agent status monitoring job and its storage in indexes.',
    renderOrder: SettingCategory.MONITORING
  },
  [SettingCategory.STATISTICS]: {
    title: 'Task:Statistics',
    description: 'Options related to the daemons manager monitoring job and their storage in indexes.',
    renderOrder: SettingCategory.STATISTICS
  },
  [SettingCategory.VULNERABILITIES]: {
    title: 'Vulnerabilities',
    description: 'Options related to the agent vulnerabilities monitoring job and its storage in indexes.',
    renderOrder: SettingCategory.VULNERABILITIES
  },
  [SettingCategory.CUSTOMIZATION]: {
    title: 'Custom branding',
    description: 'If you want to use custom branding elements such as logos, you can do so by editing the settings below.',
    documentationLink: 'user-manual/wazuh-dashboard/white-labeling.html',
    renderOrder: SettingCategory.CUSTOMIZATION
  }
};
exports.PLUGIN_SETTINGS_CATEGORIES = PLUGIN_SETTINGS_CATEGORIES;
const PLUGIN_SETTINGS = {
  'alerts.sample.prefix': {
    title: 'Sample alerts prefix',
    description: 'Define the index name prefix of sample alerts. It must match the template used by the index pattern to avoid unknown fields in dashboards.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_SAMPLE_ALERT_PREFIX,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#', '*')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  'checks.api': {
    title: 'API connection',
    description: 'Enable or disable the API health check when opening the app.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.fields': {
    title: 'Known fields',
    description: 'Enable or disable the known fields health check when opening the app.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.maxBuckets': {
    title: 'Set max buckets to 200000',
    description: 'Change the default value of the plugin platform max buckets configuration.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.metaFields': {
    title: 'Remove meta fields',
    description: 'Change the default value of the plugin platform metaField configuration.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.pattern': {
    title: 'Index pattern',
    description: 'Enable or disable the index pattern health check when opening the app.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.setup': {
    title: 'API version',
    description: 'Enable or disable the setup health check when opening the app.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.template': {
    title: 'Index template',
    description: 'Enable or disable the template health check when opening the app.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'checks.timeFilter': {
    title: 'Set time filter to 24h',
    description: 'Change the default value of the plugin platform timeFilter configuration.',
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'cron.prefix': {
    title: 'Cron prefix',
    description: 'Define the index prefix of predefined jobs.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_STATISTICS_DEFAULT_PREFIX,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#', '*')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  'cron.statistics.apis': {
    title: 'Includes APIs',
    description: 'Enter the ID of the hosts you want to save data from, leave this empty to run the task on every host.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.editor,
    defaultValue: [],
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      editor: {
        language: 'json'
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return JSON.stringify(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      try {
        return JSON.parse(value);
      } catch (error) {
        return value;
      }
    },
    validate: _settingsValidator.SettingsValidator.json(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.array(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isString, _settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces)))),
    validateBackend: function (schema) {
      return schema.arrayOf(schema.string({
        validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces)
      }));
    }
  },
  'cron.statistics.index.creation': {
    title: 'Index creation',
    description: 'Define the interval in which a new index will be created.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.select,
    options: {
      select: [{
        text: 'Hourly',
        value: 'h'
      }, {
        text: 'Daily',
        value: 'd'
      }, {
        text: 'Weekly',
        value: 'w'
      }, {
        text: 'Monthly',
        value: 'm'
      }]
    },
    defaultValue: WAZUH_STATISTICS_DEFAULT_CREATION,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    validate: function (value) {
      return _settingsValidator.SettingsValidator.literal(this.options.select.map(({
        value
      }) => value))(value);
    },
    validateBackend: function (schema) {
      return schema.oneOf(this.options.select.map(({
        value
      }) => schema.literal(value)));
    }
  },
  'cron.statistics.index.name': {
    title: 'Index name',
    description: 'Define the name of the index in which the documents will be saved.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_STATISTICS_DEFAULT_NAME,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#', '*')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  'cron.statistics.index.replicas': {
    title: 'Index replicas',
    description: 'Define the number of replicas to use for the statistics indices.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 0,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  'cron.statistics.index.shards': {
    title: 'Index shards',
    description: 'Define the number of shards to use for the statistics indices.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 1,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  'cron.statistics.interval': {
    title: 'Interval',
    description: 'Define the frequency of task execution using cron schedule expressions.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_STATISTICS_DEFAULT_CRON_FREQ,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    validate: function (value) {
      return (0, _nodeCron.validate)(value) ? undefined : 'Interval is not valid.';
    },
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  'cron.statistics.status': {
    title: 'Status',
    description: 'Enable or disable the statistics tasks.',
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.switch,
    defaultValue: WAZUH_STATISTICS_DEFAULT_STATUS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'customization.enabled': {
    title: 'Status',
    description: 'Enable or disable the customization.',
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresReloadingBrowserTab: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'customization.logo.app': {
    title: 'App main logo',
    description: `This logo is used as loading indicator while the user is logging into Wazuh API.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: '',
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png', '.svg'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 300,
            height: 70,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.app',
          resolveStaticURL: filename => `custom/images/${filename}?v=${Date.now()}` // ?v=${Date.now()} is used to force the browser to reload the image when a new file is uploaded

        }
      }
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({ ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  'customization.logo.healthcheck': {
    title: 'Healthcheck logo',
    description: `This logo is displayed during the Healthcheck routine of the app.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: '',
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png', '.svg'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 300,
            height: 70,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.healthcheck',
          resolveStaticURL: filename => `custom/images/${filename}?v=${Date.now()}` // ?v=${Date.now()} is used to force the browser to reload the image when a new file is uploaded

        }
      }
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({ ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  'customization.logo.reports': {
    title: 'PDF reports logo',
    description: `This logo is used in the PDF reports generated by the app. It's placed at the top left corner of every page of the PDF.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: '',
    defaultValueIfNotSet: REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 190,
            height: 40,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.reports',
          resolveStaticURL: filename => `custom/images/${filename}`
        }
      }
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({ ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  'customization.reports.footer': {
    title: 'Reports footer',
    description: 'Set the footer of the reports.',
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.textarea,
    defaultValue: '',
    defaultValueIfNotSet: REPORTS_PAGE_FOOTER_TEXT,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      maxRows: 2,
      maxLength: 50
    },
    validate: function (value) {
      var _this$options, _this$options2;

      return _settingsValidator.SettingsValidator.multipleLinesString({
        maxRows: (_this$options = this.options) === null || _this$options === void 0 ? void 0 : _this$options.maxRows,
        maxLength: (_this$options2 = this.options) === null || _this$options2 === void 0 ? void 0 : _this$options2.maxLength
      })(value);
    },
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate.bind(this)
      });
    }
  },
  'customization.reports.header': {
    title: 'Reports header',
    description: 'Set the header of the reports.',
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.textarea,
    defaultValue: '',
    defaultValueIfNotSet: REPORTS_PAGE_HEADER_TEXT,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      maxRows: 3,
      maxLength: 40
    },
    validate: function (value) {
      var _this$options3, _this$options4;

      return _settingsValidator.SettingsValidator.multipleLinesString({
        maxRows: (_this$options3 = this.options) === null || _this$options3 === void 0 ? void 0 : _this$options3.maxRows,
        maxLength: (_this$options4 = this.options) === null || _this$options4 === void 0 ? void 0 : _this$options4.maxLength
      })(value);
    },
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate.bind(this)
      });
    }
  },
  'enrollment.dns': {
    title: 'Enrollment DNS',
    description: 'Specifies the Wazuh registration server, used for the agent enrollment.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: '',
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    validate: _settingsValidator.SettingsValidator.hasNoSpaces,
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  'enrollment.password': {
    title: 'Enrollment password',
    description: 'Specifies the password used to authenticate during the agent enrollment.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: '',
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    validate: _settingsValidator.SettingsValidator.isNotEmptyString,
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  hideManagerAlerts: {
    title: 'Hide manager alerts',
    description: 'Hide the alerts of the manager in every dashboard.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresReloadingBrowserTab: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'ip.ignore': {
    title: 'Index pattern ignore',
    description: 'Disable certain index pattern names from being available in index pattern selector.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.editor,
    defaultValue: [],
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      editor: {
        language: 'json'
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return JSON.stringify(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      try {
        return JSON.parse(value);
      } catch (error) {
        return value;
      }
    },
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.json(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.array(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isString, _settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#'))))),
    validateBackend: function (schema) {
      return schema.arrayOf(schema.string({
        validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#'))
      }));
    }
  },
  'ip.selector': {
    title: 'IP selector',
    description: 'Define if the user is allowed to change the selected index pattern directly from the top menu bar.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'wazuh.updates.disabled': {
    title: 'Check updates',
    description: 'Define if the check updates service is active.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: false,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'logs.level': {
    title: 'Log level',
    description: 'Logging level of the App.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.select,
    options: {
      select: [{
        text: 'Info',
        value: 'info'
      }, {
        text: 'Debug',
        value: 'debug'
      }]
    },
    defaultValue: 'info',
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    validate: function (value) {
      return _settingsValidator.SettingsValidator.literal(this.options.select.map(({
        value
      }) => value))(value);
    },
    validateBackend: function (schema) {
      return schema.oneOf(this.options.select.map(({
        value
      }) => schema.literal(value)));
    }
  },
  pattern: {
    title: 'Index pattern',
    description: "Default index pattern to use on the app. If there's no valid index pattern, the app will automatically create one with the name indicated in this option.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_ALERTS_PATTERN,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  timeout: {
    title: 'Request timeout',
    description: 'Maximum time, in milliseconds, the app will wait for an API response when making requests to it. It will be ignored if the value is set under 1500 milliseconds.',
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.number,
    defaultValue: 20000,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      number: {
        min: 1500,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  'wazuh.monitoring.creation': {
    title: 'Index creation',
    description: 'Define the interval in which a new wazuh-monitoring index will be created.',
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.select,
    options: {
      select: [{
        text: 'Hourly',
        value: 'h'
      }, {
        text: 'Daily',
        value: 'd'
      }, {
        text: 'Weekly',
        value: 'w'
      }, {
        text: 'Monthly',
        value: 'm'
      }]
    },
    defaultValue: WAZUH_MONITORING_DEFAULT_CREATION,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    validate: function (value) {
      return _settingsValidator.SettingsValidator.literal(this.options.select.map(({
        value
      }) => value))(value);
    },
    validateBackend: function (schema) {
      return schema.oneOf(this.options.select.map(({
        value
      }) => schema.literal(value)));
    }
  },
  'wazuh.monitoring.enabled': {
    title: 'Status',
    description: 'Enable or disable the wazuh-monitoring index creation and/or visualization.',
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.switch,
    defaultValue: WAZUH_MONITORING_DEFAULT_ENABLED,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  'wazuh.monitoring.frequency': {
    title: 'Frequency',
    description: 'Frequency, in seconds, of API requests to get the state of the agents and create a new document in the wazuh-monitoring index with this data.',
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_MONITORING_DEFAULT_FREQUENCY,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    options: {
      number: {
        min: 60,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  'wazuh.monitoring.pattern': {
    title: 'Index pattern',
    description: 'Default index pattern to use for Wazuh monitoring.',
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_MONITORING_PATTERN,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#')),
    validateBackend: function (schema) {
      return schema.string({
        minLength: 1,
        validate: this.validate
      });
    }
  },
  'wazuh.monitoring.replicas': {
    title: 'Index replicas',
    description: 'Define the number of replicas to use for the wazuh-monitoring-* indices.',
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 0,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  'wazuh.monitoring.shards': {
    title: 'Index shards',
    description: 'Define the number of shards to use for the wazuh-monitoring-* indices.',
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_MONITORING_DEFAULT_INDICES_SHARDS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 1,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  'vulnerabilities.pattern': {
    title: 'Index pattern',
    description: 'Default index pattern to use for vulnerabilities.',
    category: SettingCategory.VULNERABILITIES,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_VULNERABILITIES_PATTERN,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: false,
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#')),
    validateBackend: function (schema) {
      return schema.string({
        minLength: 1,
        validate: this.validate
      });
    }
  }
};
exports.PLUGIN_SETTINGS = PLUGIN_SETTINGS;
let HTTP_STATUS_CODES; // Module Security configuration assessment

exports.HTTP_STATUS_CODES = HTTP_STATUS_CODES;

(function (HTTP_STATUS_CODES) {
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["CONTINUE"] = 100] = "CONTINUE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["SWITCHING_PROTOCOLS"] = 101] = "SWITCHING_PROTOCOLS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PROCESSING"] = 102] = "PROCESSING";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["OK"] = 200] = "OK";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["CREATED"] = 201] = "CREATED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["ACCEPTED"] = 202] = "ACCEPTED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NON_AUTHORITATIVE_INFORMATION"] = 203] = "NON_AUTHORITATIVE_INFORMATION";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NO_CONTENT"] = 204] = "NO_CONTENT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["RESET_CONTENT"] = 205] = "RESET_CONTENT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PARTIAL_CONTENT"] = 206] = "PARTIAL_CONTENT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MULTI_STATUS"] = 207] = "MULTI_STATUS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MULTIPLE_CHOICES"] = 300] = "MULTIPLE_CHOICES";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MOVED_PERMANENTLY"] = 301] = "MOVED_PERMANENTLY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MOVED_TEMPORARILY"] = 302] = "MOVED_TEMPORARILY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["SEE_OTHER"] = 303] = "SEE_OTHER";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_MODIFIED"] = 304] = "NOT_MODIFIED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["USE_PROXY"] = 305] = "USE_PROXY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["TEMPORARY_REDIRECT"] = 307] = "TEMPORARY_REDIRECT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PERMANENT_REDIRECT"] = 308] = "PERMANENT_REDIRECT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["BAD_REQUEST"] = 400] = "BAD_REQUEST";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNAUTHORIZED"] = 401] = "UNAUTHORIZED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PAYMENT_REQUIRED"] = 402] = "PAYMENT_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["FORBIDDEN"] = 403] = "FORBIDDEN";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_FOUND"] = 404] = "NOT_FOUND";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["METHOD_NOT_ALLOWED"] = 405] = "METHOD_NOT_ALLOWED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_ACCEPTABLE"] = 406] = "NOT_ACCEPTABLE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PROXY_AUTHENTICATION_REQUIRED"] = 407] = "PROXY_AUTHENTICATION_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_TIMEOUT"] = 408] = "REQUEST_TIMEOUT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["CONFLICT"] = 409] = "CONFLICT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["GONE"] = 410] = "GONE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["LENGTH_REQUIRED"] = 411] = "LENGTH_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PRECONDITION_FAILED"] = 412] = "PRECONDITION_FAILED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_TOO_LONG"] = 413] = "REQUEST_TOO_LONG";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_URI_TOO_LONG"] = 414] = "REQUEST_URI_TOO_LONG";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNSUPPORTED_MEDIA_TYPE"] = 415] = "UNSUPPORTED_MEDIA_TYPE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUESTED_RANGE_NOT_SATISFIABLE"] = 416] = "REQUESTED_RANGE_NOT_SATISFIABLE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["EXPECTATION_FAILED"] = 417] = "EXPECTATION_FAILED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["IM_A_TEAPOT"] = 418] = "IM_A_TEAPOT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["INSUFFICIENT_SPACE_ON_RESOURCE"] = 419] = "INSUFFICIENT_SPACE_ON_RESOURCE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["METHOD_FAILURE"] = 420] = "METHOD_FAILURE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MISDIRECTED_REQUEST"] = 421] = "MISDIRECTED_REQUEST";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNPROCESSABLE_ENTITY"] = 422] = "UNPROCESSABLE_ENTITY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["LOCKED"] = 423] = "LOCKED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["FAILED_DEPENDENCY"] = 424] = "FAILED_DEPENDENCY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PRECONDITION_REQUIRED"] = 428] = "PRECONDITION_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["TOO_MANY_REQUESTS"] = 429] = "TOO_MANY_REQUESTS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_HEADER_FIELDS_TOO_LARGE"] = 431] = "REQUEST_HEADER_FIELDS_TOO_LARGE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNAVAILABLE_FOR_LEGAL_REASONS"] = 451] = "UNAVAILABLE_FOR_LEGAL_REASONS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["INTERNAL_SERVER_ERROR"] = 500] = "INTERNAL_SERVER_ERROR";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_IMPLEMENTED"] = 501] = "NOT_IMPLEMENTED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["BAD_GATEWAY"] = 502] = "BAD_GATEWAY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["SERVICE_UNAVAILABLE"] = 503] = "SERVICE_UNAVAILABLE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["GATEWAY_TIMEOUT"] = 504] = "GATEWAY_TIMEOUT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["HTTP_VERSION_NOT_SUPPORTED"] = 505] = "HTTP_VERSION_NOT_SUPPORTED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["INSUFFICIENT_STORAGE"] = 507] = "INSUFFICIENT_STORAGE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NETWORK_AUTHENTICATION_REQUIRED"] = 511] = "NETWORK_AUTHENTICATION_REQUIRED";
})(HTTP_STATUS_CODES || (exports.HTTP_STATUS_CODES = HTTP_STATUS_CODES = {}));

const MODULE_SCA_CHECK_RESULT_LABEL = {
  passed: 'Passed',
  failed: 'Failed',
  'not applicable': 'Not applicable'
}; // Search bar
// This limits the results in the API request

exports.MODULE_SCA_CHECK_RESULT_LABEL = MODULE_SCA_CHECK_RESULT_LABEL;
const SEARCH_BAR_WQL_VALUE_SUGGESTIONS_COUNT = 30; // This limits the suggestions for the token of type value displayed in the search bar

exports.SEARCH_BAR_WQL_VALUE_SUGGESTIONS_COUNT = SEARCH_BAR_WQL_VALUE_SUGGESTIONS_COUNT;
const SEARCH_BAR_WQL_VALUE_SUGGESTIONS_DISPLAY_COUNT = 10;
/* Time in milliseconds to debounce the analysis of search bar. This mitigates some problems related
to changes running in parallel */

exports.SEARCH_BAR_WQL_VALUE_SUGGESTIONS_DISPLAY_COUNT = SEARCH_BAR_WQL_VALUE_SUGGESTIONS_DISPLAY_COUNT;
const SEARCH_BAR_DEBOUNCE_UPDATE_TIME = 400;
exports.SEARCH_BAR_DEBOUNCE_UPDATE_TIME = SEARCH_BAR_DEBOUNCE_UPDATE_TIME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnN0YW50cy50cyJdLCJuYW1lcyI6WyJQTFVHSU5fVkVSU0lPTiIsInZlcnNpb24iLCJQTFVHSU5fVkVSU0lPTl9TSE9SVCIsInNwbGl0Iiwic3BsaWNlIiwiam9pbiIsIldBWlVIX0lOREVYX1RZUEVfQUxFUlRTIiwiV0FaVUhfQUxFUlRTX1BSRUZJWCIsIldBWlVIX0FMRVJUU19QQVRURVJOIiwiV0FaVUhfSU5ERVhfVFlQRV9NT05JVE9SSU5HIiwiV0FaVUhfTU9OSVRPUklOR19QUkVGSVgiLCJXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk4iLCJXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUiLCJXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMiLCJXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfSU5ESUNFU19SRVBMSUNBUyIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9DUkVBVElPTiIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9FTkFCTEVEIiwiV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0ZSRVFVRU5DWSIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9DUk9OX0ZSRVEiLCJXQVpVSF9JTkRFWF9UWVBFX1NUQVRJU1RJQ1MiLCJXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfUFJFRklYIiwiV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX05BTUUiLCJXQVpVSF9TVEFUSVNUSUNTX1BBVFRFUk4iLCJXQVpVSF9TVEFUSVNUSUNTX1RFTVBMQVRFX05BTUUiLCJXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMiLCJXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfSU5ESUNFU19SRVBMSUNBUyIsIldBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9DUkVBVElPTiIsIldBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9TVEFUVVMiLCJXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfRlJFUVVFTkNZIiwiV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0NST05fRlJFUSIsIldBWlVIX1ZVTE5FUkFCSUxJVElFU19QQVRURVJOIiwiV0FaVUhfSU5ERVhfVFlQRV9WVUxORVJBQklMSVRJRVMiLCJXQVpVSF9QTFVHSU5fUExBVEZPUk1fVEVNUExBVEVfTkFNRSIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9OQU1FIiwiV0FaVUhfU0FNUExFX0FMRVJUX1BSRUZJWCIsIldBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfU0hBUkRTIiwiV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9SRVBMSUNBUyIsIldBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfU0VDVVJJVFkiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JZX0FVRElUSU5HX1BPTElDWV9NT05JVE9SSU5HIiwiV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SWV9USFJFQVRfREVURUNUSU9OIiwiV0FaVUhfU0FNUExFX0FMRVJUU19ERUZBVUxUX05VTUJFUl9BTEVSVFMiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JJRVNfVFlQRV9BTEVSVFMiLCJzeXNjaGVjayIsImF3cyIsIm9mZmljZSIsImdjcCIsImF1dGhlbnRpY2F0aW9uIiwic3NoIiwiYXBhY2hlIiwiYWxlcnRzIiwid2ViIiwid2luZG93cyIsInNlcnZpY2VfY29udHJvbF9tYW5hZ2VyIiwiZ2l0aHViIiwicm9vdGNoZWNrIiwiYXVkaXQiLCJvcGVuc2NhcCIsImNpc2NhdCIsInZ1bG5lcmFiaWxpdGllcyIsInZpcnVzdG90YWwiLCJvc3F1ZXJ5IiwiZG9ja2VyIiwibWl0cmUiLCJXQVpVSF9TRUNVUklUWV9QTFVHSU5fT1BFTlNFQVJDSF9EQVNIQk9BUkRTX1NFQ1VSSVRZIiwiV0FaVUhfU0VDVVJJVFlfUExVR0lOUyIsIldBWlVIX0NPTkZJR1VSQVRJT05fQ0FDSEVfVElNRSIsIldBWlVIX0FQSV9SRVNFUlZFRF9JRF9MT1dFUl9USEFOIiwiV0FaVUhfQVBJX1JFU0VSVkVEX1dVSV9TRUNVUklUWV9SVUxFUyIsIldBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfUEFUSCIsIldBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfQUJTT0xVVEVfUEFUSCIsInBhdGgiLCJfX2Rpcm5hbWUiLCJXQVpVSF9EQVRBX0FCU09MVVRFX1BBVEgiLCJXQVpVSF9EQVRBX0NPTkZJR19ESVJFQ1RPUllfUEFUSCIsIldBWlVIX0RBVEFfQ09ORklHX0FQUF9QQVRIIiwiV0FaVUhfREFUQV9DT05GSUdfUkVHSVNUUllfUEFUSCIsIk1BWF9NQl9MT0dfRklMRVMiLCJXQVpVSF9EQVRBX0xPR1NfRElSRUNUT1JZX1BBVEgiLCJXQVpVSF9EQVRBX0xPR1NfUExBSU5fRklMRU5BTUUiLCJXQVpVSF9EQVRBX0xPR1NfUExBSU5fUEFUSCIsIldBWlVIX0RBVEFfTE9HU19SQVdfRklMRU5BTUUiLCJXQVpVSF9EQVRBX0xPR1NfUkFXX1BBVEgiLCJXQVpVSF9VSV9MT0dTX1BMQUlOX0ZJTEVOQU1FIiwiV0FaVUhfVUlfTE9HU19SQVdfRklMRU5BTUUiLCJXQVpVSF9VSV9MT0dTX1BMQUlOX1BBVEgiLCJXQVpVSF9VSV9MT0dTX1JBV19QQVRIIiwiV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgiLCJXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIIiwiV0FaVUhfUVVFVUVfQ1JPTl9GUkVRIiwiV0FaVUhfRVJST1JfREFFTU9OU19OT1RfUkVBRFkiLCJXQVpVSF9BR0VOVFNfT1NfVFlQRSIsIldBWlVIX01PRFVMRVNfSUQiLCJXQVpVSF9NRU5VX01BTkFHRU1FTlRfU0VDVElPTlNfSUQiLCJXQVpVSF9NRU5VX1RPT0xTX1NFQ1RJT05TX0lEIiwiV0FaVUhfTUVOVV9TRUNVUklUWV9TRUNUSU9OU19JRCIsIldBWlVIX01FTlVfU0VUVElOR1NfU0VDVElPTlNfSUQiLCJBVVRIT1JJWkVEX0FHRU5UUyIsIldBWlVIX0xJTktfR0lUSFVCIiwiV0FaVUhfTElOS19HT09HTEVfR1JPVVBTIiwiV0FaVUhfTElOS19TTEFDSyIsIkhFQUxUSF9DSEVDSyIsIkhFQUxUSF9DSEVDS19SRURJUkVDVElPTl9USU1FIiwiV0FaVUhfUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfVElNRV9GSUxURVIiLCJmcm9tIiwidG8iLCJQTFVHSU5fUExBVEZPUk1fU0VUVElOR19OQU1FX1RJTUVfRklMVEVSIiwiV0FaVUhfUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTUFYX0JVQ0tFVFMiLCJQTFVHSU5fUExBVEZPUk1fU0VUVElOR19OQU1FX01BWF9CVUNLRVRTIiwiV0FaVUhfUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTUVUQUZJRUxEUyIsIlBMVUdJTl9QTEFURk9STV9TRVRUSU5HX05BTUVfTUVUQUZJRUxEUyIsIlVJX0xPR0dFUl9MRVZFTFMiLCJXQVJOSU5HIiwiSU5GTyIsIkVSUk9SIiwiVUlfVE9BU1RfQ09MT1IiLCJTVUNDRVNTIiwiREFOR0VSIiwiQVNTRVRTX0JBU0VfVVJMX1BSRUZJWCIsIkFTU0VUU19QVUJMSUNfVVJMIiwiUkVQT1JUU19MT0dPX0lNQUdFX0FTU0VUU19SRUxBVElWRV9QQVRIIiwiUkVQT1JUU19QUklNQVJZX0NPTE9SIiwiUkVQT1JUU19QQUdFX0ZPT1RFUl9URVhUIiwiUkVQT1JUU19QQUdFX0hFQURFUl9URVhUIiwiUExVR0lOX1BMQVRGT1JNX05BTUUiLCJQTFVHSU5fUExBVEZPUk1fQkFTRV9JTlNUQUxMQVRJT05fUEFUSCIsIlBMVUdJTl9QTEFURk9STV9JTlNUQUxMQVRJT05fVVNFUiIsIlBMVUdJTl9QTEFURk9STV9JTlNUQUxMQVRJT05fVVNFUl9HUk9VUCIsIlBMVUdJTl9QTEFURk9STV9XQVpVSF9ET0NVTUVOVEFUSU9OX1VSTF9QQVRIX1VQR1JBREVfUExBVEZPUk0iLCJQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9UUk9VQkxFU0hPT1RJTkciLCJQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9BUFBfQ09ORklHVVJBVElPTiIsIlBMVUdJTl9QTEFURk9STV9VUkxfR1VJREUiLCJQTFVHSU5fUExBVEZPUk1fVVJMX0dVSURFX1RJVExFIiwiUExVR0lOX1BMQVRGT1JNX1JFUVVFU1RfSEVBREVSUyIsIlBMVUdJTl9BUFBfTkFNRSIsIlVJX0NPTE9SX1NUQVRVUyIsInN1Y2Nlc3MiLCJkYW5nZXIiLCJ3YXJuaW5nIiwiZGlzYWJsZWQiLCJpbmZvIiwiZGVmYXVsdCIsIkFQSV9OQU1FX0FHRU5UX1NUQVRVUyIsIkFDVElWRSIsIkRJU0NPTk5FQ1RFRCIsIlBFTkRJTkciLCJORVZFUl9DT05ORUNURUQiLCJVSV9DT0xPUl9BR0VOVF9TVEFUVVMiLCJVSV9MQUJFTF9OQU1FX0FHRU5UX1NUQVRVUyIsIlVJX09SREVSX0FHRU5UX1NUQVRVUyIsIkFHRU5UX1NZTkNFRF9TVEFUVVMiLCJTWU5DRUQiLCJOT1RfU1lOQ0VEIiwiQUdFTlRfU1RBVFVTX0NPREUiLCJTVEFUVVNfQ09ERSIsIlNUQVRVU19ERVNDUklQVElPTiIsIkRPQ1VNRU5UQVRJT05fV0VCX0JBU0VfVVJMIiwiRUxBU1RJQ19OQU1FIiwiV0FaVUhfSU5ERVhFUl9OQU1FIiwiTk9UX1RJTUVfRklFTERfTkFNRV9JTkRFWF9QQVRURVJOIiwiQ1VTVE9NSVpBVElPTl9FTkRQT0lOVF9QQVlMT0FEX1VQTE9BRF9DVVNUT01fRklMRV9NQVhJTVVNX0JZVEVTIiwiU2V0dGluZ0NhdGVnb3J5IiwiRXBsdWdpblNldHRpbmdUeXBlIiwiUExVR0lOX1NFVFRJTkdTX0NBVEVHT1JJRVMiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwicmVuZGVyT3JkZXIiLCJHRU5FUkFMIiwiU0VDVVJJVFkiLCJNT05JVE9SSU5HIiwiU1RBVElTVElDUyIsIlZVTE5FUkFCSUxJVElFUyIsIkNVU1RPTUlaQVRJT04iLCJkb2N1bWVudGF0aW9uTGluayIsIlBMVUdJTl9TRVRUSU5HUyIsImNhdGVnb3J5IiwidHlwZSIsInRleHQiLCJkZWZhdWx0VmFsdWUiLCJpc0NvbmZpZ3VyYWJsZUZyb21GaWxlIiwiaXNDb25maWd1cmFibGVGcm9tVUkiLCJyZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjayIsInZhbGlkYXRlIiwiU2V0dGluZ3NWYWxpZGF0b3IiLCJjb21wb3NlIiwiaXNOb3RFbXB0eVN0cmluZyIsImhhc05vU3BhY2VzIiwibm9TdGFydHNXaXRoU3RyaW5nIiwiaGFzTm90SW52YWxpZENoYXJhY3RlcnMiLCJ2YWxpZGF0ZUJhY2tlbmQiLCJzY2hlbWEiLCJzdHJpbmciLCJzd2l0Y2giLCJvcHRpb25zIiwidmFsdWVzIiwibGFiZWwiLCJ2YWx1ZSIsImVuYWJsZWQiLCJ1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZSIsIkJvb2xlYW4iLCJpc0Jvb2xlYW4iLCJib29sZWFuIiwiZWRpdG9yIiwibGFuZ3VhZ2UiLCJ1aUZvcm1UcmFuc2Zvcm1Db25maWd1cmF0aW9uVmFsdWVUb0lucHV0VmFsdWUiLCJKU09OIiwic3RyaW5naWZ5IiwidWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlIiwicGFyc2UiLCJlcnJvciIsImpzb24iLCJhcnJheSIsImlzU3RyaW5nIiwiYXJyYXlPZiIsInNlbGVjdCIsImxpdGVyYWwiLCJtYXAiLCJvbmVPZiIsIm51bWJlciIsIm1pbiIsImludGVnZXIiLCJTdHJpbmciLCJOdW1iZXIiLCJiaW5kIiwicmVxdWlyZXNSZXN0YXJ0aW5nUGx1Z2luUGxhdGZvcm0iLCJ1bmRlZmluZWQiLCJyZXF1aXJlc1JlbG9hZGluZ0Jyb3dzZXJUYWIiLCJmaWxlcGlja2VyIiwiZmlsZSIsImV4dGVuc2lvbnMiLCJzaXplIiwibWF4Qnl0ZXMiLCJyZWNvbW1lbmRlZCIsImRpbWVuc2lvbnMiLCJ3aWR0aCIsImhlaWdodCIsInVuaXQiLCJzdG9yZSIsInJlbGF0aXZlUGF0aEZpbGVTeXN0ZW0iLCJmaWxlbmFtZSIsInJlc29sdmVTdGF0aWNVUkwiLCJEYXRlIiwibm93IiwiZmlsZVBpY2tlckZpbGVTaXplIiwibWVhbmluZ2Z1bFVuaXQiLCJmaWxlUGlja2VyU3VwcG9ydGVkRXh0ZW5zaW9ucyIsImRlZmF1bHRWYWx1ZUlmTm90U2V0IiwidGV4dGFyZWEiLCJtYXhSb3dzIiwibWF4TGVuZ3RoIiwibXVsdGlwbGVMaW5lc1N0cmluZyIsImhpZGVNYW5hZ2VyQWxlcnRzIiwibm9MaXRlcmFsU3RyaW5nIiwicGF0dGVybiIsInRpbWVvdXQiLCJtaW5MZW5ndGgiLCJIVFRQX1NUQVRVU19DT0RFUyIsIk1PRFVMRV9TQ0FfQ0hFQ0tfUkVTVUxUX0xBQkVMIiwicGFzc2VkIiwiZmFpbGVkIiwiU0VBUkNIX0JBUl9XUUxfVkFMVUVfU1VHR0VTVElPTlNfQ09VTlQiLCJTRUFSQ0hfQkFSX1dRTF9WQUxVRV9TVUdHRVNUSU9OU19ESVNQTEFZX0NPVU5UIiwiU0VBUkNIX0JBUl9ERUJPVU5DRV9VUERBVEVfVElNRSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFXQTs7QUFDQTs7QUFDQTs7QUFDQTs7OztBQWRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNQTtBQUNPLE1BQU1BLGNBQWMsR0FBR0MsZ0JBQXZCOzs7QUFDQSxNQUFNQyxvQkFBb0IsR0FBR0QsaUJBQVFFLEtBQVIsQ0FBYyxHQUFkLEVBQW1CQyxNQUFuQixDQUEwQixDQUExQixFQUE2QixDQUE3QixFQUFnQ0MsSUFBaEMsQ0FBcUMsR0FBckMsQ0FBN0IsQyxDQUVQOzs7O0FBQ08sTUFBTUMsdUJBQXVCLEdBQUcsUUFBaEM7O0FBQ0EsTUFBTUMsbUJBQW1CLEdBQUcsZUFBNUI7O0FBQ0EsTUFBTUMsb0JBQW9CLEdBQUcsZ0JBQTdCLEMsQ0FFUDs7O0FBQ08sTUFBTUMsMkJBQTJCLEdBQUcsWUFBcEM7O0FBQ0EsTUFBTUMsdUJBQXVCLEdBQUcsbUJBQWhDOztBQUNBLE1BQU1DLHdCQUF3QixHQUFHLG9CQUFqQzs7QUFDQSxNQUFNQyw4QkFBOEIsR0FBRyxhQUF2Qzs7QUFDQSxNQUFNQyx1Q0FBdUMsR0FBRyxDQUFoRDs7QUFDQSxNQUFNQyx5Q0FBeUMsR0FBRyxDQUFsRDs7QUFDQSxNQUFNQyxpQ0FBaUMsR0FBRyxHQUExQzs7QUFDQSxNQUFNQyxnQ0FBZ0MsR0FBRyxJQUF6Qzs7QUFDQSxNQUFNQyxrQ0FBa0MsR0FBRyxHQUEzQzs7QUFDQSxNQUFNQyxrQ0FBa0MsR0FBRyxhQUEzQyxDLENBRVA7OztBQUNPLE1BQU1DLDJCQUEyQixHQUFHLFlBQXBDOztBQUNBLE1BQU1DLCtCQUErQixHQUFHLE9BQXhDOztBQUNBLE1BQU1DLDZCQUE2QixHQUFHLFlBQXRDOztBQUNBLE1BQU1DLHdCQUF3QixHQUFJLEdBQUVGLCtCQUFnQyxJQUFHQyw2QkFBOEIsSUFBckc7O0FBQ0EsTUFBTUUsOEJBQThCLEdBQUksR0FBRUgsK0JBQWdDLElBQUdDLDZCQUE4QixFQUEzRzs7QUFDQSxNQUFNRyx1Q0FBdUMsR0FBRyxDQUFoRDs7QUFDQSxNQUFNQyx5Q0FBeUMsR0FBRyxDQUFsRDs7QUFDQSxNQUFNQyxpQ0FBaUMsR0FBRyxHQUExQzs7QUFDQSxNQUFNQywrQkFBK0IsR0FBRyxJQUF4Qzs7QUFDQSxNQUFNQyxrQ0FBa0MsR0FBRyxHQUEzQzs7QUFDQSxNQUFNQyxrQ0FBa0MsR0FBRyxlQUEzQyxDLENBRVA7OztBQUNPLE1BQU1DLDZCQUE2QixHQUFHLGdDQUF0Qzs7QUFDQSxNQUFNQyxnQ0FBZ0MsR0FBRyxpQkFBekMsQyxDQUVQOzs7QUFDTyxNQUFNQyxtQ0FBbUMsR0FBRyxjQUE1QyxDLENBRVA7OztBQUNPLE1BQU1DLDJCQUEyQixHQUFHLENBQXBDOztBQUNBLE1BQU1DLDZCQUE2QixHQUFHLGVBQXRDLEMsQ0FFUDs7O0FBQ08sTUFBTUMseUJBQXlCLEdBQUcsbUJBQWxDOztBQUNBLE1BQU1DLGdDQUFnQyxHQUFHLENBQXpDOztBQUNBLE1BQU1DLGtDQUFrQyxHQUFHLENBQTNDOztBQUNBLE1BQU1DLHFDQUFxQyxHQUFHLFVBQTlDOztBQUNBLE1BQU1DLHVEQUF1RCxHQUNsRSw0QkFESzs7QUFFQSxNQUFNQyw2Q0FBNkMsR0FBRyxrQkFBdEQ7O0FBQ0EsTUFBTUMseUNBQXlDLEdBQUcsSUFBbEQ7O0FBQ0EsTUFBTUMsMENBQTBDLEdBQUc7QUFDeEQsR0FBQ0oscUNBQUQsR0FBeUMsQ0FDdkM7QUFBRUssSUFBQUEsUUFBUSxFQUFFO0FBQVosR0FEdUMsRUFFdkM7QUFBRUMsSUFBQUEsR0FBRyxFQUFFO0FBQVAsR0FGdUMsRUFHdkM7QUFBRUMsSUFBQUEsTUFBTSxFQUFFO0FBQVYsR0FIdUMsRUFJdkM7QUFBRUMsSUFBQUEsR0FBRyxFQUFFO0FBQVAsR0FKdUMsRUFLdkM7QUFBRUMsSUFBQUEsY0FBYyxFQUFFO0FBQWxCLEdBTHVDLEVBTXZDO0FBQUVDLElBQUFBLEdBQUcsRUFBRTtBQUFQLEdBTnVDLEVBT3ZDO0FBQUVDLElBQUFBLE1BQU0sRUFBRSxJQUFWO0FBQWdCQyxJQUFBQSxNQUFNLEVBQUU7QUFBeEIsR0FQdUMsRUFRdkM7QUFBRUMsSUFBQUEsR0FBRyxFQUFFO0FBQVAsR0FSdUMsRUFTdkM7QUFBRUMsSUFBQUEsT0FBTyxFQUFFO0FBQUVDLE1BQUFBLHVCQUF1QixFQUFFO0FBQTNCLEtBQVg7QUFBOENILElBQUFBLE1BQU0sRUFBRTtBQUF0RCxHQVR1QyxFQVV2QztBQUFFSSxJQUFBQSxNQUFNLEVBQUU7QUFBVixHQVZ1QyxDQURlO0FBYXhELEdBQUNmLHVEQUFELEdBQTJELENBQ3pEO0FBQUVnQixJQUFBQSxTQUFTLEVBQUU7QUFBYixHQUR5RCxFQUV6RDtBQUFFQyxJQUFBQSxLQUFLLEVBQUU7QUFBVCxHQUZ5RCxFQUd6RDtBQUFFQyxJQUFBQSxRQUFRLEVBQUU7QUFBWixHQUh5RCxFQUl6RDtBQUFFQyxJQUFBQSxNQUFNLEVBQUU7QUFBVixHQUp5RCxDQWJIO0FBbUJ4RCxHQUFDbEIsNkNBQUQsR0FBaUQsQ0FDL0M7QUFBRW1CLElBQUFBLGVBQWUsRUFBRTtBQUFuQixHQUQrQyxFQUUvQztBQUFFQyxJQUFBQSxVQUFVLEVBQUU7QUFBZCxHQUYrQyxFQUcvQztBQUFFQyxJQUFBQSxPQUFPLEVBQUU7QUFBWCxHQUgrQyxFQUkvQztBQUFFQyxJQUFBQSxNQUFNLEVBQUU7QUFBVixHQUorQyxFQUsvQztBQUFFQyxJQUFBQSxLQUFLLEVBQUU7QUFBVCxHQUwrQztBQW5CTyxDQUFuRCxDLENBNEJQOzs7QUFDTyxNQUFNQyxvREFBb0QsR0FDL0QsZ0NBREs7O0FBR0EsTUFBTUMsc0JBQXNCLEdBQUcsQ0FDcENELG9EQURvQyxDQUEvQixDLENBSVA7OztBQUNPLE1BQU1FLDhCQUE4QixHQUFHLEtBQXZDLEMsQ0FBOEM7QUFFckQ7OztBQUNPLE1BQU1DLGdDQUFnQyxHQUFHLEdBQXpDOztBQUNBLE1BQU1DLHFDQUFxQyxHQUFHLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBOUMsQyxDQUVQOzs7QUFDQSxNQUFNQyxvQ0FBb0MsR0FBRyxNQUE3Qzs7QUFDTyxNQUFNQyw2Q0FBNkMsR0FBR0MsY0FBS2xFLElBQUwsQ0FDM0RtRSxTQUQyRCxFQUUzRCxXQUYyRCxFQUczREgsb0NBSDJELENBQXREOzs7O0FBS0EsTUFBTUksd0JBQXdCLEdBQUdGLGNBQUtsRSxJQUFMLENBQ3RDaUUsNkNBRHNDLEVBRXRDLE9BRnNDLENBQWpDLEMsQ0FLUDs7Ozs7QUFDTyxNQUFNSSxnQ0FBZ0MsR0FBR0gsY0FBS2xFLElBQUwsQ0FDOUNvRSx3QkFEOEMsRUFFOUMsUUFGOEMsQ0FBekM7Ozs7QUFJQSxNQUFNRSwwQkFBMEIsR0FBR0osY0FBS2xFLElBQUwsQ0FDeENxRSxnQ0FEd0MsRUFFeEMsV0FGd0MsQ0FBbkM7Ozs7QUFJQSxNQUFNRSwrQkFBK0IsR0FBR0wsY0FBS2xFLElBQUwsQ0FDN0NxRSxnQ0FENkMsRUFFN0MscUJBRjZDLENBQXhDLEMsQ0FLUDs7OztBQUNPLE1BQU1HLGdCQUFnQixHQUFHLEdBQXpCOzs7QUFDQSxNQUFNQyw4QkFBOEIsR0FBR1AsY0FBS2xFLElBQUwsQ0FDNUNvRSx3QkFENEMsRUFFNUMsTUFGNEMsQ0FBdkM7OztBQUlBLE1BQU1NLDhCQUE4QixHQUFHLG9CQUF2Qzs7O0FBQ0EsTUFBTUMsMEJBQTBCLEdBQUdULGNBQUtsRSxJQUFMLENBQ3hDeUUsOEJBRHdDLEVBRXhDQyw4QkFGd0MsQ0FBbkM7OztBQUlBLE1BQU1FLDRCQUE0QixHQUFHLGNBQXJDOzs7QUFDQSxNQUFNQyx3QkFBd0IsR0FBR1gsY0FBS2xFLElBQUwsQ0FDdEN5RSw4QkFEc0MsRUFFdENHLDRCQUZzQyxDQUFqQyxDLENBS1A7Ozs7QUFDTyxNQUFNRSw0QkFBNEIsR0FBRyxvQkFBckM7O0FBQ0EsTUFBTUMsMEJBQTBCLEdBQUcsY0FBbkM7OztBQUNBLE1BQU1DLHdCQUF3QixHQUFHZCxjQUFLbEUsSUFBTCxDQUN0Q3lFLDhCQURzQyxFQUV0Q0ssNEJBRnNDLENBQWpDOzs7O0FBSUEsTUFBTUcsc0JBQXNCLEdBQUdmLGNBQUtsRSxJQUFMLENBQ3BDeUUsOEJBRG9DLEVBRXBDTSwwQkFGb0MsQ0FBL0IsQyxDQUtQOzs7OztBQUNPLE1BQU1HLG1DQUFtQyxHQUFHaEIsY0FBS2xFLElBQUwsQ0FDakRvRSx3QkFEaUQsRUFFakQsV0FGaUQsQ0FBNUM7Ozs7QUFJQSxNQUFNZSwyQ0FBMkMsR0FBR2pCLGNBQUtsRSxJQUFMLENBQ3pEa0YsbUNBRHlELEVBRXpELFNBRnlELENBQXBELEMsQ0FLUDs7OztBQUNPLE1BQU1FLHFCQUFxQixHQUFHLGdCQUE5QixDLENBQWdEO0FBRXZEOzs7QUFDTyxNQUFNQyw2QkFBNkIsR0FBRyxXQUF0QyxDLENBRVA7OztJQUNZQyxvQjs7O1dBQUFBLG9CO0FBQUFBLEVBQUFBLG9CO0FBQUFBLEVBQUFBLG9CO0FBQUFBLEVBQUFBLG9CO0FBQUFBLEVBQUFBLG9CO0FBQUFBLEVBQUFBLG9CO0dBQUFBLG9CLG9DQUFBQSxvQjs7SUFRQUMsZ0I7OztXQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtBQUFBQSxFQUFBQSxnQjtHQUFBQSxnQixnQ0FBQUEsZ0I7O0lBd0JBQyxpQzs7O1dBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0FBQUFBLEVBQUFBLGlDO0dBQUFBLGlDLGlEQUFBQSxpQzs7SUFpQkFDLDRCOzs7V0FBQUEsNEI7QUFBQUEsRUFBQUEsNEI7QUFBQUEsRUFBQUEsNEI7R0FBQUEsNEIsNENBQUFBLDRCOztJQUtBQywrQjs7O1dBQUFBLCtCO0FBQUFBLEVBQUFBLCtCO0FBQUFBLEVBQUFBLCtCO0FBQUFBLEVBQUFBLCtCO0FBQUFBLEVBQUFBLCtCO0dBQUFBLCtCLCtDQUFBQSwrQjs7SUFPQUMsK0I7OztXQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtBQUFBQSxFQUFBQSwrQjtHQUFBQSwrQiwrQ0FBQUEsK0I7O0FBV0wsTUFBTUMsaUJBQWlCLEdBQUcsbUJBQTFCLEMsQ0FFUDs7O0FBQ08sTUFBTUMsaUJBQWlCLEdBQUcsMEJBQTFCOztBQUNBLE1BQU1DLHdCQUF3QixHQUNuQywrQ0FESzs7QUFFQSxNQUFNQyxnQkFBZ0IsR0FBRyw4Q0FBekI7O0FBRUEsTUFBTUMsWUFBWSxHQUFHLGNBQXJCLEMsQ0FFUDs7O0FBQ08sTUFBTUMsNkJBQTZCLEdBQUcsR0FBdEMsQyxDQUEyQztBQUVsRDtBQUNBOzs7QUFDTyxNQUFNQyx5Q0FBeUMsR0FBRztBQUN2REMsRUFBQUEsSUFBSSxFQUFFLFNBRGlEO0FBRXZEQyxFQUFBQSxFQUFFLEVBQUU7QUFGbUQsQ0FBbEQ7O0FBSUEsTUFBTUMsd0NBQXdDLEdBQ25ELHlCQURLLEMsQ0FHUDs7O0FBQ08sTUFBTUMseUNBQXlDLEdBQUcsTUFBbEQ7O0FBQ0EsTUFBTUMsd0NBQXdDLEdBQUcsc0JBQWpELEMsQ0FFUDs7O0FBQ08sTUFBTUMsd0NBQXdDLEdBQUcsQ0FBQyxTQUFELEVBQVksUUFBWixDQUFqRDs7QUFDQSxNQUFNQyx1Q0FBdUMsR0FBRyxZQUFoRCxDLENBRVA7OztBQUNPLE1BQU1DLGdCQUFnQixHQUFHO0FBQzlCQyxFQUFBQSxPQUFPLEVBQUUsU0FEcUI7QUFFOUJDLEVBQUFBLElBQUksRUFBRSxNQUZ3QjtBQUc5QkMsRUFBQUEsS0FBSyxFQUFFO0FBSHVCLENBQXpCOztBQU1BLE1BQU1DLGNBQWMsR0FBRztBQUM1QkMsRUFBQUEsT0FBTyxFQUFFLFNBRG1CO0FBRTVCSixFQUFBQSxPQUFPLEVBQUUsU0FGbUI7QUFHNUJLLEVBQUFBLE1BQU0sRUFBRTtBQUhvQixDQUF2QixDLENBTVA7OztBQUNPLE1BQU1DLHNCQUFzQixHQUFHLHdCQUEvQjs7QUFDQSxNQUFNQyxpQkFBaUIsR0FBRywrQkFBMUIsQyxDQUVQOzs7QUFDTyxNQUFNQyx1Q0FBdUMsR0FDbEQseUJBREs7O0FBRUEsTUFBTUMscUJBQXFCLEdBQUcsU0FBOUI7O0FBQ0EsTUFBTUMsd0JBQXdCLEdBQUcsOEJBQWpDOztBQUNBLE1BQU1DLHdCQUF3QixHQUFHLG1DQUFqQyxDLENBRVA7OztBQUNPLE1BQU1DLG9CQUFvQixHQUFHLGlCQUE3Qjs7QUFDQSxNQUFNQyxzQ0FBc0MsR0FDakQsd0NBREs7O0FBRUEsTUFBTUMsaUNBQWlDLEdBQUcsaUJBQTFDOztBQUNBLE1BQU1DLHVDQUF1QyxHQUFHLGlCQUFoRDs7QUFDQSxNQUFNQyw2REFBNkQsR0FDeEUsZUFESzs7QUFFQSxNQUFNQyw0REFBNEQsR0FDdkUsa0RBREs7O0FBRUEsTUFBTUMsOERBQThELEdBQ3pFLDhDQURLOztBQUVBLE1BQU1DLHlCQUF5QixHQUNwQyx3Q0FESzs7QUFFQSxNQUFNQywrQkFBK0IsR0FBRyxrQkFBeEM7O0FBRUEsTUFBTUMsK0JBQStCLEdBQUc7QUFDN0MsY0FBWTtBQURpQyxDQUF4QyxDLENBSVA7OztBQUNPLE1BQU1DLGVBQWUsR0FBRyxpQkFBeEIsQyxDQUVQOzs7QUFDTyxNQUFNQyxlQUFlLEdBQUc7QUFDN0JDLEVBQUFBLE9BQU8sRUFBRSxTQURvQjtBQUU3QkMsRUFBQUEsTUFBTSxFQUFFLFNBRnFCO0FBRzdCQyxFQUFBQSxPQUFPLEVBQUUsU0FIb0I7QUFJN0JDLEVBQUFBLFFBQVEsRUFBRSxTQUptQjtBQUs3QkMsRUFBQUEsSUFBSSxFQUFFLFNBTHVCO0FBTTdCQyxFQUFBQSxPQUFPLEVBQUU7QUFOb0IsQ0FBeEI7O0FBU0EsTUFBTUMscUJBQXFCLEdBQUc7QUFDbkNDLEVBQUFBLE1BQU0sRUFBRSxRQUQyQjtBQUVuQ0MsRUFBQUEsWUFBWSxFQUFFLGNBRnFCO0FBR25DQyxFQUFBQSxPQUFPLEVBQUUsU0FIMEI7QUFJbkNDLEVBQUFBLGVBQWUsRUFBRTtBQUprQixDQUE5Qjs7QUFPQSxNQUFNQyxxQkFBcUIsR0FBRztBQUNuQyxHQUFDTCxxQkFBcUIsQ0FBQ0MsTUFBdkIsR0FBZ0NSLGVBQWUsQ0FBQ0MsT0FEYjtBQUVuQyxHQUFDTSxxQkFBcUIsQ0FBQ0UsWUFBdkIsR0FBc0NULGVBQWUsQ0FBQ0UsTUFGbkI7QUFHbkMsR0FBQ0sscUJBQXFCLENBQUNHLE9BQXZCLEdBQWlDVixlQUFlLENBQUNHLE9BSGQ7QUFJbkMsR0FBQ0kscUJBQXFCLENBQUNJLGVBQXZCLEdBQXlDWCxlQUFlLENBQUNJLFFBSnRCO0FBS25DRSxFQUFBQSxPQUFPLEVBQUVOLGVBQWUsQ0FBQ007QUFMVSxDQUE5Qjs7QUFRQSxNQUFNTywwQkFBMEIsR0FBRztBQUN4QyxHQUFDTixxQkFBcUIsQ0FBQ0MsTUFBdkIsR0FBZ0MsUUFEUTtBQUV4QyxHQUFDRCxxQkFBcUIsQ0FBQ0UsWUFBdkIsR0FBc0MsY0FGRTtBQUd4QyxHQUFDRixxQkFBcUIsQ0FBQ0csT0FBdkIsR0FBaUMsU0FITztBQUl4QyxHQUFDSCxxQkFBcUIsQ0FBQ0ksZUFBdkIsR0FBeUMsaUJBSkQ7QUFLeENMLEVBQUFBLE9BQU8sRUFBRTtBQUwrQixDQUFuQzs7QUFRQSxNQUFNUSxxQkFBcUIsR0FBRyxDQUNuQ1AscUJBQXFCLENBQUNDLE1BRGEsRUFFbkNELHFCQUFxQixDQUFDRSxZQUZhLEVBR25DRixxQkFBcUIsQ0FBQ0csT0FIYSxFQUluQ0gscUJBQXFCLENBQUNJLGVBSmEsQ0FBOUI7O0FBT0EsTUFBTUksbUJBQW1CLEdBQUc7QUFDakNDLEVBQUFBLE1BQU0sRUFBRSxRQUR5QjtBQUVqQ0MsRUFBQUEsVUFBVSxFQUFFO0FBRnFCLENBQTVCLEMsQ0FLUDs7O0FBRU8sTUFBTUMsaUJBQWlCLEdBQUcsQ0FDL0I7QUFDRUMsRUFBQUEsV0FBVyxFQUFFLENBRGY7QUFFRUMsRUFBQUEsa0JBQWtCLEVBQUU7QUFGdEIsQ0FEK0IsRUFLL0I7QUFDRUQsRUFBQUEsV0FBVyxFQUFFLENBRGY7QUFFRUMsRUFBQUEsa0JBQWtCLEVBQUU7QUFGdEIsQ0FMK0IsRUFTL0I7QUFDRUQsRUFBQUEsV0FBVyxFQUFFLENBRGY7QUFFRUMsRUFBQUEsa0JBQWtCLEVBQUU7QUFGdEIsQ0FUK0IsRUFhL0I7QUFDRUQsRUFBQUEsV0FBVyxFQUFFLENBRGY7QUFFRUMsRUFBQUEsa0JBQWtCLEVBQUU7QUFGdEIsQ0FiK0IsRUFpQi9CO0FBQ0VELEVBQUFBLFdBQVcsRUFBRSxDQURmO0FBRUVDLEVBQUFBLGtCQUFrQixFQUFFO0FBRnRCLENBakIrQixFQXFCL0I7QUFDRUQsRUFBQUEsV0FBVyxFQUFFLENBRGY7QUFFRUMsRUFBQUEsa0JBQWtCLEVBQUU7QUFGdEIsQ0FyQitCLENBQTFCLEMsQ0EyQlA7OztBQUNPLE1BQU1DLDBCQUEwQixHQUFHLGlDQUFuQyxDLENBRVA7OztBQUNPLE1BQU1DLFlBQVksR0FBRyxTQUFyQixDLENBRVA7OztBQUNPLE1BQU1DLGtCQUFrQixHQUFHLGVBQTNCLEMsQ0FFUDs7O0FBQ08sTUFBTUMsaUNBQWlDLEdBQzVDLG1DQURLLEMsQ0FHUDs7O0FBQ08sTUFBTUMsK0RBQStELEdBQUcsT0FBeEUsQyxDQUVQOzs7SUFDWUMsZTs7O1dBQUFBLGU7QUFBQUEsRUFBQUEsZSxDQUFBQSxlO0FBQUFBLEVBQUFBLGUsQ0FBQUEsZTtBQUFBQSxFQUFBQSxlLENBQUFBLGU7QUFBQUEsRUFBQUEsZSxDQUFBQSxlO0FBQUFBLEVBQUFBLGUsQ0FBQUEsZTtBQUFBQSxFQUFBQSxlLENBQUFBLGU7QUFBQUEsRUFBQUEsZSxDQUFBQSxlO0dBQUFBLGUsK0JBQUFBLGU7O0lBa0VBQyxrQjs7O1dBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0FBQUFBLEVBQUFBLGtCO0dBQUFBLGtCLGtDQUFBQSxrQjs7QUE2REwsTUFBTUMsMEJBRVosR0FBRztBQUNGLEdBQUNGLGVBQWUsQ0FBQzVELFlBQWpCLEdBQWdDO0FBQzlCK0QsSUFBQUEsS0FBSyxFQUFFLGNBRHVCO0FBRTlCQyxJQUFBQSxXQUFXLEVBQUUsbURBRmlCO0FBRzlCQyxJQUFBQSxXQUFXLEVBQUVMLGVBQWUsQ0FBQzVEO0FBSEMsR0FEOUI7QUFNRixHQUFDNEQsZUFBZSxDQUFDTSxPQUFqQixHQUEyQjtBQUN6QkgsSUFBQUEsS0FBSyxFQUFFLFNBRGtCO0FBRXpCQyxJQUFBQSxXQUFXLEVBQ1QscUhBSHVCO0FBSXpCQyxJQUFBQSxXQUFXLEVBQUVMLGVBQWUsQ0FBQ007QUFKSixHQU56QjtBQVlGLEdBQUNOLGVBQWUsQ0FBQ08sUUFBakIsR0FBNEI7QUFDMUJKLElBQUFBLEtBQUssRUFBRSxVQURtQjtBQUUxQkMsSUFBQUEsV0FBVyxFQUFFLDBEQUZhO0FBRzFCQyxJQUFBQSxXQUFXLEVBQUVMLGVBQWUsQ0FBQ087QUFISCxHQVoxQjtBQWlCRixHQUFDUCxlQUFlLENBQUNRLFVBQWpCLEdBQThCO0FBQzVCTCxJQUFBQSxLQUFLLEVBQUUsaUJBRHFCO0FBRTVCQyxJQUFBQSxXQUFXLEVBQ1QsZ0ZBSDBCO0FBSTVCQyxJQUFBQSxXQUFXLEVBQUVMLGVBQWUsQ0FBQ1E7QUFKRCxHQWpCNUI7QUF1QkYsR0FBQ1IsZUFBZSxDQUFDUyxVQUFqQixHQUE4QjtBQUM1Qk4sSUFBQUEsS0FBSyxFQUFFLGlCQURxQjtBQUU1QkMsSUFBQUEsV0FBVyxFQUNULHFGQUgwQjtBQUk1QkMsSUFBQUEsV0FBVyxFQUFFTCxlQUFlLENBQUNTO0FBSkQsR0F2QjVCO0FBNkJGLEdBQUNULGVBQWUsQ0FBQ1UsZUFBakIsR0FBbUM7QUFDakNQLElBQUFBLEtBQUssRUFBRSxpQkFEMEI7QUFFakNDLElBQUFBLFdBQVcsRUFDVCx5RkFIK0I7QUFJakNDLElBQUFBLFdBQVcsRUFBRUwsZUFBZSxDQUFDVTtBQUpJLEdBN0JqQztBQW1DRixHQUFDVixlQUFlLENBQUNXLGFBQWpCLEdBQWlDO0FBQy9CUixJQUFBQSxLQUFLLEVBQUUsaUJBRHdCO0FBRS9CQyxJQUFBQSxXQUFXLEVBQ1QseUdBSDZCO0FBSS9CUSxJQUFBQSxpQkFBaUIsRUFBRSxpREFKWTtBQUsvQlAsSUFBQUEsV0FBVyxFQUFFTCxlQUFlLENBQUNXO0FBTEU7QUFuQy9CLENBRkc7O0FBOENBLE1BQU1FLGVBQWtELEdBQUc7QUFDaEUsMEJBQXdCO0FBQ3RCVixJQUFBQSxLQUFLLEVBQUUsc0JBRGU7QUFFdEJDLElBQUFBLFdBQVcsRUFDVCw0SUFIb0I7QUFJdEJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUpKO0FBS3RCUyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDZSxJQUxIO0FBTXRCQyxJQUFBQSxZQUFZLEVBQUUvSSx5QkFOUTtBQU90QmdKLElBQUFBLHNCQUFzQixFQUFFLElBUEY7QUFRdEJDLElBQUFBLG9CQUFvQixFQUFFLElBUkE7QUFTdEJDLElBQUFBLDBCQUEwQixFQUFFLElBVE47QUFVdEI7QUFDQUMsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JDLE9BQWxCLENBQ1JELHFDQUFrQkUsZ0JBRFYsRUFFUkYscUNBQWtCRyxXQUZWLEVBR1JILHFDQUFrQkksa0JBQWxCLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLEVBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBSFEsRUFJUkoscUNBQWtCSyx1QkFBbEIsQ0FDRSxJQURGLEVBRUUsR0FGRixFQUdFLEdBSEYsRUFJRSxHQUpGLEVBS0UsR0FMRixFQU1FLEdBTkYsRUFPRSxHQVBGLEVBUUUsR0FSRixFQVNFLEdBVEYsRUFVRSxHQVZGLENBSlEsQ0FYWTtBQTRCdEJDLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUVULFFBQUFBLFFBQVEsRUFBRSxLQUFLQTtBQUFqQixPQUFkLENBQVA7QUFDRDtBQTlCcUIsR0FEd0M7QUFpQ2hFLGdCQUFjO0FBQ1psQixJQUFBQSxLQUFLLEVBQUUsZ0JBREs7QUFFWkMsSUFBQUEsV0FBVyxFQUFFLDhEQUZEO0FBR1pVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDNUQsWUFIZDtBQUlaMkUsSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BSmI7QUFLWmQsSUFBQUEsWUFBWSxFQUFFLElBTEY7QUFNWkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFOWjtBQU9aQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVBWO0FBUVphLElBQUFBLE9BQU8sRUFBRTtBQUNQRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkUsUUFBQUEsTUFBTSxFQUFFO0FBQ052RCxVQUFBQSxRQUFRLEVBQUU7QUFBRXdELFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FESjtBQUVOQyxVQUFBQSxPQUFPLEVBQUU7QUFBRUYsWUFBQUEsS0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQUFBLEtBQUssRUFBRTtBQUF4QjtBQUZIO0FBREY7QUFERCxLQVJHO0FBZ0JaRSxJQUFBQSxnQ0FBZ0MsRUFBRSxVQUNoQ0YsS0FEZ0MsRUFFdkI7QUFDVCxhQUFPRyxPQUFPLENBQUNILEtBQUQsQ0FBZDtBQUNELEtBcEJXO0FBcUJaZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBckJoQjtBQXNCWlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXhCVyxHQWpDa0Q7QUEyRGhFLG1CQUFpQjtBQUNmckMsSUFBQUEsS0FBSyxFQUFFLGNBRFE7QUFFZkMsSUFBQUEsV0FBVyxFQUNULHVFQUhhO0FBSWZVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDNUQsWUFKWDtBQUtmMkUsSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BTFY7QUFNZmQsSUFBQUEsWUFBWSxFQUFFLElBTkM7QUFPZkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFQVDtBQVFmQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJQO0FBU2ZhLElBQUFBLE9BQU8sRUFBRTtBQUNQRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkUsUUFBQUEsTUFBTSxFQUFFO0FBQ052RCxVQUFBQSxRQUFRLEVBQUU7QUFBRXdELFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FESjtBQUVOQyxVQUFBQSxPQUFPLEVBQUU7QUFBRUYsWUFBQUEsS0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQUFBLEtBQUssRUFBRTtBQUF4QjtBQUZIO0FBREY7QUFERCxLQVRNO0FBaUJmRSxJQUFBQSxnQ0FBZ0MsRUFBRSxVQUNoQ0YsS0FEZ0MsRUFFdkI7QUFDVCxhQUFPRyxPQUFPLENBQUNILEtBQUQsQ0FBZDtBQUNELEtBckJjO0FBc0JmZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBdEJiO0FBdUJmWCxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNXLE9BQVAsRUFBUDtBQUNEO0FBekJjLEdBM0QrQztBQXNGaEUsdUJBQXFCO0FBQ25CckMsSUFBQUEsS0FBSyxFQUFFLDJCQURZO0FBRW5CQyxJQUFBQSxXQUFXLEVBQ1QsNEVBSGlCO0FBSW5CVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQzVELFlBSlA7QUFLbkIyRSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFMTjtBQU1uQmQsSUFBQUEsWUFBWSxFQUFFLElBTks7QUFPbkJDLElBQUFBLHNCQUFzQixFQUFFLElBUEw7QUFRbkJDLElBQUFBLG9CQUFvQixFQUFFLElBUkg7QUFTbkJhLElBQUFBLE9BQU8sRUFBRTtBQUNQRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkUsUUFBQUEsTUFBTSxFQUFFO0FBQ052RCxVQUFBQSxRQUFRLEVBQUU7QUFBRXdELFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FESjtBQUVOQyxVQUFBQSxPQUFPLEVBQUU7QUFBRUYsWUFBQUEsS0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQUFBLEtBQUssRUFBRTtBQUF4QjtBQUZIO0FBREY7QUFERCxLQVRVO0FBaUJuQkUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXJCa0I7QUFzQm5CZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBdEJUO0FBdUJuQlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXpCa0IsR0F0RjJDO0FBaUhoRSx1QkFBcUI7QUFDbkJyQyxJQUFBQSxLQUFLLEVBQUUsb0JBRFk7QUFFbkJDLElBQUFBLFdBQVcsRUFDVCwwRUFIaUI7QUFJbkJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDNUQsWUFKUDtBQUtuQjJFLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUxOO0FBTW5CZCxJQUFBQSxZQUFZLEVBQUUsSUFOSztBQU9uQkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFQTDtBQVFuQkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSSDtBQVNuQmEsSUFBQUEsT0FBTyxFQUFFO0FBQ1BELE1BQUFBLE1BQU0sRUFBRTtBQUNORSxRQUFBQSxNQUFNLEVBQUU7QUFDTnZELFVBQUFBLFFBQVEsRUFBRTtBQUFFd0QsWUFBQUEsS0FBSyxFQUFFLE9BQVQ7QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQURKO0FBRU5DLFVBQUFBLE9BQU8sRUFBRTtBQUFFRixZQUFBQSxLQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCO0FBRkg7QUFERjtBQURELEtBVFU7QUFpQm5CRSxJQUFBQSxnQ0FBZ0MsRUFBRSxVQUNoQ0YsS0FEZ0MsRUFFdkI7QUFDVCxhQUFPRyxPQUFPLENBQUNILEtBQUQsQ0FBZDtBQUNELEtBckJrQjtBQXNCbkJkLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCaUIsU0F0QlQ7QUF1Qm5CWCxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNXLE9BQVAsRUFBUDtBQUNEO0FBekJrQixHQWpIMkM7QUE0SWhFLG9CQUFrQjtBQUNoQnJDLElBQUFBLEtBQUssRUFBRSxlQURTO0FBRWhCQyxJQUFBQSxXQUFXLEVBQ1Qsd0VBSGM7QUFJaEJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDNUQsWUFKVjtBQUtoQjJFLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUxUO0FBTWhCZCxJQUFBQSxZQUFZLEVBQUUsSUFORTtBQU9oQkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFQUjtBQVFoQkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSTjtBQVNoQmEsSUFBQUEsT0FBTyxFQUFFO0FBQ1BELE1BQUFBLE1BQU0sRUFBRTtBQUNORSxRQUFBQSxNQUFNLEVBQUU7QUFDTnZELFVBQUFBLFFBQVEsRUFBRTtBQUFFd0QsWUFBQUEsS0FBSyxFQUFFLE9BQVQ7QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQURKO0FBRU5DLFVBQUFBLE9BQU8sRUFBRTtBQUFFRixZQUFBQSxLQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCO0FBRkg7QUFERjtBQURELEtBVE87QUFpQmhCRSxJQUFBQSxnQ0FBZ0MsRUFBRSxVQUNoQ0YsS0FEZ0MsRUFFdkI7QUFDVCxhQUFPRyxPQUFPLENBQUNILEtBQUQsQ0FBZDtBQUNELEtBckJlO0FBc0JoQmQsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JpQixTQXRCWjtBQXVCaEJYLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ1csT0FBUCxFQUFQO0FBQ0Q7QUF6QmUsR0E1SThDO0FBdUtoRSxrQkFBZ0I7QUFDZHJDLElBQUFBLEtBQUssRUFBRSxhQURPO0FBRWRDLElBQUFBLFdBQVcsRUFDVCxnRUFIWTtBQUlkVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQzVELFlBSlo7QUFLZDJFLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUxYO0FBTWRkLElBQUFBLFlBQVksRUFBRSxJQU5BO0FBT2RDLElBQUFBLHNCQUFzQixFQUFFLElBUFY7QUFRZEMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSUjtBQVNkYSxJQUFBQSxPQUFPLEVBQUU7QUFDUEQsTUFBQUEsTUFBTSxFQUFFO0FBQ05FLFFBQUFBLE1BQU0sRUFBRTtBQUNOdkQsVUFBQUEsUUFBUSxFQUFFO0FBQUV3RCxZQUFBQSxLQUFLLEVBQUUsT0FBVDtBQUFrQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXpCLFdBREo7QUFFTkMsVUFBQUEsT0FBTyxFQUFFO0FBQUVGLFlBQUFBLEtBQUssRUFBRSxNQUFUO0FBQWlCQyxZQUFBQSxLQUFLLEVBQUU7QUFBeEI7QUFGSDtBQURGO0FBREQsS0FUSztBQWlCZEUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXJCYTtBQXNCZGQsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JpQixTQXRCZDtBQXVCZFgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXpCYSxHQXZLZ0Q7QUFrTWhFLHFCQUFtQjtBQUNqQnJDLElBQUFBLEtBQUssRUFBRSxnQkFEVTtBQUVqQkMsSUFBQUEsV0FBVyxFQUNULG1FQUhlO0FBSWpCVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQzVELFlBSlQ7QUFLakIyRSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFMUjtBQU1qQmQsSUFBQUEsWUFBWSxFQUFFLElBTkc7QUFPakJDLElBQUFBLHNCQUFzQixFQUFFLElBUFA7QUFRakJDLElBQUFBLG9CQUFvQixFQUFFLElBUkw7QUFTakJhLElBQUFBLE9BQU8sRUFBRTtBQUNQRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkUsUUFBQUEsTUFBTSxFQUFFO0FBQ052RCxVQUFBQSxRQUFRLEVBQUU7QUFBRXdELFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FESjtBQUVOQyxVQUFBQSxPQUFPLEVBQUU7QUFBRUYsWUFBQUEsS0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQUFBLEtBQUssRUFBRTtBQUF4QjtBQUZIO0FBREY7QUFERCxLQVRRO0FBaUJqQkUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXJCZ0I7QUFzQmpCZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBdEJYO0FBdUJqQlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXpCZ0IsR0FsTTZDO0FBNk5oRSx1QkFBcUI7QUFDbkJyQyxJQUFBQSxLQUFLLEVBQUUsd0JBRFk7QUFFbkJDLElBQUFBLFdBQVcsRUFDVCwyRUFIaUI7QUFJbkJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDNUQsWUFKUDtBQUtuQjJFLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUxOO0FBTW5CZCxJQUFBQSxZQUFZLEVBQUUsSUFOSztBQU9uQkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFQTDtBQVFuQkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSSDtBQVNuQmEsSUFBQUEsT0FBTyxFQUFFO0FBQ1BELE1BQUFBLE1BQU0sRUFBRTtBQUNORSxRQUFBQSxNQUFNLEVBQUU7QUFDTnZELFVBQUFBLFFBQVEsRUFBRTtBQUFFd0QsWUFBQUEsS0FBSyxFQUFFLE9BQVQ7QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQURKO0FBRU5DLFVBQUFBLE9BQU8sRUFBRTtBQUFFRixZQUFBQSxLQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCO0FBRkg7QUFERjtBQURELEtBVFU7QUFpQm5CRSxJQUFBQSxnQ0FBZ0MsRUFBRSxVQUNoQ0YsS0FEZ0MsRUFFdkI7QUFDVCxhQUFPRyxPQUFPLENBQUNILEtBQUQsQ0FBZDtBQUNELEtBckJrQjtBQXNCbkJkLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCaUIsU0F0QlQ7QUF1Qm5CWCxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNXLE9BQVAsRUFBUDtBQUNEO0FBekJrQixHQTdOMkM7QUF3UGhFLGlCQUFlO0FBQ2JyQyxJQUFBQSxLQUFLLEVBQUUsYUFETTtBQUViQyxJQUFBQSxXQUFXLEVBQUUsNkNBRkE7QUFHYlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNNLE9BSGI7QUFJYlMsSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2UsSUFKWjtBQUtiQyxJQUFBQSxZQUFZLEVBQUU5SiwrQkFMRDtBQU1iK0osSUFBQUEsc0JBQXNCLEVBQUUsSUFOWDtBQU9iQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVBUO0FBUWI7QUFDQUUsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JDLE9BQWxCLENBQ1JELHFDQUFrQkUsZ0JBRFYsRUFFUkYscUNBQWtCRyxXQUZWLEVBR1JILHFDQUFrQkksa0JBQWxCLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLEVBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBSFEsRUFJUkoscUNBQWtCSyx1QkFBbEIsQ0FDRSxJQURGLEVBRUUsR0FGRixFQUdFLEdBSEYsRUFJRSxHQUpGLEVBS0UsR0FMRixFQU1FLEdBTkYsRUFPRSxHQVBGLEVBUUUsR0FSRixFQVNFLEdBVEYsRUFVRSxHQVZGLENBSlEsQ0FURztBQTBCYkMsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBRVQsUUFBQUEsUUFBUSxFQUFFLEtBQUtBO0FBQWpCLE9BQWQsQ0FBUDtBQUNEO0FBNUJZLEdBeFBpRDtBQXNSaEUsMEJBQXdCO0FBQ3RCbEIsSUFBQUEsS0FBSyxFQUFFLGVBRGU7QUFFdEJDLElBQUFBLFdBQVcsRUFDVCx1R0FIb0I7QUFJdEJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDUyxVQUpKO0FBS3RCTSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDd0MsTUFMSDtBQU10QnhCLElBQUFBLFlBQVksRUFBRSxFQU5RO0FBT3RCQyxJQUFBQSxzQkFBc0IsRUFBRSxJQVBGO0FBUXRCQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJBO0FBU3RCYSxJQUFBQSxPQUFPLEVBQUU7QUFDUFMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFFBQVEsRUFBRTtBQURKO0FBREQsS0FUYTtBQWN0QkMsSUFBQUEsNkNBQTZDLEVBQUUsVUFBVVIsS0FBVixFQUEyQjtBQUN4RSxhQUFPUyxJQUFJLENBQUNDLFNBQUwsQ0FBZVYsS0FBZixDQUFQO0FBQ0QsS0FoQnFCO0FBaUJ0QlcsSUFBQUEsNkNBQTZDLEVBQUUsVUFDN0NYLEtBRDZDLEVBRXhDO0FBQ0wsVUFBSTtBQUNGLGVBQU9TLElBQUksQ0FBQ0csS0FBTCxDQUFXWixLQUFYLENBQVA7QUFDRCxPQUZELENBRUUsT0FBT2EsS0FBUCxFQUFjO0FBQ2QsZUFBT2IsS0FBUDtBQUNEO0FBQ0YsS0F6QnFCO0FBMEJ0QmQsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0IyQixJQUFsQixDQUNSM0IscUNBQWtCQyxPQUFsQixDQUNFRCxxQ0FBa0I0QixLQUFsQixDQUNFNUIscUNBQWtCQyxPQUFsQixDQUNFRCxxQ0FBa0I2QixRQURwQixFQUVFN0IscUNBQWtCRSxnQkFGcEIsRUFHRUYscUNBQWtCRyxXQUhwQixDQURGLENBREYsQ0FEUSxDQTFCWTtBQXFDdEJHLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ3VCLE9BQVAsQ0FDTHZCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQ1pULFFBQUFBLFFBQVEsRUFBRUMscUNBQWtCQyxPQUFsQixDQUNSRCxxQ0FBa0JFLGdCQURWLEVBRVJGLHFDQUFrQkcsV0FGVjtBQURFLE9BQWQsQ0FESyxDQUFQO0FBUUQ7QUE5Q3FCLEdBdFJ3QztBQXNVaEUsb0NBQWtDO0FBQ2hDdEIsSUFBQUEsS0FBSyxFQUFFLGdCQUR5QjtBQUVoQ0MsSUFBQUEsV0FBVyxFQUFFLDJEQUZtQjtBQUdoQ1UsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNTLFVBSE07QUFJaENNLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUNvRCxNQUpPO0FBS2hDckIsSUFBQUEsT0FBTyxFQUFFO0FBQ1BxQixNQUFBQSxNQUFNLEVBQUUsQ0FDTjtBQUNFckMsUUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BRE0sRUFLTjtBQUNFbkIsUUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BTE0sRUFTTjtBQUNFbkIsUUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BVE0sRUFhTjtBQUNFbkIsUUFBQUEsSUFBSSxFQUFFLFNBRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BYk07QUFERCxLQUx1QjtBQXlCaENsQixJQUFBQSxZQUFZLEVBQUV4SixpQ0F6QmtCO0FBMEJoQ3lKLElBQUFBLHNCQUFzQixFQUFFLElBMUJRO0FBMkJoQ0MsSUFBQUEsb0JBQW9CLEVBQUUsSUEzQlU7QUE0QmhDQyxJQUFBQSwwQkFBMEIsRUFBRSxJQTVCSTtBQTZCaENDLElBQUFBLFFBQVEsRUFBRSxVQUFVYyxLQUFWLEVBQWlCO0FBQ3pCLGFBQU9iLHFDQUFrQmdDLE9BQWxCLENBQ0wsS0FBS3RCLE9BQUwsQ0FBYXFCLE1BQWIsQ0FBb0JFLEdBQXBCLENBQXdCLENBQUM7QUFBRXBCLFFBQUFBO0FBQUYsT0FBRCxLQUFlQSxLQUF2QyxDQURLLEVBRUxBLEtBRkssQ0FBUDtBQUdELEtBakMrQjtBQWtDaENQLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQzJCLEtBQVAsQ0FDTCxLQUFLeEIsT0FBTCxDQUFhcUIsTUFBYixDQUFvQkUsR0FBcEIsQ0FBd0IsQ0FBQztBQUFFcEIsUUFBQUE7QUFBRixPQUFELEtBQWVOLE1BQU0sQ0FBQ3lCLE9BQVAsQ0FBZW5CLEtBQWYsQ0FBdkMsQ0FESyxDQUFQO0FBR0Q7QUF0QytCLEdBdFU4QjtBQThXaEUsZ0NBQThCO0FBQzVCaEMsSUFBQUEsS0FBSyxFQUFFLFlBRHFCO0FBRTVCQyxJQUFBQSxXQUFXLEVBQ1Qsb0VBSDBCO0FBSTVCVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1MsVUFKRTtBQUs1Qk0sSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2UsSUFMRztBQU01QkMsSUFBQUEsWUFBWSxFQUFFN0osNkJBTmM7QUFPNUI4SixJQUFBQSxzQkFBc0IsRUFBRSxJQVBJO0FBUTVCQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJNO0FBUzVCQyxJQUFBQSwwQkFBMEIsRUFBRSxJQVRBO0FBVTVCO0FBQ0FDLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCQyxPQUFsQixDQUNSRCxxQ0FBa0JFLGdCQURWLEVBRVJGLHFDQUFrQkcsV0FGVixFQUdSSCxxQ0FBa0JJLGtCQUFsQixDQUFxQyxHQUFyQyxFQUEwQyxHQUExQyxFQUErQyxHQUEvQyxFQUFvRCxHQUFwRCxDQUhRLEVBSVJKLHFDQUFrQkssdUJBQWxCLENBQ0UsSUFERixFQUVFLEdBRkYsRUFHRSxHQUhGLEVBSUUsR0FKRixFQUtFLEdBTEYsRUFNRSxHQU5GLEVBT0UsR0FQRixFQVFFLEdBUkYsRUFTRSxHQVRGLEVBVUUsR0FWRixDQUpRLENBWGtCO0FBNEI1QkMsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBRVQsUUFBQUEsUUFBUSxFQUFFLEtBQUtBO0FBQWpCLE9BQWQsQ0FBUDtBQUNEO0FBOUIyQixHQTlXa0M7QUE4WWhFLG9DQUFrQztBQUNoQ2xCLElBQUFBLEtBQUssRUFBRSxnQkFEeUI7QUFFaENDLElBQUFBLFdBQVcsRUFDVCxrRUFIOEI7QUFJaENVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDUyxVQUpNO0FBS2hDTSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDd0QsTUFMTztBQU1oQ3hDLElBQUFBLFlBQVksRUFBRXpKLHlDQU5rQjtBQU9oQzBKLElBQUFBLHNCQUFzQixFQUFFLElBUFE7QUFRaENDLElBQUFBLG9CQUFvQixFQUFFLElBUlU7QUFTaENDLElBQUFBLDBCQUEwQixFQUFFLElBVEk7QUFVaENZLElBQUFBLE9BQU8sRUFBRTtBQUNQeUIsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLEdBQUcsRUFBRSxDQURDO0FBRU5DLFFBQUFBLE9BQU8sRUFBRTtBQUZIO0FBREQsS0FWdUI7QUFnQmhDaEIsSUFBQUEsNkNBQTZDLEVBQUUsVUFDN0NSLEtBRDZDLEVBRXJDO0FBQ1IsYUFBT3lCLE1BQU0sQ0FBQ3pCLEtBQUQsQ0FBYjtBQUNELEtBcEIrQjtBQXFCaENXLElBQUFBLDZDQUE2QyxFQUFFLFVBQzdDWCxLQUQ2QyxFQUVyQztBQUNSLGFBQU8wQixNQUFNLENBQUMxQixLQUFELENBQWI7QUFDRCxLQXpCK0I7QUEwQmhDZCxJQUFBQSxRQUFRLEVBQUUsVUFBVWMsS0FBVixFQUFpQjtBQUN6QixhQUFPYixxQ0FBa0JtQyxNQUFsQixDQUF5QixLQUFLekIsT0FBTCxDQUFheUIsTUFBdEMsRUFBOEN0QixLQUE5QyxDQUFQO0FBQ0QsS0E1QitCO0FBNkJoQ1AsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDNEIsTUFBUCxDQUFjO0FBQUVwQyxRQUFBQSxRQUFRLEVBQUUsS0FBS0EsUUFBTCxDQUFjeUMsSUFBZCxDQUFtQixJQUFuQjtBQUFaLE9BQWQsQ0FBUDtBQUNEO0FBL0IrQixHQTlZOEI7QUErYWhFLGtDQUFnQztBQUM5QjNELElBQUFBLEtBQUssRUFBRSxjQUR1QjtBQUU5QkMsSUFBQUEsV0FBVyxFQUNULGdFQUg0QjtBQUk5QlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNTLFVBSkk7QUFLOUJNLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUN3RCxNQUxLO0FBTTlCeEMsSUFBQUEsWUFBWSxFQUFFMUosdUNBTmdCO0FBTzlCMkosSUFBQUEsc0JBQXNCLEVBQUUsSUFQTTtBQVE5QkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSUTtBQVM5QkMsSUFBQUEsMEJBQTBCLEVBQUUsSUFURTtBQVU5QlksSUFBQUEsT0FBTyxFQUFFO0FBQ1B5QixNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsR0FBRyxFQUFFLENBREM7QUFFTkMsUUFBQUEsT0FBTyxFQUFFO0FBRkg7QUFERCxLQVZxQjtBQWdCOUJoQixJQUFBQSw2Q0FBNkMsRUFBRSxVQUFVUixLQUFWLEVBQXlCO0FBQ3RFLGFBQU95QixNQUFNLENBQUN6QixLQUFELENBQWI7QUFDRCxLQWxCNkI7QUFtQjlCVyxJQUFBQSw2Q0FBNkMsRUFBRSxVQUM3Q1gsS0FENkMsRUFFckM7QUFDUixhQUFPMEIsTUFBTSxDQUFDMUIsS0FBRCxDQUFiO0FBQ0QsS0F2QjZCO0FBd0I5QmQsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBaUI7QUFDekIsYUFBT2IscUNBQWtCbUMsTUFBbEIsQ0FBeUIsS0FBS3pCLE9BQUwsQ0FBYXlCLE1BQXRDLEVBQThDdEIsS0FBOUMsQ0FBUDtBQUNELEtBMUI2QjtBQTJCOUJQLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQzRCLE1BQVAsQ0FBYztBQUFFcEMsUUFBQUEsUUFBUSxFQUFFLEtBQUtBLFFBQUwsQ0FBY3lDLElBQWQsQ0FBbUIsSUFBbkI7QUFBWixPQUFkLENBQVA7QUFDRDtBQTdCNkIsR0EvYWdDO0FBOGNoRSw4QkFBNEI7QUFDMUIzRCxJQUFBQSxLQUFLLEVBQUUsVUFEbUI7QUFFMUJDLElBQUFBLFdBQVcsRUFDVCx5RUFId0I7QUFJMUJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDUyxVQUpBO0FBSzFCTSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDZSxJQUxDO0FBTTFCQyxJQUFBQSxZQUFZLEVBQUVySixrQ0FOWTtBQU8xQnNKLElBQUFBLHNCQUFzQixFQUFFLElBUEU7QUFRMUJDLElBQUFBLG9CQUFvQixFQUFFLElBUkk7QUFTMUI0QyxJQUFBQSxnQ0FBZ0MsRUFBRSxJQVRSO0FBVTFCMUMsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBeUI7QUFDakMsYUFBTyx3QkFBeUJBLEtBQXpCLElBQ0g2QixTQURHLEdBRUgsd0JBRko7QUFHRCxLQWR5QjtBQWUxQnBDLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUVULFFBQUFBLFFBQVEsRUFBRSxLQUFLQTtBQUFqQixPQUFkLENBQVA7QUFDRDtBQWpCeUIsR0E5Y29DO0FBaWVoRSw0QkFBMEI7QUFDeEJsQixJQUFBQSxLQUFLLEVBQUUsUUFEaUI7QUFFeEJDLElBQUFBLFdBQVcsRUFBRSx5Q0FGVztBQUd4QlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNTLFVBSEY7QUFJeEJNLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUpEO0FBS3hCZCxJQUFBQSxZQUFZLEVBQUV2SiwrQkFMVTtBQU14QndKLElBQUFBLHNCQUFzQixFQUFFLElBTkE7QUFPeEJDLElBQUFBLG9CQUFvQixFQUFFLElBUEU7QUFReEJhLElBQUFBLE9BQU8sRUFBRTtBQUNQRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkUsUUFBQUEsTUFBTSxFQUFFO0FBQ052RCxVQUFBQSxRQUFRLEVBQUU7QUFBRXdELFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FESjtBQUVOQyxVQUFBQSxPQUFPLEVBQUU7QUFBRUYsWUFBQUEsS0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQUFBLEtBQUssRUFBRTtBQUF4QjtBQUZIO0FBREY7QUFERCxLQVJlO0FBZ0J4QkUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXBCdUI7QUFxQnhCZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBckJKO0FBc0J4QlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXhCdUIsR0FqZXNDO0FBMmZoRSwyQkFBeUI7QUFDdkJyQyxJQUFBQSxLQUFLLEVBQUUsUUFEZ0I7QUFFdkJDLElBQUFBLFdBQVcsRUFBRSxzQ0FGVTtBQUd2QlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNXLGFBSEg7QUFJdkJJLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUpGO0FBS3ZCZCxJQUFBQSxZQUFZLEVBQUUsSUFMUztBQU12QkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFORDtBQU92QkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFQQztBQVF2QjhDLElBQUFBLDJCQUEyQixFQUFFLElBUk47QUFTdkJqQyxJQUFBQSxPQUFPLEVBQUU7QUFDUEQsTUFBQUEsTUFBTSxFQUFFO0FBQ05FLFFBQUFBLE1BQU0sRUFBRTtBQUNOdkQsVUFBQUEsUUFBUSxFQUFFO0FBQUV3RCxZQUFBQSxLQUFLLEVBQUUsT0FBVDtBQUFrQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXpCLFdBREo7QUFFTkMsVUFBQUEsT0FBTyxFQUFFO0FBQUVGLFlBQUFBLEtBQUssRUFBRSxNQUFUO0FBQWlCQyxZQUFBQSxLQUFLLEVBQUU7QUFBeEI7QUFGSDtBQURGO0FBREQsS0FUYztBQWlCdkJFLElBQUFBLGdDQUFnQyxFQUFFLFVBQ2hDRixLQURnQyxFQUV2QjtBQUNULGFBQU9HLE9BQU8sQ0FBQ0gsS0FBRCxDQUFkO0FBQ0QsS0FyQnNCO0FBc0J2QmQsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JpQixTQXRCTDtBQXVCdkJYLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ1csT0FBUCxFQUFQO0FBQ0Q7QUF6QnNCLEdBM2Z1QztBQXNoQmhFLDRCQUEwQjtBQUN4QnJDLElBQUFBLEtBQUssRUFBRSxlQURpQjtBQUV4QkMsSUFBQUEsV0FBVyxFQUFHLGtGQUZVO0FBR3hCVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1csYUFIRjtBQUl4QkksSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2lFLFVBSkQ7QUFLeEJqRCxJQUFBQSxZQUFZLEVBQUUsRUFMVTtBQU14QkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFOQTtBQU94QkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFQRTtBQVF4QmEsSUFBQUEsT0FBTyxFQUFFO0FBQ1BtQyxNQUFBQSxJQUFJLEVBQUU7QUFDSnBELFFBQUFBLElBQUksRUFBRSxPQURGO0FBRUpxRCxRQUFBQSxVQUFVLEVBQUUsQ0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixNQUFsQixFQUEwQixNQUExQixDQUZSO0FBR0pDLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxRQUFRLEVBQ052RTtBQUZFLFNBSEY7QUFPSndFLFFBQUFBLFdBQVcsRUFBRTtBQUNYQyxVQUFBQSxVQUFVLEVBQUU7QUFDVkMsWUFBQUEsS0FBSyxFQUFFLEdBREc7QUFFVkMsWUFBQUEsTUFBTSxFQUFFLEVBRkU7QUFHVkMsWUFBQUEsSUFBSSxFQUFFO0FBSEk7QUFERCxTQVBUO0FBY0pDLFFBQUFBLEtBQUssRUFBRTtBQUNMQyxVQUFBQSxzQkFBc0IsRUFBRSw2QkFEbkI7QUFFTEMsVUFBQUEsUUFBUSxFQUFFLHdCQUZMO0FBR0xDLFVBQUFBLGdCQUFnQixFQUFHRCxRQUFELElBQ2YsaUJBQWdCQSxRQUFTLE1BQUtFLElBQUksQ0FBQ0MsR0FBTCxFQUFXLEVBSnZDLENBS0w7O0FBTEs7QUFkSDtBQURDLEtBUmU7QUFnQ3hCNUQsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBaUI7QUFDekIsYUFBT2IscUNBQWtCQyxPQUFsQixDQUNMRCxxQ0FBa0I0RCxrQkFBbEIsQ0FBcUMsRUFDbkMsR0FBRyxLQUFLbEQsT0FBTCxDQUFhbUMsSUFBYixDQUFrQkUsSUFEYztBQUVuQ2MsUUFBQUEsY0FBYyxFQUFFO0FBRm1CLE9BQXJDLENBREssRUFLTDdELHFDQUFrQjhELDZCQUFsQixDQUNFLEtBQUtwRCxPQUFMLENBQWFtQyxJQUFiLENBQWtCQyxVQURwQixDQUxLLEVBUUxqQyxLQVJLLENBQVA7QUFTRDtBQTFDdUIsR0F0aEJzQztBQWtrQmhFLG9DQUFrQztBQUNoQ2hDLElBQUFBLEtBQUssRUFBRSxrQkFEeUI7QUFFaENDLElBQUFBLFdBQVcsRUFBRyxtRUFGa0I7QUFHaENVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDVyxhQUhNO0FBSWhDSSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDaUUsVUFKTztBQUtoQ2pELElBQUFBLFlBQVksRUFBRSxFQUxrQjtBQU1oQ0MsSUFBQUEsc0JBQXNCLEVBQUUsSUFOUTtBQU9oQ0MsSUFBQUEsb0JBQW9CLEVBQUUsSUFQVTtBQVFoQ2EsSUFBQUEsT0FBTyxFQUFFO0FBQ1BtQyxNQUFBQSxJQUFJLEVBQUU7QUFDSnBELFFBQUFBLElBQUksRUFBRSxPQURGO0FBRUpxRCxRQUFBQSxVQUFVLEVBQUUsQ0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixNQUFsQixFQUEwQixNQUExQixDQUZSO0FBR0pDLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxRQUFRLEVBQ052RTtBQUZFLFNBSEY7QUFPSndFLFFBQUFBLFdBQVcsRUFBRTtBQUNYQyxVQUFBQSxVQUFVLEVBQUU7QUFDVkMsWUFBQUEsS0FBSyxFQUFFLEdBREc7QUFFVkMsWUFBQUEsTUFBTSxFQUFFLEVBRkU7QUFHVkMsWUFBQUEsSUFBSSxFQUFFO0FBSEk7QUFERCxTQVBUO0FBY0pDLFFBQUFBLEtBQUssRUFBRTtBQUNMQyxVQUFBQSxzQkFBc0IsRUFBRSw2QkFEbkI7QUFFTEMsVUFBQUEsUUFBUSxFQUFFLGdDQUZMO0FBR0xDLFVBQUFBLGdCQUFnQixFQUFHRCxRQUFELElBQ2YsaUJBQWdCQSxRQUFTLE1BQUtFLElBQUksQ0FBQ0MsR0FBTCxFQUFXLEVBSnZDLENBS0w7O0FBTEs7QUFkSDtBQURDLEtBUnVCO0FBZ0NoQzVELElBQUFBLFFBQVEsRUFBRSxVQUFVYyxLQUFWLEVBQWlCO0FBQ3pCLGFBQU9iLHFDQUFrQkMsT0FBbEIsQ0FDTEQscUNBQWtCNEQsa0JBQWxCLENBQXFDLEVBQ25DLEdBQUcsS0FBS2xELE9BQUwsQ0FBYW1DLElBQWIsQ0FBa0JFLElBRGM7QUFFbkNjLFFBQUFBLGNBQWMsRUFBRTtBQUZtQixPQUFyQyxDQURLLEVBS0w3RCxxQ0FBa0I4RCw2QkFBbEIsQ0FDRSxLQUFLcEQsT0FBTCxDQUFhbUMsSUFBYixDQUFrQkMsVUFEcEIsQ0FMSyxFQVFMakMsS0FSSyxDQUFQO0FBU0Q7QUExQytCLEdBbGtCOEI7QUE4bUJoRSxnQ0FBOEI7QUFDNUJoQyxJQUFBQSxLQUFLLEVBQUUsa0JBRHFCO0FBRTVCQyxJQUFBQSxXQUFXLEVBQUcseUhBRmM7QUFHNUJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDVyxhQUhFO0FBSTVCSSxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDaUUsVUFKRztBQUs1QmpELElBQUFBLFlBQVksRUFBRSxFQUxjO0FBTTVCb0UsSUFBQUEsb0JBQW9CLEVBQUU5SCx1Q0FOTTtBQU81QjJELElBQUFBLHNCQUFzQixFQUFFLElBUEk7QUFRNUJDLElBQUFBLG9CQUFvQixFQUFFLElBUk07QUFTNUJhLElBQUFBLE9BQU8sRUFBRTtBQUNQbUMsTUFBQUEsSUFBSSxFQUFFO0FBQ0pwRCxRQUFBQSxJQUFJLEVBQUUsT0FERjtBQUVKcUQsUUFBQUEsVUFBVSxFQUFFLENBQUMsT0FBRCxFQUFVLE1BQVYsRUFBa0IsTUFBbEIsQ0FGUjtBQUdKQyxRQUFBQSxJQUFJLEVBQUU7QUFDSkMsVUFBQUEsUUFBUSxFQUNOdkU7QUFGRSxTQUhGO0FBT0p3RSxRQUFBQSxXQUFXLEVBQUU7QUFDWEMsVUFBQUEsVUFBVSxFQUFFO0FBQ1ZDLFlBQUFBLEtBQUssRUFBRSxHQURHO0FBRVZDLFlBQUFBLE1BQU0sRUFBRSxFQUZFO0FBR1ZDLFlBQUFBLElBQUksRUFBRTtBQUhJO0FBREQsU0FQVDtBQWNKQyxRQUFBQSxLQUFLLEVBQUU7QUFDTEMsVUFBQUEsc0JBQXNCLEVBQUUsNkJBRG5CO0FBRUxDLFVBQUFBLFFBQVEsRUFBRSw0QkFGTDtBQUdMQyxVQUFBQSxnQkFBZ0IsRUFBR0QsUUFBRCxJQUF1QixpQkFBZ0JBLFFBQVM7QUFIN0Q7QUFkSDtBQURDLEtBVG1CO0FBK0I1QnpELElBQUFBLFFBQVEsRUFBRSxVQUFVYyxLQUFWLEVBQWlCO0FBQ3pCLGFBQU9iLHFDQUFrQkMsT0FBbEIsQ0FDTEQscUNBQWtCNEQsa0JBQWxCLENBQXFDLEVBQ25DLEdBQUcsS0FBS2xELE9BQUwsQ0FBYW1DLElBQWIsQ0FBa0JFLElBRGM7QUFFbkNjLFFBQUFBLGNBQWMsRUFBRTtBQUZtQixPQUFyQyxDQURLLEVBS0w3RCxxQ0FBa0I4RCw2QkFBbEIsQ0FDRSxLQUFLcEQsT0FBTCxDQUFhbUMsSUFBYixDQUFrQkMsVUFEcEIsQ0FMSyxFQVFMakMsS0FSSyxDQUFQO0FBU0Q7QUF6QzJCLEdBOW1Ca0M7QUF5cEJoRSxrQ0FBZ0M7QUFDOUJoQyxJQUFBQSxLQUFLLEVBQUUsZ0JBRHVCO0FBRTlCQyxJQUFBQSxXQUFXLEVBQUUsZ0NBRmlCO0FBRzlCVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1csYUFISTtBQUk5QkksSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ3FGLFFBSks7QUFLOUJyRSxJQUFBQSxZQUFZLEVBQUUsRUFMZ0I7QUFNOUJvRSxJQUFBQSxvQkFBb0IsRUFBRTVILHdCQU5RO0FBTzlCeUQsSUFBQUEsc0JBQXNCLEVBQUUsSUFQTTtBQVE5QkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSUTtBQVM5QmEsSUFBQUEsT0FBTyxFQUFFO0FBQUV1RCxNQUFBQSxPQUFPLEVBQUUsQ0FBWDtBQUFjQyxNQUFBQSxTQUFTLEVBQUU7QUFBekIsS0FUcUI7QUFVOUJuRSxJQUFBQSxRQUFRLEVBQUUsVUFBVWMsS0FBVixFQUFpQjtBQUFBOztBQUN6QixhQUFPYixxQ0FBa0JtRSxtQkFBbEIsQ0FBc0M7QUFDM0NGLFFBQUFBLE9BQU8sbUJBQUUsS0FBS3ZELE9BQVAsa0RBQUUsY0FBY3VELE9BRG9CO0FBRTNDQyxRQUFBQSxTQUFTLG9CQUFFLEtBQUt4RCxPQUFQLG1EQUFFLGVBQWN3RDtBQUZrQixPQUF0QyxFQUdKckQsS0FISSxDQUFQO0FBSUQsS0FmNkI7QUFnQjlCUCxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFFVCxRQUFBQSxRQUFRLEVBQUUsS0FBS0EsUUFBTCxDQUFjeUMsSUFBZCxDQUFtQixJQUFuQjtBQUFaLE9BQWQsQ0FBUDtBQUNEO0FBbEI2QixHQXpwQmdDO0FBNnFCaEUsa0NBQWdDO0FBQzlCM0QsSUFBQUEsS0FBSyxFQUFFLGdCQUR1QjtBQUU5QkMsSUFBQUEsV0FBVyxFQUFFLGdDQUZpQjtBQUc5QlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNXLGFBSEk7QUFJOUJJLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUNxRixRQUpLO0FBSzlCckUsSUFBQUEsWUFBWSxFQUFFLEVBTGdCO0FBTTlCb0UsSUFBQUEsb0JBQW9CLEVBQUUzSCx3QkFOUTtBQU85QndELElBQUFBLHNCQUFzQixFQUFFLElBUE07QUFROUJDLElBQUFBLG9CQUFvQixFQUFFLElBUlE7QUFTOUJhLElBQUFBLE9BQU8sRUFBRTtBQUFFdUQsTUFBQUEsT0FBTyxFQUFFLENBQVg7QUFBY0MsTUFBQUEsU0FBUyxFQUFFO0FBQXpCLEtBVHFCO0FBVTlCbkUsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBaUI7QUFBQTs7QUFDekIsYUFBT2IscUNBQWtCbUUsbUJBQWxCLENBQXNDO0FBQzNDRixRQUFBQSxPQUFPLG9CQUFFLEtBQUt2RCxPQUFQLG1EQUFFLGVBQWN1RCxPQURvQjtBQUUzQ0MsUUFBQUEsU0FBUyxvQkFBRSxLQUFLeEQsT0FBUCxtREFBRSxlQUFjd0Q7QUFGa0IsT0FBdEMsRUFHSnJELEtBSEksQ0FBUDtBQUlELEtBZjZCO0FBZ0I5QlAsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBRVQsUUFBQUEsUUFBUSxFQUFFLEtBQUtBLFFBQUwsQ0FBY3lDLElBQWQsQ0FBbUIsSUFBbkI7QUFBWixPQUFkLENBQVA7QUFDRDtBQWxCNkIsR0E3cUJnQztBQWlzQmhFLG9CQUFrQjtBQUNoQjNELElBQUFBLEtBQUssRUFBRSxnQkFEUztBQUVoQkMsSUFBQUEsV0FBVyxFQUNULHlFQUhjO0FBSWhCVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ00sT0FKVjtBQUtoQlMsSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2UsSUFMVDtBQU1oQkMsSUFBQUEsWUFBWSxFQUFFLEVBTkU7QUFPaEJDLElBQUFBLHNCQUFzQixFQUFFLElBUFI7QUFRaEJDLElBQUFBLG9CQUFvQixFQUFFLElBUk47QUFTaEJFLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCRyxXQVRaO0FBVWhCRyxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFFVCxRQUFBQSxRQUFRLEVBQUUsS0FBS0E7QUFBakIsT0FBZCxDQUFQO0FBQ0Q7QUFaZSxHQWpzQjhDO0FBK3NCaEUseUJBQXVCO0FBQ3JCbEIsSUFBQUEsS0FBSyxFQUFFLHFCQURjO0FBRXJCQyxJQUFBQSxXQUFXLEVBQ1QsMEVBSG1CO0FBSXJCVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ00sT0FKTDtBQUtyQlMsSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2UsSUFMSjtBQU1yQkMsSUFBQUEsWUFBWSxFQUFFLEVBTk87QUFPckJDLElBQUFBLHNCQUFzQixFQUFFLElBUEg7QUFRckJDLElBQUFBLG9CQUFvQixFQUFFLEtBUkQ7QUFTckJFLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCRSxnQkFUUDtBQVVyQkksSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBRVQsUUFBQUEsUUFBUSxFQUFFLEtBQUtBO0FBQWpCLE9BQWQsQ0FBUDtBQUNEO0FBWm9CLEdBL3NCeUM7QUE2dEJoRXFFLEVBQUFBLGlCQUFpQixFQUFFO0FBQ2pCdkYsSUFBQUEsS0FBSyxFQUFFLHFCQURVO0FBRWpCQyxJQUFBQSxXQUFXLEVBQUUsb0RBRkk7QUFHakJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUhUO0FBSWpCUyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFKUjtBQUtqQmQsSUFBQUEsWUFBWSxFQUFFLEtBTEc7QUFNakJDLElBQUFBLHNCQUFzQixFQUFFLElBTlA7QUFPakJDLElBQUFBLG9CQUFvQixFQUFFLElBUEw7QUFRakI4QyxJQUFBQSwyQkFBMkIsRUFBRSxJQVJaO0FBU2pCakMsSUFBQUEsT0FBTyxFQUFFO0FBQ1BELE1BQUFBLE1BQU0sRUFBRTtBQUNORSxRQUFBQSxNQUFNLEVBQUU7QUFDTnZELFVBQUFBLFFBQVEsRUFBRTtBQUFFd0QsWUFBQUEsS0FBSyxFQUFFLE9BQVQ7QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQURKO0FBRU5DLFVBQUFBLE9BQU8sRUFBRTtBQUFFRixZQUFBQSxLQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCO0FBRkg7QUFERjtBQURELEtBVFE7QUFpQmpCRSxJQUFBQSxnQ0FBZ0MsRUFBRSxVQUNoQ0YsS0FEZ0MsRUFFdkI7QUFDVCxhQUFPRyxPQUFPLENBQUNILEtBQUQsQ0FBZDtBQUNELEtBckJnQjtBQXNCakJkLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCaUIsU0F0Qlg7QUF1QmpCWCxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNXLE9BQVAsRUFBUDtBQUNEO0FBekJnQixHQTd0QjZDO0FBd3ZCaEUsZUFBYTtBQUNYckMsSUFBQUEsS0FBSyxFQUFFLHNCQURJO0FBRVhDLElBQUFBLFdBQVcsRUFDVCxxRkFIUztBQUlYVSxJQUFBQSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ00sT0FKZjtBQUtYUyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDd0MsTUFMZDtBQU1YeEIsSUFBQUEsWUFBWSxFQUFFLEVBTkg7QUFPWEMsSUFBQUEsc0JBQXNCLEVBQUUsSUFQYjtBQVFYQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJYO0FBU1hhLElBQUFBLE9BQU8sRUFBRTtBQUNQUyxNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsUUFBUSxFQUFFO0FBREo7QUFERCxLQVRFO0FBY1hDLElBQUFBLDZDQUE2QyxFQUFFLFVBQVVSLEtBQVYsRUFBMkI7QUFDeEUsYUFBT1MsSUFBSSxDQUFDQyxTQUFMLENBQWVWLEtBQWYsQ0FBUDtBQUNELEtBaEJVO0FBaUJYVyxJQUFBQSw2Q0FBNkMsRUFBRSxVQUM3Q1gsS0FENkMsRUFFeEM7QUFDTCxVQUFJO0FBQ0YsZUFBT1MsSUFBSSxDQUFDRyxLQUFMLENBQVdaLEtBQVgsQ0FBUDtBQUNELE9BRkQsQ0FFRSxPQUFPYSxLQUFQLEVBQWM7QUFDZCxlQUFPYixLQUFQO0FBQ0Q7QUFDRixLQXpCVTtBQTBCWDtBQUNBZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQjJCLElBQWxCLENBQ1IzQixxQ0FBa0JDLE9BQWxCLENBQ0VELHFDQUFrQjRCLEtBQWxCLENBQ0U1QixxQ0FBa0JDLE9BQWxCLENBQ0VELHFDQUFrQjZCLFFBRHBCLEVBRUU3QixxQ0FBa0JFLGdCQUZwQixFQUdFRixxQ0FBa0JHLFdBSHBCLEVBSUVILHFDQUFrQnFFLGVBQWxCLENBQWtDLEdBQWxDLEVBQXVDLElBQXZDLENBSkYsRUFLRXJFLHFDQUFrQkksa0JBQWxCLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLEVBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBTEYsRUFNRUoscUNBQWtCSyx1QkFBbEIsQ0FDRSxJQURGLEVBRUUsR0FGRixFQUdFLEdBSEYsRUFJRSxHQUpGLEVBS0UsR0FMRixFQU1FLEdBTkYsRUFPRSxHQVBGLEVBUUUsR0FSRixFQVNFLEdBVEYsQ0FORixDQURGLENBREYsQ0FEUSxDQTNCQztBQW1EWEMsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDdUIsT0FBUCxDQUNMdkIsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFDWlQsUUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JDLE9BQWxCLENBQ1JELHFDQUFrQkUsZ0JBRFYsRUFFUkYscUNBQWtCRyxXQUZWLEVBR1JILHFDQUFrQnFFLGVBQWxCLENBQWtDLEdBQWxDLEVBQXVDLElBQXZDLENBSFEsRUFJUnJFLHFDQUFrQkksa0JBQWxCLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLEVBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBSlEsRUFLUkoscUNBQWtCSyx1QkFBbEIsQ0FDRSxJQURGLEVBRUUsR0FGRixFQUdFLEdBSEYsRUFJRSxHQUpGLEVBS0UsR0FMRixFQU1FLEdBTkYsRUFPRSxHQVBGLEVBUUUsR0FSRixFQVNFLEdBVEYsQ0FMUTtBQURFLE9BQWQsQ0FESyxDQUFQO0FBcUJEO0FBekVVLEdBeHZCbUQ7QUFtMEJoRSxpQkFBZTtBQUNieEIsSUFBQUEsS0FBSyxFQUFFLGFBRE07QUFFYkMsSUFBQUEsV0FBVyxFQUNULG9HQUhXO0FBSWJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUpiO0FBS2JTLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUxaO0FBTWJkLElBQUFBLFlBQVksRUFBRSxJQU5EO0FBT2JDLElBQUFBLHNCQUFzQixFQUFFLElBUFg7QUFRYkMsSUFBQUEsb0JBQW9CLEVBQUUsS0FSVDtBQVNiYSxJQUFBQSxPQUFPLEVBQUU7QUFDUEQsTUFBQUEsTUFBTSxFQUFFO0FBQ05FLFFBQUFBLE1BQU0sRUFBRTtBQUNOdkQsVUFBQUEsUUFBUSxFQUFFO0FBQUV3RCxZQUFBQSxLQUFLLEVBQUUsT0FBVDtBQUFrQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXpCLFdBREo7QUFFTkMsVUFBQUEsT0FBTyxFQUFFO0FBQUVGLFlBQUFBLEtBQUssRUFBRSxNQUFUO0FBQWlCQyxZQUFBQSxLQUFLLEVBQUU7QUFBeEI7QUFGSDtBQURGO0FBREQsS0FUSTtBQWlCYkUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXJCWTtBQXNCYmQsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JpQixTQXRCZjtBQXVCYlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXpCWSxHQW4wQmlEO0FBODFCaEUsNEJBQTBCO0FBQ3hCckMsSUFBQUEsS0FBSyxFQUFFLGVBRGlCO0FBRXhCQyxJQUFBQSxXQUFXLEVBQUUsZ0RBRlc7QUFHeEJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUhGO0FBSXhCUyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFKRDtBQUt4QmQsSUFBQUEsWUFBWSxFQUFFLEtBTFU7QUFNeEJDLElBQUFBLHNCQUFzQixFQUFFLEtBTkE7QUFPeEJDLElBQUFBLG9CQUFvQixFQUFFLEtBUEU7QUFReEJhLElBQUFBLE9BQU8sRUFBRTtBQUNQRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkUsUUFBQUEsTUFBTSxFQUFFO0FBQ052RCxVQUFBQSxRQUFRLEVBQUU7QUFBRXdELFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FESjtBQUVOQyxVQUFBQSxPQUFPLEVBQUU7QUFBRUYsWUFBQUEsS0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQUFBLEtBQUssRUFBRTtBQUF4QjtBQUZIO0FBREY7QUFERCxLQVJlO0FBZ0J4QkUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXBCdUI7QUFxQnhCZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBckJKO0FBc0J4QlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQXhCdUIsR0E5MUJzQztBQXczQmhFLGdCQUFjO0FBQ1pyQyxJQUFBQSxLQUFLLEVBQUUsV0FESztBQUVaQyxJQUFBQSxXQUFXLEVBQUUsMkJBRkQ7QUFHWlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNNLE9BSGQ7QUFJWlMsSUFBQUEsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ29ELE1BSmI7QUFLWnJCLElBQUFBLE9BQU8sRUFBRTtBQUNQcUIsTUFBQUEsTUFBTSxFQUFFLENBQ047QUFDRXJDLFFBQUFBLElBQUksRUFBRSxNQURSO0FBRUVtQixRQUFBQSxLQUFLLEVBQUU7QUFGVCxPQURNLEVBS047QUFDRW5CLFFBQUFBLElBQUksRUFBRSxPQURSO0FBRUVtQixRQUFBQSxLQUFLLEVBQUU7QUFGVCxPQUxNO0FBREQsS0FMRztBQWlCWmxCLElBQUFBLFlBQVksRUFBRSxNQWpCRjtBQWtCWkMsSUFBQUEsc0JBQXNCLEVBQUUsSUFsQlo7QUFtQlpDLElBQUFBLG9CQUFvQixFQUFFLElBbkJWO0FBb0JaNEMsSUFBQUEsZ0NBQWdDLEVBQUUsSUFwQnRCO0FBcUJaMUMsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBaUI7QUFDekIsYUFBT2IscUNBQWtCZ0MsT0FBbEIsQ0FDTCxLQUFLdEIsT0FBTCxDQUFhcUIsTUFBYixDQUFvQkUsR0FBcEIsQ0FBd0IsQ0FBQztBQUFFcEIsUUFBQUE7QUFBRixPQUFELEtBQWVBLEtBQXZDLENBREssRUFFTEEsS0FGSyxDQUFQO0FBR0QsS0F6Qlc7QUEwQlpQLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQzJCLEtBQVAsQ0FDTCxLQUFLeEIsT0FBTCxDQUFhcUIsTUFBYixDQUFvQkUsR0FBcEIsQ0FBd0IsQ0FBQztBQUFFcEIsUUFBQUE7QUFBRixPQUFELEtBQWVOLE1BQU0sQ0FBQ3lCLE9BQVAsQ0FBZW5CLEtBQWYsQ0FBdkMsQ0FESyxDQUFQO0FBR0Q7QUE5QlcsR0F4M0JrRDtBQXc1QmhFeUQsRUFBQUEsT0FBTyxFQUFFO0FBQ1B6RixJQUFBQSxLQUFLLEVBQUUsZUFEQTtBQUVQQyxJQUFBQSxXQUFXLEVBQ1QsMkpBSEs7QUFJUFUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNNLE9BSm5CO0FBS1BTLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUNlLElBTGxCO0FBTVBDLElBQUFBLFlBQVksRUFBRTFLLG9CQU5QO0FBT1AySyxJQUFBQSxzQkFBc0IsRUFBRSxJQVBqQjtBQVFQQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJmO0FBU1BDLElBQUFBLDBCQUEwQixFQUFFLElBVHJCO0FBVVA7QUFDQUMsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JDLE9BQWxCLENBQ1JELHFDQUFrQkUsZ0JBRFYsRUFFUkYscUNBQWtCRyxXQUZWLEVBR1JILHFDQUFrQnFFLGVBQWxCLENBQWtDLEdBQWxDLEVBQXVDLElBQXZDLENBSFEsRUFJUnJFLHFDQUFrQkksa0JBQWxCLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLEVBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBSlEsRUFLUkoscUNBQWtCSyx1QkFBbEIsQ0FDRSxJQURGLEVBRUUsR0FGRixFQUdFLEdBSEYsRUFJRSxHQUpGLEVBS0UsR0FMRixFQU1FLEdBTkYsRUFPRSxHQVBGLEVBUUUsR0FSRixFQVNFLEdBVEYsQ0FMUSxDQVhIO0FBNEJQQyxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFFVCxRQUFBQSxRQUFRLEVBQUUsS0FBS0E7QUFBakIsT0FBZCxDQUFQO0FBQ0Q7QUE5Qk0sR0F4NUJ1RDtBQXc3QmhFd0UsRUFBQUEsT0FBTyxFQUFFO0FBQ1AxRixJQUFBQSxLQUFLLEVBQUUsaUJBREE7QUFFUEMsSUFBQUEsV0FBVyxFQUNULGtLQUhLO0FBSVBVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUpuQjtBQUtQUyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDd0QsTUFMbEI7QUFNUHhDLElBQUFBLFlBQVksRUFBRSxLQU5QO0FBT1BDLElBQUFBLHNCQUFzQixFQUFFLElBUGpCO0FBUVBDLElBQUFBLG9CQUFvQixFQUFFLElBUmY7QUFTUGEsSUFBQUEsT0FBTyxFQUFFO0FBQ1B5QixNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsR0FBRyxFQUFFLElBREM7QUFFTkMsUUFBQUEsT0FBTyxFQUFFO0FBRkg7QUFERCxLQVRGO0FBZVBoQixJQUFBQSw2Q0FBNkMsRUFBRSxVQUFVUixLQUFWLEVBQXlCO0FBQ3RFLGFBQU95QixNQUFNLENBQUN6QixLQUFELENBQWI7QUFDRCxLQWpCTTtBQWtCUFcsSUFBQUEsNkNBQTZDLEVBQUUsVUFDN0NYLEtBRDZDLEVBRXJDO0FBQ1IsYUFBTzBCLE1BQU0sQ0FBQzFCLEtBQUQsQ0FBYjtBQUNELEtBdEJNO0FBdUJQZCxJQUFBQSxRQUFRLEVBQUUsVUFBVWMsS0FBVixFQUFpQjtBQUN6QixhQUFPYixxQ0FBa0JtQyxNQUFsQixDQUF5QixLQUFLekIsT0FBTCxDQUFheUIsTUFBdEMsRUFBOEN0QixLQUE5QyxDQUFQO0FBQ0QsS0F6Qk07QUEwQlBQLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQzRCLE1BQVAsQ0FBYztBQUFFcEMsUUFBQUEsUUFBUSxFQUFFLEtBQUtBLFFBQUwsQ0FBY3lDLElBQWQsQ0FBbUIsSUFBbkI7QUFBWixPQUFkLENBQVA7QUFDRDtBQTVCTSxHQXg3QnVEO0FBczlCaEUsK0JBQTZCO0FBQzNCM0QsSUFBQUEsS0FBSyxFQUFFLGdCQURvQjtBQUUzQkMsSUFBQUEsV0FBVyxFQUNULDRFQUh5QjtBQUkzQlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNRLFVBSkM7QUFLM0JPLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUNvRCxNQUxFO0FBTTNCckIsSUFBQUEsT0FBTyxFQUFFO0FBQ1BxQixNQUFBQSxNQUFNLEVBQUUsQ0FDTjtBQUNFckMsUUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BRE0sRUFLTjtBQUNFbkIsUUFBQUEsSUFBSSxFQUFFLE9BRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BTE0sRUFTTjtBQUNFbkIsUUFBQUEsSUFBSSxFQUFFLFFBRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BVE0sRUFhTjtBQUNFbkIsUUFBQUEsSUFBSSxFQUFFLFNBRFI7QUFFRW1CLFFBQUFBLEtBQUssRUFBRTtBQUZULE9BYk07QUFERCxLQU5rQjtBQTBCM0JsQixJQUFBQSxZQUFZLEVBQUVuSyxpQ0ExQmE7QUEyQjNCb0ssSUFBQUEsc0JBQXNCLEVBQUUsSUEzQkc7QUE0QjNCQyxJQUFBQSxvQkFBb0IsRUFBRSxJQTVCSztBQTZCM0JDLElBQUFBLDBCQUEwQixFQUFFLElBN0JEO0FBOEIzQkMsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBaUI7QUFDekIsYUFBT2IscUNBQWtCZ0MsT0FBbEIsQ0FDTCxLQUFLdEIsT0FBTCxDQUFhcUIsTUFBYixDQUFvQkUsR0FBcEIsQ0FBd0IsQ0FBQztBQUFFcEIsUUFBQUE7QUFBRixPQUFELEtBQWVBLEtBQXZDLENBREssRUFFTEEsS0FGSyxDQUFQO0FBR0QsS0FsQzBCO0FBbUMzQlAsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDMkIsS0FBUCxDQUNMLEtBQUt4QixPQUFMLENBQWFxQixNQUFiLENBQW9CRSxHQUFwQixDQUF3QixDQUFDO0FBQUVwQixRQUFBQTtBQUFGLE9BQUQsS0FBZU4sTUFBTSxDQUFDeUIsT0FBUCxDQUFlbkIsS0FBZixDQUF2QyxDQURLLENBQVA7QUFHRDtBQXZDMEIsR0F0OUJtQztBQSsvQmhFLDhCQUE0QjtBQUMxQmhDLElBQUFBLEtBQUssRUFBRSxRQURtQjtBQUUxQkMsSUFBQUEsV0FBVyxFQUNULDZFQUh3QjtBQUkxQlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNRLFVBSkE7QUFLMUJPLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUxDO0FBTTFCZCxJQUFBQSxZQUFZLEVBQUVsSyxnQ0FOWTtBQU8xQm1LLElBQUFBLHNCQUFzQixFQUFFLElBUEU7QUFRMUJDLElBQUFBLG9CQUFvQixFQUFFLElBUkk7QUFTMUI0QyxJQUFBQSxnQ0FBZ0MsRUFBRSxJQVRSO0FBVTFCL0IsSUFBQUEsT0FBTyxFQUFFO0FBQ1BELE1BQUFBLE1BQU0sRUFBRTtBQUNORSxRQUFBQSxNQUFNLEVBQUU7QUFDTnZELFVBQUFBLFFBQVEsRUFBRTtBQUFFd0QsWUFBQUEsS0FBSyxFQUFFLE9BQVQ7QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQURKO0FBRU5DLFVBQUFBLE9BQU8sRUFBRTtBQUFFRixZQUFBQSxLQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCO0FBRkg7QUFERjtBQURELEtBVmlCO0FBa0IxQkUsSUFBQUEsZ0NBQWdDLEVBQUUsVUFDaENGLEtBRGdDLEVBRXZCO0FBQ1QsYUFBT0csT0FBTyxDQUFDSCxLQUFELENBQWQ7QUFDRCxLQXRCeUI7QUF1QjFCZCxJQUFBQSxRQUFRLEVBQUVDLHFDQUFrQmlCLFNBdkJGO0FBd0IxQlgsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDVyxPQUFQLEVBQVA7QUFDRDtBQTFCeUIsR0EvL0JvQztBQTJoQ2hFLGdDQUE4QjtBQUM1QnJDLElBQUFBLEtBQUssRUFBRSxXQURxQjtBQUU1QkMsSUFBQUEsV0FBVyxFQUNULCtJQUgwQjtBQUk1QlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNRLFVBSkU7QUFLNUJPLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUN3RCxNQUxHO0FBTTVCeEMsSUFBQUEsWUFBWSxFQUFFakssa0NBTmM7QUFPNUJrSyxJQUFBQSxzQkFBc0IsRUFBRSxJQVBJO0FBUTVCQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJNO0FBUzVCNEMsSUFBQUEsZ0NBQWdDLEVBQUUsSUFUTjtBQVU1Qi9CLElBQUFBLE9BQU8sRUFBRTtBQUNQeUIsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLEdBQUcsRUFBRSxFQURDO0FBRU5DLFFBQUFBLE9BQU8sRUFBRTtBQUZIO0FBREQsS0FWbUI7QUFnQjVCaEIsSUFBQUEsNkNBQTZDLEVBQUUsVUFBVVIsS0FBVixFQUF5QjtBQUN0RSxhQUFPeUIsTUFBTSxDQUFDekIsS0FBRCxDQUFiO0FBQ0QsS0FsQjJCO0FBbUI1QlcsSUFBQUEsNkNBQTZDLEVBQUUsVUFDN0NYLEtBRDZDLEVBRXJDO0FBQ1IsYUFBTzBCLE1BQU0sQ0FBQzFCLEtBQUQsQ0FBYjtBQUNELEtBdkIyQjtBQXdCNUJkLElBQUFBLFFBQVEsRUFBRSxVQUFVYyxLQUFWLEVBQWlCO0FBQ3pCLGFBQU9iLHFDQUFrQm1DLE1BQWxCLENBQXlCLEtBQUt6QixPQUFMLENBQWF5QixNQUF0QyxFQUE4Q3RCLEtBQTlDLENBQVA7QUFDRCxLQTFCMkI7QUEyQjVCUCxJQUFBQSxlQUFlLEVBQUUsVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxhQUFPQSxNQUFNLENBQUM0QixNQUFQLENBQWM7QUFBRXBDLFFBQUFBLFFBQVEsRUFBRSxLQUFLQSxRQUFMLENBQWN5QyxJQUFkLENBQW1CLElBQW5CO0FBQVosT0FBZCxDQUFQO0FBQ0Q7QUE3QjJCLEdBM2hDa0M7QUEwakNoRSw4QkFBNEI7QUFDMUIzRCxJQUFBQSxLQUFLLEVBQUUsZUFEbUI7QUFFMUJDLElBQUFBLFdBQVcsRUFBRSxvREFGYTtBQUcxQlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNRLFVBSEE7QUFJMUJPLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUNlLElBSkM7QUFLMUJDLElBQUFBLFlBQVksRUFBRXZLLHdCQUxZO0FBTTFCd0ssSUFBQUEsc0JBQXNCLEVBQUUsSUFORTtBQU8xQkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFQSTtBQVExQkMsSUFBQUEsMEJBQTBCLEVBQUUsSUFSRjtBQVMxQkMsSUFBQUEsUUFBUSxFQUFFQyxxQ0FBa0JDLE9BQWxCLENBQ1JELHFDQUFrQkUsZ0JBRFYsRUFFUkYscUNBQWtCRyxXQUZWLEVBR1JILHFDQUFrQnFFLGVBQWxCLENBQWtDLEdBQWxDLEVBQXVDLElBQXZDLENBSFEsRUFJUnJFLHFDQUFrQkksa0JBQWxCLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLEVBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBSlEsRUFLUkoscUNBQWtCSyx1QkFBbEIsQ0FDRSxJQURGLEVBRUUsR0FGRixFQUdFLEdBSEYsRUFJRSxHQUpGLEVBS0UsR0FMRixFQU1FLEdBTkYsRUFPRSxHQVBGLEVBUUUsR0FSRixFQVNFLEdBVEYsQ0FMUSxDQVRnQjtBQTBCMUJDLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUVnRSxRQUFBQSxTQUFTLEVBQUUsQ0FBYjtBQUFnQnpFLFFBQUFBLFFBQVEsRUFBRSxLQUFLQTtBQUEvQixPQUFkLENBQVA7QUFDRDtBQTVCeUIsR0ExakNvQztBQXdsQ2hFLCtCQUE2QjtBQUMzQmxCLElBQUFBLEtBQUssRUFBRSxnQkFEb0I7QUFFM0JDLElBQUFBLFdBQVcsRUFDVCwwRUFIeUI7QUFJM0JVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDUSxVQUpDO0FBSzNCTyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDd0QsTUFMRTtBQU0zQnhDLElBQUFBLFlBQVksRUFBRXBLLHlDQU5hO0FBTzNCcUssSUFBQUEsc0JBQXNCLEVBQUUsSUFQRztBQVEzQkMsSUFBQUEsb0JBQW9CLEVBQUUsSUFSSztBQVMzQkMsSUFBQUEsMEJBQTBCLEVBQUUsSUFURDtBQVUzQlksSUFBQUEsT0FBTyxFQUFFO0FBQ1B5QixNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsR0FBRyxFQUFFLENBREM7QUFFTkMsUUFBQUEsT0FBTyxFQUFFO0FBRkg7QUFERCxLQVZrQjtBQWdCM0JoQixJQUFBQSw2Q0FBNkMsRUFBRSxVQUFVUixLQUFWLEVBQXlCO0FBQ3RFLGFBQU95QixNQUFNLENBQUN6QixLQUFELENBQWI7QUFDRCxLQWxCMEI7QUFtQjNCVyxJQUFBQSw2Q0FBNkMsRUFBRSxVQUM3Q1gsS0FENkMsRUFFckM7QUFDUixhQUFPMEIsTUFBTSxDQUFDMUIsS0FBRCxDQUFiO0FBQ0QsS0F2QjBCO0FBd0IzQmQsSUFBQUEsUUFBUSxFQUFFLFVBQVVjLEtBQVYsRUFBaUI7QUFDekIsYUFBT2IscUNBQWtCbUMsTUFBbEIsQ0FBeUIsS0FBS3pCLE9BQUwsQ0FBYXlCLE1BQXRDLEVBQThDdEIsS0FBOUMsQ0FBUDtBQUNELEtBMUIwQjtBQTJCM0JQLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQzRCLE1BQVAsQ0FBYztBQUFFcEMsUUFBQUEsUUFBUSxFQUFFLEtBQUtBLFFBQUwsQ0FBY3lDLElBQWQsQ0FBbUIsSUFBbkI7QUFBWixPQUFkLENBQVA7QUFDRDtBQTdCMEIsR0F4bENtQztBQXVuQ2hFLDZCQUEyQjtBQUN6QjNELElBQUFBLEtBQUssRUFBRSxjQURrQjtBQUV6QkMsSUFBQUEsV0FBVyxFQUNULHdFQUh1QjtBQUl6QlUsSUFBQUEsUUFBUSxFQUFFZCxlQUFlLENBQUNRLFVBSkQ7QUFLekJPLElBQUFBLElBQUksRUFBRWQsa0JBQWtCLENBQUN3RCxNQUxBO0FBTXpCeEMsSUFBQUEsWUFBWSxFQUFFckssdUNBTlc7QUFPekJzSyxJQUFBQSxzQkFBc0IsRUFBRSxJQVBDO0FBUXpCQyxJQUFBQSxvQkFBb0IsRUFBRSxJQVJHO0FBU3pCQyxJQUFBQSwwQkFBMEIsRUFBRSxJQVRIO0FBVXpCWSxJQUFBQSxPQUFPLEVBQUU7QUFDUHlCLE1BQUFBLE1BQU0sRUFBRTtBQUNOQyxRQUFBQSxHQUFHLEVBQUUsQ0FEQztBQUVOQyxRQUFBQSxPQUFPLEVBQUU7QUFGSDtBQURELEtBVmdCO0FBZ0J6QmhCLElBQUFBLDZDQUE2QyxFQUFFLFVBQVVSLEtBQVYsRUFBeUI7QUFDdEUsYUFBT3lCLE1BQU0sQ0FBQ3pCLEtBQUQsQ0FBYjtBQUNELEtBbEJ3QjtBQW1CekJXLElBQUFBLDZDQUE2QyxFQUFFLFVBQzdDWCxLQUQ2QyxFQUVyQztBQUNSLGFBQU8wQixNQUFNLENBQUMxQixLQUFELENBQWI7QUFDRCxLQXZCd0I7QUF3QnpCZCxJQUFBQSxRQUFRLEVBQUUsVUFBVWMsS0FBVixFQUFpQjtBQUN6QixhQUFPYixxQ0FBa0JtQyxNQUFsQixDQUF5QixLQUFLekIsT0FBTCxDQUFheUIsTUFBdEMsRUFBOEN0QixLQUE5QyxDQUFQO0FBQ0QsS0ExQndCO0FBMkJ6QlAsSUFBQUEsZUFBZSxFQUFFLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsYUFBT0EsTUFBTSxDQUFDNEIsTUFBUCxDQUFjO0FBQUVwQyxRQUFBQSxRQUFRLEVBQUUsS0FBS0EsUUFBTCxDQUFjeUMsSUFBZCxDQUFtQixJQUFuQjtBQUFaLE9BQWQsQ0FBUDtBQUNEO0FBN0J3QixHQXZuQ3FDO0FBc3BDaEUsNkJBQTJCO0FBQ3pCM0QsSUFBQUEsS0FBSyxFQUFFLGVBRGtCO0FBRXpCQyxJQUFBQSxXQUFXLEVBQUUsbURBRlk7QUFHekJVLElBQUFBLFFBQVEsRUFBRWQsZUFBZSxDQUFDVSxlQUhEO0FBSXpCSyxJQUFBQSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDZSxJQUpBO0FBS3pCQyxJQUFBQSxZQUFZLEVBQUVwSiw2QkFMVztBQU16QnFKLElBQUFBLHNCQUFzQixFQUFFLElBTkM7QUFPekJDLElBQUFBLG9CQUFvQixFQUFFLElBUEc7QUFRekJDLElBQUFBLDBCQUEwQixFQUFFLEtBUkg7QUFTekJDLElBQUFBLFFBQVEsRUFBRUMscUNBQWtCQyxPQUFsQixDQUNSRCxxQ0FBa0JFLGdCQURWLEVBRVJGLHFDQUFrQkcsV0FGVixFQUdSSCxxQ0FBa0JxRSxlQUFsQixDQUFrQyxHQUFsQyxFQUF1QyxJQUF2QyxDQUhRLEVBSVJyRSxxQ0FBa0JJLGtCQUFsQixDQUFxQyxHQUFyQyxFQUEwQyxHQUExQyxFQUErQyxHQUEvQyxFQUFvRCxHQUFwRCxDQUpRLEVBS1JKLHFDQUFrQkssdUJBQWxCLENBQ0UsSUFERixFQUVFLEdBRkYsRUFHRSxHQUhGLEVBSUUsR0FKRixFQUtFLEdBTEYsRUFNRSxHQU5GLEVBT0UsR0FQRixFQVFFLEdBUkYsRUFTRSxHQVRGLENBTFEsQ0FUZTtBQTBCekJDLElBQUFBLGVBQWUsRUFBRSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2pDLGFBQU9BLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUVnRSxRQUFBQSxTQUFTLEVBQUUsQ0FBYjtBQUFnQnpFLFFBQUFBLFFBQVEsRUFBRSxLQUFLQTtBQUEvQixPQUFkLENBQVA7QUFDRDtBQTVCd0I7QUF0cENxQyxDQUEzRDs7SUF3ckNLMEUsaUIsRUEyRFo7Ozs7V0EzRFlBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0FBQUFBLEVBQUFBLGlCLENBQUFBLGlCO0dBQUFBLGlCLGlDQUFBQSxpQjs7QUE0REwsTUFBTUMsNkJBQTZCLEdBQUc7QUFDM0NDLEVBQUFBLE1BQU0sRUFBRSxRQURtQztBQUUzQ0MsRUFBQUEsTUFBTSxFQUFFLFFBRm1DO0FBRzNDLG9CQUFrQjtBQUh5QixDQUF0QyxDLENBTVA7QUFFQTs7O0FBQ08sTUFBTUMsc0NBQXNDLEdBQUcsRUFBL0MsQyxDQUNQOzs7QUFDTyxNQUFNQyw4Q0FBOEMsR0FBRyxFQUF2RDtBQUNQO0FBQ0E7OztBQUNPLE1BQU1DLCtCQUErQixHQUFHLEdBQXhDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIFdhenVoIENvbnN0YW50cyBmaWxlXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxuICpcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cbiAqL1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5pbXBvcnQgeyB2ZXJzaW9uIH0gZnJvbSAnLi4vcGFja2FnZS5qc29uJztcbmltcG9ydCB7IHZhbGlkYXRlIGFzIHZhbGlkYXRlTm9kZUNyb25JbnRlcnZhbCB9IGZyb20gJ25vZGUtY3Jvbic7XG5pbXBvcnQgeyBTZXR0aW5nc1ZhbGlkYXRvciB9IGZyb20gJy4uL2NvbW1vbi9zZXJ2aWNlcy9zZXR0aW5ncy12YWxpZGF0b3InO1xuXG4vLyBQbHVnaW5cbmV4cG9ydCBjb25zdCBQTFVHSU5fVkVSU0lPTiA9IHZlcnNpb247XG5leHBvcnQgY29uc3QgUExVR0lOX1ZFUlNJT05fU0hPUlQgPSB2ZXJzaW9uLnNwbGl0KCcuJykuc3BsaWNlKDAsIDIpLmpvaW4oJy4nKTtcblxuLy8gSW5kZXggcGF0dGVybnMgLSBXYXp1aCBhbGVydHNcbmV4cG9ydCBjb25zdCBXQVpVSF9JTkRFWF9UWVBFX0FMRVJUUyA9ICdhbGVydHMnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0FMRVJUU19QUkVGSVggPSAnd2F6dWgtYWxlcnRzLSc7XG5leHBvcnQgY29uc3QgV0FaVUhfQUxFUlRTX1BBVFRFUk4gPSAnd2F6dWgtYWxlcnRzLSonO1xuXG4vLyBKb2IgLSBXYXp1aCBtb25pdG9yaW5nXG5leHBvcnQgY29uc3QgV0FaVUhfSU5ERVhfVFlQRV9NT05JVE9SSU5HID0gJ21vbml0b3JpbmcnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX01PTklUT1JJTkdfUFJFRklYID0gJ3dhenVoLW1vbml0b3JpbmctJztcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk4gPSAnd2F6dWgtbW9uaXRvcmluZy0qJztcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUgPSAnd2F6dWgtYWdlbnQnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9JTkRJQ0VTX1NIQVJEUyA9IDE7XG5leHBvcnQgY29uc3QgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMgPSAwO1xuZXhwb3J0IGNvbnN0IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9DUkVBVElPTiA9ICd3JztcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfRU5BQkxFRCA9IHRydWU7XG5leHBvcnQgY29uc3QgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0ZSRVFVRU5DWSA9IDkwMDtcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JPTl9GUkVRID0gJzAgKiAqICogKiAqJztcblxuLy8gSm9iIC0gV2F6dWggc3RhdGlzdGljc1xuZXhwb3J0IGNvbnN0IFdBWlVIX0lOREVYX1RZUEVfU1RBVElTVElDUyA9ICdzdGF0aXN0aWNzJztcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfUFJFRklYID0gJ3dhenVoJztcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfTkFNRSA9ICdzdGF0aXN0aWNzJztcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX1BBVFRFUk4gPSBgJHtXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfUFJFRklYfS0ke1dBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9OQU1FfS0qYDtcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX1RFTVBMQVRFX05BTUUgPSBgJHtXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfUFJFRklYfS0ke1dBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9OQU1FfWA7XG5leHBvcnQgY29uc3QgV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0lORElDRVNfU0hBUkRTID0gMTtcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfSU5ESUNFU19SRVBMSUNBUyA9IDA7XG5leHBvcnQgY29uc3QgV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0NSRUFUSU9OID0gJ3cnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9TVEFUVVMgPSB0cnVlO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9GUkVRVUVOQ1kgPSA5MDA7XG5leHBvcnQgY29uc3QgV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0NST05fRlJFUSA9ICcwICovNSAqICogKiAqJztcblxuLy8gV2F6dWggdnVsbmVyYWJpbGl0aWVzXG5leHBvcnQgY29uc3QgV0FaVUhfVlVMTkVSQUJJTElUSUVTX1BBVFRFUk4gPSAnd2F6dWgtc3RhdGVzLXZ1bG5lcmFiaWxpdGllcy0qJztcbmV4cG9ydCBjb25zdCBXQVpVSF9JTkRFWF9UWVBFX1ZVTE5FUkFCSUxJVElFUyA9ICd2dWxuZXJhYmlsaXRpZXMnO1xuXG4vLyBKb2IgLSBXYXp1aCBpbml0aWFsaXplXG5leHBvcnQgY29uc3QgV0FaVUhfUExVR0lOX1BMQVRGT1JNX1RFTVBMQVRFX05BTUUgPSAnd2F6dWgta2liYW5hJztcblxuLy8gUGVybWlzc2lvbnNcbmV4cG9ydCBjb25zdCBXQVpVSF9ST0xFX0FETUlOSVNUUkFUT1JfSUQgPSAxO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9OQU1FID0gJ2FkbWluaXN0cmF0b3InO1xuXG4vLyBTYW1wbGUgZGF0YVxuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVF9QUkVGSVggPSAnd2F6dWgtYWxlcnRzLTQueC0nO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfU0hBUkRTID0gMTtcbmV4cG9ydCBjb25zdCBXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1JFUExJQ0FTID0gMDtcbmV4cG9ydCBjb25zdCBXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JZX1NFQ1VSSVRZID0gJ3NlY3VyaXR5JztcbmV4cG9ydCBjb25zdCBXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JZX0FVRElUSU5HX1BPTElDWV9NT05JVE9SSU5HID1cbiAgJ2F1ZGl0aW5nLXBvbGljeS1tb25pdG9yaW5nJztcbmV4cG9ydCBjb25zdCBXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JZX1RIUkVBVF9ERVRFQ1RJT04gPSAndGhyZWF0LWRldGVjdGlvbic7XG5leHBvcnQgY29uc3QgV0FaVUhfU0FNUExFX0FMRVJUU19ERUZBVUxUX05VTUJFUl9BTEVSVFMgPSAzMDAwO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUklFU19UWVBFX0FMRVJUUyA9IHtcbiAgW1dBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfU0VDVVJJVFldOiBbXG4gICAgeyBzeXNjaGVjazogdHJ1ZSB9LFxuICAgIHsgYXdzOiB0cnVlIH0sXG4gICAgeyBvZmZpY2U6IHRydWUgfSxcbiAgICB7IGdjcDogdHJ1ZSB9LFxuICAgIHsgYXV0aGVudGljYXRpb246IHRydWUgfSxcbiAgICB7IHNzaDogdHJ1ZSB9LFxuICAgIHsgYXBhY2hlOiB0cnVlLCBhbGVydHM6IDIwMDAgfSxcbiAgICB7IHdlYjogdHJ1ZSB9LFxuICAgIHsgd2luZG93czogeyBzZXJ2aWNlX2NvbnRyb2xfbWFuYWdlcjogdHJ1ZSB9LCBhbGVydHM6IDEwMDAgfSxcbiAgICB7IGdpdGh1YjogdHJ1ZSB9LFxuICBdLFxuICBbV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SWV9BVURJVElOR19QT0xJQ1lfTU9OSVRPUklOR106IFtcbiAgICB7IHJvb3RjaGVjazogdHJ1ZSB9LFxuICAgIHsgYXVkaXQ6IHRydWUgfSxcbiAgICB7IG9wZW5zY2FwOiB0cnVlIH0sXG4gICAgeyBjaXNjYXQ6IHRydWUgfSxcbiAgXSxcbiAgW1dBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfVEhSRUFUX0RFVEVDVElPTl06IFtcbiAgICB7IHZ1bG5lcmFiaWxpdGllczogdHJ1ZSB9LFxuICAgIHsgdmlydXN0b3RhbDogdHJ1ZSB9LFxuICAgIHsgb3NxdWVyeTogdHJ1ZSB9LFxuICAgIHsgZG9ja2VyOiB0cnVlIH0sXG4gICAgeyBtaXRyZTogdHJ1ZSB9LFxuICBdLFxufTtcblxuLy8gU2VjdXJpdHlcbmV4cG9ydCBjb25zdCBXQVpVSF9TRUNVUklUWV9QTFVHSU5fT1BFTlNFQVJDSF9EQVNIQk9BUkRTX1NFQ1VSSVRZID1cbiAgJ09wZW5TZWFyY2ggRGFzaGJvYXJkcyBTZWN1cml0eSc7XG5cbmV4cG9ydCBjb25zdCBXQVpVSF9TRUNVUklUWV9QTFVHSU5TID0gW1xuICBXQVpVSF9TRUNVUklUWV9QTFVHSU5fT1BFTlNFQVJDSF9EQVNIQk9BUkRTX1NFQ1VSSVRZLFxuXTtcblxuLy8gQXBwIGNvbmZpZ3VyYXRpb25cbmV4cG9ydCBjb25zdCBXQVpVSF9DT05GSUdVUkFUSU9OX0NBQ0hFX1RJTUUgPSAxMDAwMDsgLy8gdGltZSBpbiBtcztcblxuLy8gUmVzZXJ2ZWQgaWRzIGZvciBVc2Vycy9Sb2xlIG1hcHBpbmdcbmV4cG9ydCBjb25zdCBXQVpVSF9BUElfUkVTRVJWRURfSURfTE9XRVJfVEhBTiA9IDEwMDtcbmV4cG9ydCBjb25zdCBXQVpVSF9BUElfUkVTRVJWRURfV1VJX1NFQ1VSSVRZX1JVTEVTID0gWzEsIDJdO1xuXG4vLyBXYXp1aCBkYXRhIHBhdGhcbmNvbnN0IFdBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfUEFUSCA9ICdkYXRhJztcbmV4cG9ydCBjb25zdCBXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX0FCU09MVVRFX1BBVEggPSBwYXRoLmpvaW4oXG4gIF9fZGlybmFtZSxcbiAgJy4uLy4uLy4uLycsXG4gIFdBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfUEFUSCxcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9BQlNPTFVURV9QQVRIID0gcGF0aC5qb2luKFxuICBXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX0FCU09MVVRFX1BBVEgsXG4gICd3YXp1aCcsXG4pO1xuXG4vLyBXYXp1aCBkYXRhIHBhdGggLSBjb25maWdcbmV4cG9ydCBjb25zdCBXQVpVSF9EQVRBX0NPTkZJR19ESVJFQ1RPUllfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9BQlNPTFVURV9QQVRILFxuICAnY29uZmlnJyxcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9DT05GSUdfQVBQX1BBVEggPSBwYXRoLmpvaW4oXG4gIFdBWlVIX0RBVEFfQ09ORklHX0RJUkVDVE9SWV9QQVRILFxuICAnd2F6dWgueW1sJyxcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9DT05GSUdfUkVHSVNUUllfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9DT05GSUdfRElSRUNUT1JZX1BBVEgsXG4gICd3YXp1aC1yZWdpc3RyeS5qc29uJyxcbik7XG5cbi8vIFdhenVoIGRhdGEgcGF0aCAtIGxvZ3NcbmV4cG9ydCBjb25zdCBNQVhfTUJfTE9HX0ZJTEVTID0gMTAwO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfTE9HU19ESVJFQ1RPUllfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9BQlNPTFVURV9QQVRILFxuICAnbG9ncycsXG4pO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfTE9HU19QTEFJTl9GSUxFTkFNRSA9ICd3YXp1aGFwcC1wbGFpbi5sb2cnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfTE9HU19QTEFJTl9QQVRIID0gcGF0aC5qb2luKFxuICBXQVpVSF9EQVRBX0xPR1NfRElSRUNUT1JZX1BBVEgsXG4gIFdBWlVIX0RBVEFfTE9HU19QTEFJTl9GSUxFTkFNRSxcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9MT0dTX1JBV19GSUxFTkFNRSA9ICd3YXp1aGFwcC5sb2cnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfTE9HU19SQVdfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9MT0dTX0RJUkVDVE9SWV9QQVRILFxuICBXQVpVSF9EQVRBX0xPR1NfUkFXX0ZJTEVOQU1FLFxuKTtcblxuLy8gV2F6dWggZGF0YSBwYXRoIC0gVUkgbG9nc1xuZXhwb3J0IGNvbnN0IFdBWlVIX1VJX0xPR1NfUExBSU5fRklMRU5BTUUgPSAnd2F6dWgtdWktcGxhaW4ubG9nJztcbmV4cG9ydCBjb25zdCBXQVpVSF9VSV9MT0dTX1JBV19GSUxFTkFNRSA9ICd3YXp1aC11aS5sb2cnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1VJX0xPR1NfUExBSU5fUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9MT0dTX0RJUkVDVE9SWV9QQVRILFxuICBXQVpVSF9VSV9MT0dTX1BMQUlOX0ZJTEVOQU1FLFxuKTtcbmV4cG9ydCBjb25zdCBXQVpVSF9VSV9MT0dTX1JBV19QQVRIID0gcGF0aC5qb2luKFxuICBXQVpVSF9EQVRBX0xPR1NfRElSRUNUT1JZX1BBVEgsXG4gIFdBWlVIX1VJX0xPR1NfUkFXX0ZJTEVOQU1FLFxuKTtcblxuLy8gV2F6dWggZGF0YSBwYXRoIC0gZG93bmxvYWRzXG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEggPSBwYXRoLmpvaW4oXG4gIFdBWlVIX0RBVEFfQUJTT0xVVEVfUEFUSCxcbiAgJ2Rvd25sb2FkcycsXG4pO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEggPSBwYXRoLmpvaW4oXG4gIFdBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRILFxuICAncmVwb3J0cycsXG4pO1xuXG4vLyBRdWV1ZVxuZXhwb3J0IGNvbnN0IFdBWlVIX1FVRVVFX0NST05fRlJFUSA9ICcqLzE1ICogKiAqICogKic7IC8vIEV2ZXJ5IDE1IHNlY29uZHNcblxuLy8gV2F6dWggZXJyb3JzXG5leHBvcnQgY29uc3QgV0FaVUhfRVJST1JfREFFTU9OU19OT1RfUkVBRFkgPSAnRVJST1IzMDk5JztcblxuLy8gQWdlbnRzXG5leHBvcnQgZW51bSBXQVpVSF9BR0VOVFNfT1NfVFlQRSB7XG4gIFdJTkRPV1MgPSAnd2luZG93cycsXG4gIExJTlVYID0gJ2xpbnV4JyxcbiAgU1VOT1MgPSAnc3Vub3MnLFxuICBEQVJXSU4gPSAnZGFyd2luJyxcbiAgT1RIRVJTID0gJycsXG59XG5cbmV4cG9ydCBlbnVtIFdBWlVIX01PRFVMRVNfSUQge1xuICBTRUNVUklUWV9FVkVOVFMgPSAnZ2VuZXJhbCcsXG4gIElOVEVHUklUWV9NT05JVE9SSU5HID0gJ2ZpbScsXG4gIEFNQVpPTl9XRUJfU0VSVklDRVMgPSAnYXdzJyxcbiAgT0ZGSUNFXzM2NSA9ICdvZmZpY2UnLFxuICBHT09HTEVfQ0xPVURfUExBVEZPUk0gPSAnZ2NwJyxcbiAgUE9MSUNZX01PTklUT1JJTkcgPSAncG0nLFxuICBTRUNVUklUWV9DT05GSUdVUkFUSU9OX0FTU0VTU01FTlQgPSAnc2NhJyxcbiAgQVVESVRJTkcgPSAnYXVkaXQnLFxuICBPUEVOX1NDQVAgPSAnb3NjYXAnLFxuICBWVUxORVJBQklMSVRJRVMgPSAndnVscycsXG4gIE9TUVVFUlkgPSAnb3NxdWVyeScsXG4gIERPQ0tFUiA9ICdkb2NrZXInLFxuICBNSVRSRV9BVFRBQ0sgPSAnbWl0cmUnLFxuICBQQ0lfRFNTID0gJ3BjaScsXG4gIEhJUEFBID0gJ2hpcGFhJyxcbiAgTklTVF84MDBfNTMgPSAnbmlzdCcsXG4gIFRTQyA9ICd0c2MnLFxuICBDSVNfQ0FUID0gJ2Npc2NhdCcsXG4gIFZJUlVTVE9UQUwgPSAndmlydXN0b3RhbCcsXG4gIEdEUFIgPSAnZ2RwcicsXG4gIEdJVEhVQiA9ICdnaXRodWInLFxufVxuXG5leHBvcnQgZW51bSBXQVpVSF9NRU5VX01BTkFHRU1FTlRfU0VDVElPTlNfSUQge1xuICBNQU5BR0VNRU5UID0gJ21hbmFnZW1lbnQnLFxuICBBRE1JTklTVFJBVElPTiA9ICdhZG1pbmlzdHJhdGlvbicsXG4gIFJVTEVTRVQgPSAncnVsZXNldCcsXG4gIFJVTEVTID0gJ3J1bGVzJyxcbiAgREVDT0RFUlMgPSAnZGVjb2RlcnMnLFxuICBDREJfTElTVFMgPSAnbGlzdHMnLFxuICBHUk9VUFMgPSAnZ3JvdXBzJyxcbiAgQ09ORklHVVJBVElPTiA9ICdjb25maWd1cmF0aW9uJyxcbiAgU1RBVFVTX0FORF9SRVBPUlRTID0gJ3N0YXR1c1JlcG9ydHMnLFxuICBTVEFUVVMgPSAnc3RhdHVzJyxcbiAgQ0xVU1RFUiA9ICdtb25pdG9yaW5nJyxcbiAgTE9HUyA9ICdsb2dzJyxcbiAgUkVQT1JUSU5HID0gJ3JlcG9ydGluZycsXG4gIFNUQVRJU1RJQ1MgPSAnc3RhdGlzdGljcycsXG59XG5cbmV4cG9ydCBlbnVtIFdBWlVIX01FTlVfVE9PTFNfU0VDVElPTlNfSUQge1xuICBBUElfQ09OU09MRSA9ICdkZXZUb29scycsXG4gIFJVTEVTRVRfVEVTVCA9ICdsb2d0ZXN0Jyxcbn1cblxuZXhwb3J0IGVudW0gV0FaVUhfTUVOVV9TRUNVUklUWV9TRUNUSU9OU19JRCB7XG4gIFVTRVJTID0gJ3VzZXJzJyxcbiAgUk9MRVMgPSAncm9sZXMnLFxuICBQT0xJQ0lFUyA9ICdwb2xpY2llcycsXG4gIFJPTEVTX01BUFBJTkcgPSAncm9sZU1hcHBpbmcnLFxufVxuXG5leHBvcnQgZW51bSBXQVpVSF9NRU5VX1NFVFRJTkdTX1NFQ1RJT05TX0lEIHtcbiAgU0VUVElOR1MgPSAnc2V0dGluZ3MnLFxuICBBUElfQ09ORklHVVJBVElPTiA9ICdhcGknLFxuICBNT0RVTEVTID0gJ21vZHVsZXMnLFxuICBTQU1QTEVfREFUQSA9ICdzYW1wbGVfZGF0YScsXG4gIENPTkZJR1VSQVRJT04gPSAnY29uZmlndXJhdGlvbicsXG4gIExPR1MgPSAnbG9ncycsXG4gIE1JU0NFTExBTkVPVVMgPSAnbWlzY2VsbGFuZW91cycsXG4gIEFCT1VUID0gJ2Fib3V0Jyxcbn1cblxuZXhwb3J0IGNvbnN0IEFVVEhPUklaRURfQUdFTlRTID0gJ2F1dGhvcml6ZWQtYWdlbnRzJztcblxuLy8gV2F6dWggbGlua3NcbmV4cG9ydCBjb25zdCBXQVpVSF9MSU5LX0dJVEhVQiA9ICdodHRwczovL2dpdGh1Yi5jb20vd2F6dWgnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0xJTktfR09PR0xFX0dST1VQUyA9XG4gICdodHRwczovL2dyb3Vwcy5nb29nbGUuY29tL2ZvcnVtLyMhZm9ydW0vd2F6dWgnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0xJTktfU0xBQ0sgPSAnaHR0cHM6Ly93YXp1aC5jb20vY29tbXVuaXR5L2pvaW4tdXMtb24tc2xhY2snO1xuXG5leHBvcnQgY29uc3QgSEVBTFRIX0NIRUNLID0gJ2hlYWx0aC1jaGVjayc7XG5cbi8vIEhlYWx0aCBjaGVja1xuZXhwb3J0IGNvbnN0IEhFQUxUSF9DSEVDS19SRURJUkVDVElPTl9USU1FID0gMzAwOyAvL21zXG5cbi8vIFBsdWdpbiBwbGF0Zm9ybSBzZXR0aW5nc1xuLy8gRGVmYXVsdCB0aW1lRmlsdGVyIHNldCBieSB0aGUgYXBwXG5leHBvcnQgY29uc3QgV0FaVUhfUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfVElNRV9GSUxURVIgPSB7XG4gIGZyb206ICdub3ctMjRoJyxcbiAgdG86ICdub3cnLFxufTtcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fU0VUVElOR19OQU1FX1RJTUVfRklMVEVSID1cbiAgJ3RpbWVwaWNrZXI6dGltZURlZmF1bHRzJztcblxuLy8gRGVmYXVsdCBtYXhCdWNrZXRzIHNldCBieSB0aGUgYXBwXG5leHBvcnQgY29uc3QgV0FaVUhfUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTUFYX0JVQ0tFVFMgPSAyMDAwMDA7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTkFNRV9NQVhfQlVDS0VUUyA9ICd0aW1lbGluZTptYXhfYnVja2V0cyc7XG5cbi8vIERlZmF1bHQgbWV0YUZpZWxkcyBzZXQgYnkgdGhlIGFwcFxuZXhwb3J0IGNvbnN0IFdBWlVIX1BMVUdJTl9QTEFURk9STV9TRVRUSU5HX01FVEFGSUVMRFMgPSBbJ19zb3VyY2UnLCAnX2luZGV4J107XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTkFNRV9NRVRBRklFTERTID0gJ21ldGFGaWVsZHMnO1xuXG4vLyBMb2dnZXJcbmV4cG9ydCBjb25zdCBVSV9MT0dHRVJfTEVWRUxTID0ge1xuICBXQVJOSU5HOiAnV0FSTklORycsXG4gIElORk86ICdJTkZPJyxcbiAgRVJST1I6ICdFUlJPUicsXG59O1xuXG5leHBvcnQgY29uc3QgVUlfVE9BU1RfQ09MT1IgPSB7XG4gIFNVQ0NFU1M6ICdzdWNjZXNzJyxcbiAgV0FSTklORzogJ3dhcm5pbmcnLFxuICBEQU5HRVI6ICdkYW5nZXInLFxufTtcblxuLy8gQXNzZXRzXG5leHBvcnQgY29uc3QgQVNTRVRTX0JBU0VfVVJMX1BSRUZJWCA9ICcvcGx1Z2lucy93YXp1aC9hc3NldHMvJztcbmV4cG9ydCBjb25zdCBBU1NFVFNfUFVCTElDX1VSTCA9ICcvcGx1Z2lucy93YXp1aC9wdWJsaWMvYXNzZXRzLyc7XG5cbi8vIFJlcG9ydHNcbmV4cG9ydCBjb25zdCBSRVBPUlRTX0xPR09fSU1BR0VfQVNTRVRTX1JFTEFUSVZFX1BBVEggPVxuICAnaW1hZ2VzL2xvZ29fcmVwb3J0cy5wbmcnO1xuZXhwb3J0IGNvbnN0IFJFUE9SVFNfUFJJTUFSWV9DT0xPUiA9ICcjMjU2QkQxJztcbmV4cG9ydCBjb25zdCBSRVBPUlRTX1BBR0VfRk9PVEVSX1RFWFQgPSAnQ29weXJpZ2h0IMKpIDIwMjMgV2F6dWgsIEluYy4nO1xuZXhwb3J0IGNvbnN0IFJFUE9SVFNfUEFHRV9IRUFERVJfVEVYVCA9ICdpbmZvQHdhenVoLmNvbVxcbmh0dHBzOi8vd2F6dWguY29tJztcblxuLy8gUGx1Z2luIHBsYXRmb3JtXG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX05BTUUgPSAnV2F6dWggZGFzaGJvYXJkJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fQkFTRV9JTlNUQUxMQVRJT05fUEFUSCA9XG4gICcvdXNyL3NoYXJlL3dhenVoLWRhc2hib2FyZC9kYXRhL3dhenVoLyc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX0lOU1RBTExBVElPTl9VU0VSID0gJ3dhenVoLWRhc2hib2FyZCc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX0lOU1RBTExBVElPTl9VU0VSX0dST1VQID0gJ3dhenVoLWRhc2hib2FyZCc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1dBWlVIX0RPQ1VNRU5UQVRJT05fVVJMX1BBVEhfVVBHUkFERV9QTEFURk9STSA9XG4gICd1cGdyYWRlLWd1aWRlJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9UUk9VQkxFU0hPT1RJTkcgPVxuICAndXNlci1tYW51YWwvd2F6dWgtZGFzaGJvYXJkL3Ryb3VibGVzaG9vdGluZy5odG1sJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9BUFBfQ09ORklHVVJBVElPTiA9XG4gICd1c2VyLW1hbnVhbC93YXp1aC1kYXNoYm9hcmQvY29uZmlnLWZpbGUuaHRtbCc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1VSTF9HVUlERSA9XG4gICdodHRwczovL29wZW5zZWFyY2gub3JnL2RvY3MvMi4xMC9hYm91dCc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1VSTF9HVUlERV9USVRMRSA9ICdPcGVuU2VhcmNoIGd1aWRlJztcblxuZXhwb3J0IGNvbnN0IFBMVUdJTl9QTEFURk9STV9SRVFVRVNUX0hFQURFUlMgPSB7XG4gICdvc2QteHNyZic6ICdraWJhbmEnLFxufTtcblxuLy8gUGx1Z2luIGFwcFxuZXhwb3J0IGNvbnN0IFBMVUdJTl9BUFBfTkFNRSA9ICdXYXp1aCBkYXNoYm9hcmQnO1xuXG4vLyBVSVxuZXhwb3J0IGNvbnN0IFVJX0NPTE9SX1NUQVRVUyA9IHtcbiAgc3VjY2VzczogJyMwMDc4NzEnLFxuICBkYW5nZXI6ICcjQkQyNzFFJyxcbiAgd2FybmluZzogJyNGRUM1MTQnLFxuICBkaXNhYmxlZDogJyM2NDZBNzcnLFxuICBpbmZvOiAnIzYwOTJDMCcsXG4gIGRlZmF1bHQ6ICcjMDAwMDAwJyxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBBUElfTkFNRV9BR0VOVF9TVEFUVVMgPSB7XG4gIEFDVElWRTogJ2FjdGl2ZScsXG4gIERJU0NPTk5FQ1RFRDogJ2Rpc2Nvbm5lY3RlZCcsXG4gIFBFTkRJTkc6ICdwZW5kaW5nJyxcbiAgTkVWRVJfQ09OTkVDVEVEOiAnbmV2ZXJfY29ubmVjdGVkJyxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBVSV9DT0xPUl9BR0VOVF9TVEFUVVMgPSB7XG4gIFtBUElfTkFNRV9BR0VOVF9TVEFUVVMuQUNUSVZFXTogVUlfQ09MT1JfU1RBVFVTLnN1Y2Nlc3MsXG4gIFtBUElfTkFNRV9BR0VOVF9TVEFUVVMuRElTQ09OTkVDVEVEXTogVUlfQ09MT1JfU1RBVFVTLmRhbmdlcixcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5QRU5ESU5HXTogVUlfQ09MT1JfU1RBVFVTLndhcm5pbmcsXG4gIFtBUElfTkFNRV9BR0VOVF9TVEFUVVMuTkVWRVJfQ09OTkVDVEVEXTogVUlfQ09MT1JfU1RBVFVTLmRpc2FibGVkLFxuICBkZWZhdWx0OiBVSV9DT0xPUl9TVEFUVVMuZGVmYXVsdCxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBVSV9MQUJFTF9OQU1FX0FHRU5UX1NUQVRVUyA9IHtcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5BQ1RJVkVdOiAnQWN0aXZlJyxcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5ESVNDT05ORUNURURdOiAnRGlzY29ubmVjdGVkJyxcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5QRU5ESU5HXTogJ1BlbmRpbmcnLFxuICBbQVBJX05BTUVfQUdFTlRfU1RBVFVTLk5FVkVSX0NPTk5FQ1RFRF06ICdOZXZlciBjb25uZWN0ZWQnLFxuICBkZWZhdWx0OiAnVW5rbm93bicsXG59IGFzIGNvbnN0O1xuXG5leHBvcnQgY29uc3QgVUlfT1JERVJfQUdFTlRfU1RBVFVTID0gW1xuICBBUElfTkFNRV9BR0VOVF9TVEFUVVMuQUNUSVZFLFxuICBBUElfTkFNRV9BR0VOVF9TVEFUVVMuRElTQ09OTkVDVEVELFxuICBBUElfTkFNRV9BR0VOVF9TVEFUVVMuUEVORElORyxcbiAgQVBJX05BTUVfQUdFTlRfU1RBVFVTLk5FVkVSX0NPTk5FQ1RFRCxcbl07XG5cbmV4cG9ydCBjb25zdCBBR0VOVF9TWU5DRURfU1RBVFVTID0ge1xuICBTWU5DRUQ6ICdzeW5jZWQnLFxuICBOT1RfU1lOQ0VEOiAnbm90IHN5bmNlZCcsXG59O1xuXG4vLyBUaGUgc3RhdHVzIGNvZGUgY2FuIGJlIHNlZW4gaGVyZSBodHRwczovL2dpdGh1Yi5jb20vd2F6dWgvd2F6dWgvYmxvYi82ODYwNjhhMWYwNWQ4MDZiMmUzYjNkNjMzYTc2NTMyMGFlN2FlMTE0L3NyYy93YXp1aF9kYi93ZGIuaCNMNTUtTDYxXG5cbmV4cG9ydCBjb25zdCBBR0VOVF9TVEFUVVNfQ09ERSA9IFtcbiAge1xuICAgIFNUQVRVU19DT0RFOiAwLFxuICAgIFNUQVRVU19ERVNDUklQVElPTjogJ0FnZW50IGlzIGNvbm5lY3RlZCcsXG4gIH0sXG4gIHtcbiAgICBTVEFUVVNfQ09ERTogMSxcbiAgICBTVEFUVVNfREVTQ1JJUFRJT046ICdJbnZhbGlkIGFnZW50IHZlcnNpb24nLFxuICB9LFxuICB7XG4gICAgU1RBVFVTX0NPREU6IDIsXG4gICAgU1RBVFVTX0RFU0NSSVBUSU9OOiAnRXJyb3IgcmV0cmlldmluZyB2ZXJzaW9uJyxcbiAgfSxcbiAge1xuICAgIFNUQVRVU19DT0RFOiAzLFxuICAgIFNUQVRVU19ERVNDUklQVElPTjogJ1NodXRkb3duIG1lc3NhZ2UgcmVjZWl2ZWQnLFxuICB9LFxuICB7XG4gICAgU1RBVFVTX0NPREU6IDQsXG4gICAgU1RBVFVTX0RFU0NSSVBUSU9OOiAnRGlzY29ubmVjdGVkIGJlY2F1c2Ugbm8ga2VlcGFsaXZlIHJlY2VpdmVkJyxcbiAgfSxcbiAge1xuICAgIFNUQVRVU19DT0RFOiA1LFxuICAgIFNUQVRVU19ERVNDUklQVElPTjogJ0Nvbm5lY3Rpb24gcmVzZXQgYnkgbWFuYWdlcicsXG4gIH0sXG5dO1xuXG4vLyBEb2N1bWVudGF0aW9uXG5leHBvcnQgY29uc3QgRE9DVU1FTlRBVElPTl9XRUJfQkFTRV9VUkwgPSAnaHR0cHM6Ly9kb2N1bWVudGF0aW9uLndhenVoLmNvbSc7XG5cbi8vIERlZmF1bHQgRWxhc3RpY3NlYXJjaCB1c2VyIG5hbWUgY29udGV4dFxuZXhwb3J0IGNvbnN0IEVMQVNUSUNfTkFNRSA9ICdlbGFzdGljJztcblxuLy8gRGVmYXVsdCBXYXp1aCBpbmRleGVyIG5hbWVcbmV4cG9ydCBjb25zdCBXQVpVSF9JTkRFWEVSX05BTUUgPSAnV2F6dWggaW5kZXhlcic7XG5cbi8vIE5vdCB0aW1lRmllbGROYW1lIG9uIGluZGV4IHBhdHRlcm5cbmV4cG9ydCBjb25zdCBOT1RfVElNRV9GSUVMRF9OQU1FX0lOREVYX1BBVFRFUk4gPVxuICAnbm90X3RpbWVfZmllbGRfbmFtZV9pbmRleF9wYXR0ZXJuJztcblxuLy8gQ3VzdG9taXphdGlvblxuZXhwb3J0IGNvbnN0IENVU1RPTUlaQVRJT05fRU5EUE9JTlRfUEFZTE9BRF9VUExPQURfQ1VTVE9NX0ZJTEVfTUFYSU1VTV9CWVRFUyA9IDEwNDg1NzY7XG5cbi8vIFBsdWdpbiBzZXR0aW5nc1xuZXhwb3J0IGVudW0gU2V0dGluZ0NhdGVnb3J5IHtcbiAgR0VORVJBTCxcbiAgSEVBTFRIX0NIRUNLLFxuICBNT05JVE9SSU5HLFxuICBTVEFUSVNUSUNTLFxuICBWVUxORVJBQklMSVRJRVMsXG4gIFNFQ1VSSVRZLFxuICBDVVNUT01JWkFUSU9OLFxufVxuXG50eXBlIFRQbHVnaW5TZXR0aW5nT3B0aW9uc1RleHRBcmVhID0ge1xuICBtYXhSb3dzPzogbnVtYmVyO1xuICBtaW5Sb3dzPzogbnVtYmVyO1xuICBtYXhMZW5ndGg/OiBudW1iZXI7XG59O1xuXG50eXBlIFRQbHVnaW5TZXR0aW5nT3B0aW9uc1NlbGVjdCA9IHtcbiAgc2VsZWN0OiB7IHRleHQ6IHN0cmluZzsgdmFsdWU6IGFueSB9W107XG59O1xuXG50eXBlIFRQbHVnaW5TZXR0aW5nT3B0aW9uc0VkaXRvciA9IHtcbiAgZWRpdG9yOiB7XG4gICAgbGFuZ3VhZ2U6IHN0cmluZztcbiAgfTtcbn07XG5cbnR5cGUgVFBsdWdpblNldHRpbmdPcHRpb25zRmlsZSA9IHtcbiAgZmlsZToge1xuICAgIHR5cGU6ICdpbWFnZSc7XG4gICAgZXh0ZW5zaW9ucz86IHN0cmluZ1tdO1xuICAgIHNpemU/OiB7XG4gICAgICBtYXhCeXRlcz86IG51bWJlcjtcbiAgICAgIG1pbkJ5dGVzPzogbnVtYmVyO1xuICAgIH07XG4gICAgcmVjb21tZW5kZWQ/OiB7XG4gICAgICBkaW1lbnNpb25zPzoge1xuICAgICAgICB3aWR0aDogbnVtYmVyO1xuICAgICAgICBoZWlnaHQ6IG51bWJlcjtcbiAgICAgICAgdW5pdDogc3RyaW5nO1xuICAgICAgfTtcbiAgICB9O1xuICAgIHN0b3JlPzoge1xuICAgICAgcmVsYXRpdmVQYXRoRmlsZVN5c3RlbTogc3RyaW5nO1xuICAgICAgZmlsZW5hbWU6IHN0cmluZztcbiAgICAgIHJlc29sdmVTdGF0aWNVUkw6IChmaWxlbmFtZTogc3RyaW5nKSA9PiBzdHJpbmc7XG4gICAgfTtcbiAgfTtcbn07XG5cbnR5cGUgVFBsdWdpblNldHRpbmdPcHRpb25zTnVtYmVyID0ge1xuICBudW1iZXI6IHtcbiAgICBtaW4/OiBudW1iZXI7XG4gICAgbWF4PzogbnVtYmVyO1xuICAgIGludGVnZXI/OiBib29sZWFuO1xuICB9O1xufTtcblxudHlwZSBUUGx1Z2luU2V0dGluZ09wdGlvbnNTd2l0Y2ggPSB7XG4gIHN3aXRjaDoge1xuICAgIHZhbHVlczoge1xuICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw/OiBzdHJpbmc7IHZhbHVlOiBhbnkgfTtcbiAgICAgIGVuYWJsZWQ6IHsgbGFiZWw/OiBzdHJpbmc7IHZhbHVlOiBhbnkgfTtcbiAgICB9O1xuICB9O1xufTtcblxuZXhwb3J0IGVudW0gRXBsdWdpblNldHRpbmdUeXBlIHtcbiAgdGV4dCA9ICd0ZXh0JyxcbiAgdGV4dGFyZWEgPSAndGV4dGFyZWEnLFxuICBzd2l0Y2ggPSAnc3dpdGNoJyxcbiAgbnVtYmVyID0gJ251bWJlcicsXG4gIGVkaXRvciA9ICdlZGl0b3InLFxuICBzZWxlY3QgPSAnc2VsZWN0JyxcbiAgZmlsZXBpY2tlciA9ICdmaWxlcGlja2VyJyxcbn1cblxuZXhwb3J0IHR5cGUgVFBsdWdpblNldHRpbmcgPSB7XG4gIC8vIERlZmluZSB0aGUgdGV4dCBkaXNwbGF5ZWQgaW4gdGhlIFVJLlxuICB0aXRsZTogc3RyaW5nO1xuICAvLyBEZXNjcmlwdGlvbi5cbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgLy8gQ2F0ZWdvcnkuXG4gIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnk7XG4gIC8vIFR5cGUuXG4gIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZTtcbiAgLy8gRGVmYXVsdCB2YWx1ZS5cbiAgZGVmYXVsdFZhbHVlOiBhbnk7XG4gIC8vIERlZmF1bHQgdmFsdWUgaWYgaXQgaXMgbm90IHNldC4gSXQgaGFzIHByZWZlcmVuY2Ugb3ZlciBgZGVmYXVsdGAuXG4gIGRlZmF1bHRWYWx1ZUlmTm90U2V0PzogYW55O1xuICAvLyBDb25maWd1cmFibGUgZnJvbSB0aGUgY29uZmlndXJhdGlvbiBmaWxlLlxuICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiBib29sZWFuO1xuICAvLyBDb25maWd1cmFibGUgZnJvbSB0aGUgVUkgKFNldHRpbmdzL0NvbmZpZ3VyYXRpb24pLlxuICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogYm9vbGVhbjtcbiAgLy8gTW9kaWZ5IHRoZSBzZXR0aW5nIHJlcXVpcmVzIHJ1bm5pbmcgdGhlIHBsdWdpbiBoZWFsdGggY2hlY2sgKGZyb250ZW5kKS5cbiAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s/OiBib29sZWFuO1xuICAvLyBNb2RpZnkgdGhlIHNldHRpbmcgcmVxdWlyZXMgcmVsb2FkaW5nIHRoZSBicm93c2VyIHRhYiAoZnJvbnRlbmQpLlxuICByZXF1aXJlc1JlbG9hZGluZ0Jyb3dzZXJUYWI/OiBib29sZWFuO1xuICAvLyBNb2RpZnkgdGhlIHNldHRpbmcgcmVxdWlyZXMgcmVzdGFydGluZyB0aGUgcGx1Z2luIHBsYXRmb3JtIHRvIHRha2UgZWZmZWN0LlxuICByZXF1aXJlc1Jlc3RhcnRpbmdQbHVnaW5QbGF0Zm9ybT86IGJvb2xlYW47XG4gIC8vIERlZmluZSBvcHRpb25zIHJlbGF0ZWQgdG8gdGhlIGB0eXBlYC5cbiAgb3B0aW9ucz86XG4gICAgfCBUUGx1Z2luU2V0dGluZ09wdGlvbnNFZGl0b3JcbiAgICB8IFRQbHVnaW5TZXR0aW5nT3B0aW9uc0ZpbGVcbiAgICB8IFRQbHVnaW5TZXR0aW5nT3B0aW9uc051bWJlclxuICAgIHwgVFBsdWdpblNldHRpbmdPcHRpb25zU2VsZWN0XG4gICAgfCBUUGx1Z2luU2V0dGluZ09wdGlvbnNTd2l0Y2hcbiAgICB8IFRQbHVnaW5TZXR0aW5nT3B0aW9uc1RleHRBcmVhO1xuICAvLyBUcmFuc2Zvcm0gdGhlIGlucHV0IHZhbHVlLiBUaGUgcmVzdWx0IGlzIHNhdmVkIGluIHRoZSBmb3JtIGdsb2JhbCBzdGF0ZSBvZiBTZXR0aW5ncy9Db25maWd1cmF0aW9uXG4gIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlPzogKHZhbHVlOiBhbnkpID0+IGFueTtcbiAgLy8gVHJhbnNmb3JtIHRoZSBjb25maWd1cmF0aW9uIHZhbHVlIG9yIGRlZmF1bHQgYXMgaW5pdGlhbCB2YWx1ZSBmb3IgdGhlIGlucHV0IGluIFNldHRpbmdzL0NvbmZpZ3VyYXRpb25cbiAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlPzogKHZhbHVlOiBhbnkpID0+IGFueTtcbiAgLy8gVHJhbnNmb3JtIHRoZSBpbnB1dCB2YWx1ZSBjaGFuZ2VkIGluIHRoZSBmb3JtIG9mIFNldHRpbmdzL0NvbmZpZ3VyYXRpb24gYW5kIHJldHVybmVkIGluIHRoZSBgY2hhbmdlZGAgcHJvcGVydHkgb2YgdGhlIGhvb2sgdXNlRm9ybVxuICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU/OiAodmFsdWU6IGFueSkgPT4gYW55O1xuICAvLyBWYWxpZGF0ZSB0aGUgdmFsdWUgaW4gdGhlIGZvcm0gb2YgU2V0dGluZ3MvQ29uZmlndXJhdGlvbi4gSXQgcmV0dXJucyBhIHN0cmluZyBpZiB0aGVyZSBpcyBzb21lIHZhbGlkYXRpb24gZXJyb3IuXG4gIHZhbGlkYXRlPzogKHZhbHVlOiBhbnkpID0+IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgLy8gVmFsaWRhdGUgZnVuY3Rpb24gY3JlYXRvciB0byB2YWxpZGF0ZSB0aGUgc2V0dGluZyBpbiB0aGUgYmFja2VuZC4gSXQgdXNlcyBgc2NoZW1hYCBvZiB0aGUgYEBrYm4vY29uZmlnLXNjaGVtYWAgcGFja2FnZS5cbiAgdmFsaWRhdGVCYWNrZW5kPzogKHNjaGVtYTogYW55KSA9PiAodmFsdWU6IHVua25vd24pID0+IHN0cmluZyB8IHVuZGVmaW5lZDtcbn07XG5cbmV4cG9ydCB0eXBlIFRQbHVnaW5TZXR0aW5nV2l0aEtleSA9IFRQbHVnaW5TZXR0aW5nICYgeyBrZXk6IFRQbHVnaW5TZXR0aW5nS2V5IH07XG5leHBvcnQgdHlwZSBUUGx1Z2luU2V0dGluZ0NhdGVnb3J5ID0ge1xuICB0aXRsZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgZG9jdW1lbnRhdGlvbkxpbms/OiBzdHJpbmc7XG4gIHJlbmRlck9yZGVyPzogbnVtYmVyO1xufTtcblxuZXhwb3J0IGNvbnN0IFBMVUdJTl9TRVRUSU5HU19DQVRFR09SSUVTOiB7XG4gIFtjYXRlZ29yeTogbnVtYmVyXTogVFBsdWdpblNldHRpbmdDYXRlZ29yeTtcbn0gPSB7XG4gIFtTZXR0aW5nQ2F0ZWdvcnkuSEVBTFRIX0NIRUNLXToge1xuICAgIHRpdGxlOiAnSGVhbHRoIGNoZWNrJyxcbiAgICBkZXNjcmlwdGlvbjogXCJDaGVja3Mgd2lsbCBiZSBleGVjdXRlZCBieSB0aGUgYXBwJ3MgSGVhbHRoY2hlY2suXCIsXG4gICAgcmVuZGVyT3JkZXI6IFNldHRpbmdDYXRlZ29yeS5IRUFMVEhfQ0hFQ0ssXG4gIH0sXG4gIFtTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTF06IHtcbiAgICB0aXRsZTogJ0dlbmVyYWwnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0Jhc2ljIGFwcCBzZXR0aW5ncyByZWxhdGVkIHRvIGFsZXJ0cyBpbmRleCBwYXR0ZXJuLCBoaWRlIHRoZSBtYW5hZ2VyIGFsZXJ0cyBpbiB0aGUgZGFzaGJvYXJkcywgbG9ncyBsZXZlbCBhbmQgbW9yZS4nLFxuICAgIHJlbmRlck9yZGVyOiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgfSxcbiAgW1NldHRpbmdDYXRlZ29yeS5TRUNVUklUWV06IHtcbiAgICB0aXRsZTogJ1NlY3VyaXR5JyxcbiAgICBkZXNjcmlwdGlvbjogJ0FwcGxpY2F0aW9uIHNlY3VyaXR5IG9wdGlvbnMgc3VjaCBhcyB1bmF1dGhvcml6ZWQgcm9sZXMuJyxcbiAgICByZW5kZXJPcmRlcjogU2V0dGluZ0NhdGVnb3J5LlNFQ1VSSVRZLFxuICB9LFxuICBbU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkddOiB7XG4gICAgdGl0bGU6ICdUYXNrOk1vbml0b3JpbmcnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ09wdGlvbnMgcmVsYXRlZCB0byB0aGUgYWdlbnQgc3RhdHVzIG1vbml0b3Jpbmcgam9iIGFuZCBpdHMgc3RvcmFnZSBpbiBpbmRleGVzLicsXG4gICAgcmVuZGVyT3JkZXI6IFNldHRpbmdDYXRlZ29yeS5NT05JVE9SSU5HLFxuICB9LFxuICBbU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1NdOiB7XG4gICAgdGl0bGU6ICdUYXNrOlN0YXRpc3RpY3MnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ09wdGlvbnMgcmVsYXRlZCB0byB0aGUgZGFlbW9ucyBtYW5hZ2VyIG1vbml0b3Jpbmcgam9iIGFuZCB0aGVpciBzdG9yYWdlIGluIGluZGV4ZXMuJyxcbiAgICByZW5kZXJPcmRlcjogU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1MsXG4gIH0sXG4gIFtTZXR0aW5nQ2F0ZWdvcnkuVlVMTkVSQUJJTElUSUVTXToge1xuICAgIHRpdGxlOiAnVnVsbmVyYWJpbGl0aWVzJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdPcHRpb25zIHJlbGF0ZWQgdG8gdGhlIGFnZW50IHZ1bG5lcmFiaWxpdGllcyBtb25pdG9yaW5nIGpvYiBhbmQgaXRzIHN0b3JhZ2UgaW4gaW5kZXhlcy4nLFxuICAgIHJlbmRlck9yZGVyOiBTZXR0aW5nQ2F0ZWdvcnkuVlVMTkVSQUJJTElUSUVTLFxuICB9LFxuICBbU2V0dGluZ0NhdGVnb3J5LkNVU1RPTUlaQVRJT05dOiB7XG4gICAgdGl0bGU6ICdDdXN0b20gYnJhbmRpbmcnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0lmIHlvdSB3YW50IHRvIHVzZSBjdXN0b20gYnJhbmRpbmcgZWxlbWVudHMgc3VjaCBhcyBsb2dvcywgeW91IGNhbiBkbyBzbyBieSBlZGl0aW5nIHRoZSBzZXR0aW5ncyBiZWxvdy4nLFxuICAgIGRvY3VtZW50YXRpb25MaW5rOiAndXNlci1tYW51YWwvd2F6dWgtZGFzaGJvYXJkL3doaXRlLWxhYmVsaW5nLmh0bWwnLFxuICAgIHJlbmRlck9yZGVyOiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgfSxcbn07XG5cbmV4cG9ydCBjb25zdCBQTFVHSU5fU0VUVElOR1M6IHsgW2tleTogc3RyaW5nXTogVFBsdWdpblNldHRpbmcgfSA9IHtcbiAgJ2FsZXJ0cy5zYW1wbGUucHJlZml4Jzoge1xuICAgIHRpdGxlOiAnU2FtcGxlIGFsZXJ0cyBwcmVmaXgnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0RlZmluZSB0aGUgaW5kZXggbmFtZSBwcmVmaXggb2Ygc2FtcGxlIGFsZXJ0cy4gSXQgbXVzdCBtYXRjaCB0aGUgdGVtcGxhdGUgdXNlZCBieSB0aGUgaW5kZXggcGF0dGVybiB0byBhdm9pZCB1bmtub3duIGZpZWxkcyBpbiBkYXNoYm9hcmRzLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5HRU5FUkFMLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS50ZXh0LFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfU0FNUExFX0FMRVJUX1BSRUZJWCxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrOiB0cnVlLFxuICAgIC8vIFZhbGlkYXRpb246IGh0dHBzOi8vZ2l0aHViLmNvbS9lbGFzdGljL2VsYXN0aWNzZWFyY2gvYmxvYi92Ny4xMC4yL2RvY3MvcmVmZXJlbmNlL2luZGljZXMvY3JlYXRlLWluZGV4LmFzY2lpZG9jXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm9TcGFjZXMsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub1N0YXJ0c1dpdGhTdHJpbmcoJy0nLCAnXycsICcrJywgJy4nKSxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vdEludmFsaWRDaGFyYWN0ZXJzKFxuICAgICAgICAnXFxcXCcsXG4gICAgICAgICcvJyxcbiAgICAgICAgJz8nLFxuICAgICAgICAnXCInLFxuICAgICAgICAnPCcsXG4gICAgICAgICc+JyxcbiAgICAgICAgJ3wnLFxuICAgICAgICAnLCcsXG4gICAgICAgICcjJyxcbiAgICAgICAgJyonLFxuICAgICAgKSxcbiAgICApLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5zdHJpbmcoeyB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZSB9KTtcbiAgICB9LFxuICB9LFxuICAnY2hlY2tzLmFwaSc6IHtcbiAgICB0aXRsZTogJ0FQSSBjb25uZWN0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ0VuYWJsZSBvciBkaXNhYmxlIHRoZSBBUEkgaGVhbHRoIGNoZWNrIHdoZW4gb3BlbmluZyB0aGUgYXBwLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5IRUFMVEhfQ0hFQ0ssXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcsXG4gICAgKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG4gICAgfSxcbiAgfSxcbiAgJ2NoZWNrcy5maWVsZHMnOiB7XG4gICAgdGl0bGU6ICdLbm93biBmaWVsZHMnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0VuYWJsZSBvciBkaXNhYmxlIHRoZSBrbm93biBmaWVsZHMgaGVhbHRoIGNoZWNrIHdoZW4gb3BlbmluZyB0aGUgYXBwLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5IRUFMVEhfQ0hFQ0ssXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcsXG4gICAgKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG4gICAgfSxcbiAgfSxcbiAgJ2NoZWNrcy5tYXhCdWNrZXRzJzoge1xuICAgIHRpdGxlOiAnU2V0IG1heCBidWNrZXRzIHRvIDIwMDAwMCcsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnQ2hhbmdlIHRoZSBkZWZhdWx0IHZhbHVlIG9mIHRoZSBwbHVnaW4gcGxhdGZvcm0gbWF4IGJ1Y2tldHMgY29uZmlndXJhdGlvbi4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuSEVBTFRIX0NIRUNLLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uIChcbiAgICAgIHZhbHVlOiBib29sZWFuIHwgc3RyaW5nLFxuICAgICk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuICAgIH0sXG4gIH0sXG4gICdjaGVja3MubWV0YUZpZWxkcyc6IHtcbiAgICB0aXRsZTogJ1JlbW92ZSBtZXRhIGZpZWxkcycsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnQ2hhbmdlIHRoZSBkZWZhdWx0IHZhbHVlIG9mIHRoZSBwbHVnaW4gcGxhdGZvcm0gbWV0YUZpZWxkIGNvbmZpZ3VyYXRpb24uJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyxcbiAgICApOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcbiAgICB9LFxuICB9LFxuICAnY2hlY2tzLnBhdHRlcm4nOiB7XG4gICAgdGl0bGU6ICdJbmRleCBwYXR0ZXJuJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdFbmFibGUgb3IgZGlzYWJsZSB0aGUgaW5kZXggcGF0dGVybiBoZWFsdGggY2hlY2sgd2hlbiBvcGVuaW5nIHRoZSBhcHAuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyxcbiAgICApOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcbiAgICB9LFxuICB9LFxuICAnY2hlY2tzLnNldHVwJzoge1xuICAgIHRpdGxlOiAnQVBJIHZlcnNpb24nLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0VuYWJsZSBvciBkaXNhYmxlIHRoZSBzZXR1cCBoZWFsdGggY2hlY2sgd2hlbiBvcGVuaW5nIHRoZSBhcHAuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyxcbiAgICApOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcbiAgICB9LFxuICB9LFxuICAnY2hlY2tzLnRlbXBsYXRlJzoge1xuICAgIHRpdGxlOiAnSW5kZXggdGVtcGxhdGUnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0VuYWJsZSBvciBkaXNhYmxlIHRoZSB0ZW1wbGF0ZSBoZWFsdGggY2hlY2sgd2hlbiBvcGVuaW5nIHRoZSBhcHAuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyxcbiAgICApOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcbiAgICB9LFxuICB9LFxuICAnY2hlY2tzLnRpbWVGaWx0ZXInOiB7XG4gICAgdGl0bGU6ICdTZXQgdGltZSBmaWx0ZXIgdG8gMjRoJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdDaGFuZ2UgdGhlIGRlZmF1bHQgdmFsdWUgb2YgdGhlIHBsdWdpbiBwbGF0Zm9ybSB0aW1lRmlsdGVyIGNvbmZpZ3VyYXRpb24uJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyxcbiAgICApOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcbiAgICB9LFxuICB9LFxuICAnY3Jvbi5wcmVmaXgnOiB7XG4gICAgdGl0bGU6ICdDcm9uIHByZWZpeCcsXG4gICAgZGVzY3JpcHRpb246ICdEZWZpbmUgdGhlIGluZGV4IHByZWZpeCBvZiBwcmVkZWZpbmVkIGpvYnMuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfUFJFRklYLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgLy8gVmFsaWRhdGlvbjogaHR0cHM6Ly9naXRodWIuY29tL2VsYXN0aWMvZWxhc3RpY3NlYXJjaC9ibG9iL3Y3LjEwLjIvZG9jcy9yZWZlcmVuY2UvaW5kaWNlcy9jcmVhdGUtaW5kZXguYXNjaWlkb2NcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vU3RhcnRzV2l0aFN0cmluZygnLScsICdfJywgJysnLCAnLicpLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm90SW52YWxpZENoYXJhY3RlcnMoXG4gICAgICAgICdcXFxcJyxcbiAgICAgICAgJy8nLFxuICAgICAgICAnPycsXG4gICAgICAgICdcIicsXG4gICAgICAgICc8JyxcbiAgICAgICAgJz4nLFxuICAgICAgICAnfCcsXG4gICAgICAgICcsJyxcbiAgICAgICAgJyMnLFxuICAgICAgICAnKicsXG4gICAgICApLFxuICAgICksXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLnN0cmluZyh7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlIH0pO1xuICAgIH0sXG4gIH0sXG4gICdjcm9uLnN0YXRpc3RpY3MuYXBpcyc6IHtcbiAgICB0aXRsZTogJ0luY2x1ZGVzIEFQSXMnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0VudGVyIHRoZSBJRCBvZiB0aGUgaG9zdHMgeW91IHdhbnQgdG8gc2F2ZSBkYXRhIGZyb20sIGxlYXZlIHRoaXMgZW1wdHkgdG8gcnVuIHRoZSB0YXNrIG9uIGV2ZXJ5IGhvc3QuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1MsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLmVkaXRvcixcbiAgICBkZWZhdWx0VmFsdWU6IFtdLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgZWRpdG9yOiB7XG4gICAgICAgIGxhbmd1YWdlOiAnanNvbicsXG4gICAgICB9LFxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGFueSk6IGFueSB7XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogc3RyaW5nLFxuICAgICk6IGFueSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuanNvbihcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmFycmF5KFxuICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc1N0cmluZyxcbiAgICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgICAgICApLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5hcnJheU9mKFxuICAgICAgICBzY2hlbWEuc3RyaW5nKHtcbiAgICAgICAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgICAgICApLFxuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgfSxcbiAgfSxcbiAgJ2Nyb24uc3RhdGlzdGljcy5pbmRleC5jcmVhdGlvbic6IHtcbiAgICB0aXRsZTogJ0luZGV4IGNyZWF0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ0RlZmluZSB0aGUgaW50ZXJ2YWwgaW4gd2hpY2ggYSBuZXcgaW5kZXggd2lsbCBiZSBjcmVhdGVkLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zZWxlY3QsXG4gICAgb3B0aW9uczoge1xuICAgICAgc2VsZWN0OiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiAnSG91cmx5JyxcbiAgICAgICAgICB2YWx1ZTogJ2gnLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogJ0RhaWx5JyxcbiAgICAgICAgICB2YWx1ZTogJ2QnLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogJ1dlZWtseScsXG4gICAgICAgICAgdmFsdWU6ICd3JyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6ICdNb250aGx5JyxcbiAgICAgICAgICB2YWx1ZTogJ20nLFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICB9LFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0NSRUFUSU9OLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s6IHRydWUsXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLmxpdGVyYWwoXG4gICAgICAgIHRoaXMub3B0aW9ucy5zZWxlY3QubWFwKCh7IHZhbHVlIH0pID0+IHZhbHVlKSxcbiAgICAgICkodmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLm9uZU9mKFxuICAgICAgICB0aGlzLm9wdGlvbnMuc2VsZWN0Lm1hcCgoeyB2YWx1ZSB9KSA9PiBzY2hlbWEubGl0ZXJhbCh2YWx1ZSkpLFxuICAgICAgKTtcbiAgICB9LFxuICB9LFxuICAnY3Jvbi5zdGF0aXN0aWNzLmluZGV4Lm5hbWUnOiB7XG4gICAgdGl0bGU6ICdJbmRleCBuYW1lJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdEZWZpbmUgdGhlIG5hbWUgb2YgdGhlIGluZGV4IGluIHdoaWNoIHRoZSBkb2N1bWVudHMgd2lsbCBiZSBzYXZlZC4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuU1RBVElTVElDUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9OQU1FLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s6IHRydWUsXG4gICAgLy8gVmFsaWRhdGlvbjogaHR0cHM6Ly9naXRodWIuY29tL2VsYXN0aWMvZWxhc3RpY3NlYXJjaC9ibG9iL3Y3LjEwLjIvZG9jcy9yZWZlcmVuY2UvaW5kaWNlcy9jcmVhdGUtaW5kZXguYXNjaWlkb2NcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vU3RhcnRzV2l0aFN0cmluZygnLScsICdfJywgJysnLCAnLicpLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm90SW52YWxpZENoYXJhY3RlcnMoXG4gICAgICAgICdcXFxcJyxcbiAgICAgICAgJy8nLFxuICAgICAgICAnPycsXG4gICAgICAgICdcIicsXG4gICAgICAgICc8JyxcbiAgICAgICAgJz4nLFxuICAgICAgICAnfCcsXG4gICAgICAgICcsJyxcbiAgICAgICAgJyMnLFxuICAgICAgICAnKicsXG4gICAgICApLFxuICAgICksXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLnN0cmluZyh7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlIH0pO1xuICAgIH0sXG4gIH0sXG4gICdjcm9uLnN0YXRpc3RpY3MuaW5kZXgucmVwbGljYXMnOiB7XG4gICAgdGl0bGU6ICdJbmRleCByZXBsaWNhcycsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRGVmaW5lIHRoZSBudW1iZXIgb2YgcmVwbGljYXMgdG8gdXNlIGZvciB0aGUgc3RhdGlzdGljcyBpbmRpY2VzLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5udW1iZXIsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfSU5ESUNFU19SRVBMSUNBUyxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIG51bWJlcjoge1xuICAgICAgICBtaW46IDAsXG4gICAgICAgIGludGVnZXI6IHRydWUsXG4gICAgICB9LFxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogbnVtYmVyLFxuICAgICk6IHN0cmluZyB7XG4gICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IHN0cmluZyxcbiAgICApOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IubnVtYmVyKHRoaXMub3B0aW9ucy5udW1iZXIpKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5udW1iZXIoeyB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZS5iaW5kKHRoaXMpIH0pO1xuICAgIH0sXG4gIH0sXG4gICdjcm9uLnN0YXRpc3RpY3MuaW5kZXguc2hhcmRzJzoge1xuICAgIHRpdGxlOiAnSW5kZXggc2hhcmRzJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdEZWZpbmUgdGhlIG51bWJlciBvZiBzaGFyZHMgdG8gdXNlIGZvciB0aGUgc3RhdGlzdGljcyBpbmRpY2VzLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5udW1iZXIsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiAxLFxuICAgICAgICBpbnRlZ2VyOiB0cnVlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNvbmZpZ3VyYXRpb25WYWx1ZVRvSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogc3RyaW5nLFxuICAgICk6IG51bWJlciB7XG4gICAgICByZXR1cm4gTnVtYmVyKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5udW1iZXIodGhpcy5vcHRpb25zLm51bWJlcikodmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLm51bWJlcih7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlLmJpbmQodGhpcykgfSk7XG4gICAgfSxcbiAgfSxcbiAgJ2Nyb24uc3RhdGlzdGljcy5pbnRlcnZhbCc6IHtcbiAgICB0aXRsZTogJ0ludGVydmFsJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdEZWZpbmUgdGhlIGZyZXF1ZW5jeSBvZiB0YXNrIGV4ZWN1dGlvbiB1c2luZyBjcm9uIHNjaGVkdWxlIGV4cHJlc3Npb25zLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS50ZXh0LFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0NST05fRlJFUSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUmVzdGFydGluZ1BsdWdpblBsYXRmb3JtOiB0cnVlLFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWU6IHN0cmluZykge1xuICAgICAgcmV0dXJuIHZhbGlkYXRlTm9kZUNyb25JbnRlcnZhbCh2YWx1ZSlcbiAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgOiAnSW50ZXJ2YWwgaXMgbm90IHZhbGlkLic7XG4gICAgfSxcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuc3RyaW5nKHsgdmFsaWRhdGU6IHRoaXMudmFsaWRhdGUgfSk7XG4gICAgfSxcbiAgfSxcbiAgJ2Nyb24uc3RhdGlzdGljcy5zdGF0dXMnOiB7XG4gICAgdGl0bGU6ICdTdGF0dXMnLFxuICAgIGRlc2NyaXB0aW9uOiAnRW5hYmxlIG9yIGRpc2FibGUgdGhlIHN0YXRpc3RpY3MgdGFza3MuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1MsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9TVEFUVVMsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcsXG4gICAgKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG4gICAgfSxcbiAgfSxcbiAgJ2N1c3RvbWl6YXRpb24uZW5hYmxlZCc6IHtcbiAgICB0aXRsZTogJ1N0YXR1cycsXG4gICAgZGVzY3JpcHRpb246ICdFbmFibGUgb3IgZGlzYWJsZSB0aGUgY3VzdG9taXphdGlvbi4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUmVsb2FkaW5nQnJvd3NlclRhYjogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcsXG4gICAgKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG4gICAgfSxcbiAgfSxcbiAgJ2N1c3RvbWl6YXRpb24ubG9nby5hcHAnOiB7XG4gICAgdGl0bGU6ICdBcHAgbWFpbiBsb2dvJyxcbiAgICBkZXNjcmlwdGlvbjogYFRoaXMgbG9nbyBpcyB1c2VkIGFzIGxvYWRpbmcgaW5kaWNhdG9yIHdoaWxlIHRoZSB1c2VyIGlzIGxvZ2dpbmcgaW50byBXYXp1aCBBUEkuYCxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkNVU1RPTUlaQVRJT04sXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLmZpbGVwaWNrZXIsXG4gICAgZGVmYXVsdFZhbHVlOiAnJyxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIGZpbGU6IHtcbiAgICAgICAgdHlwZTogJ2ltYWdlJyxcbiAgICAgICAgZXh0ZW5zaW9uczogWycuanBlZycsICcuanBnJywgJy5wbmcnLCAnLnN2ZyddLFxuICAgICAgICBzaXplOiB7XG4gICAgICAgICAgbWF4Qnl0ZXM6XG4gICAgICAgICAgICBDVVNUT01JWkFUSU9OX0VORFBPSU5UX1BBWUxPQURfVVBMT0FEX0NVU1RPTV9GSUxFX01BWElNVU1fQllURVMsXG4gICAgICAgIH0sXG4gICAgICAgIHJlY29tbWVuZGVkOiB7XG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgd2lkdGg6IDMwMCxcbiAgICAgICAgICAgIGhlaWdodDogNzAsXG4gICAgICAgICAgICB1bml0OiAncHgnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHN0b3JlOiB7XG4gICAgICAgICAgcmVsYXRpdmVQYXRoRmlsZVN5c3RlbTogJ3B1YmxpYy9hc3NldHMvY3VzdG9tL2ltYWdlcycsXG4gICAgICAgICAgZmlsZW5hbWU6ICdjdXN0b21pemF0aW9uLmxvZ28uYXBwJyxcbiAgICAgICAgICByZXNvbHZlU3RhdGljVVJMOiAoZmlsZW5hbWU6IHN0cmluZykgPT5cbiAgICAgICAgICAgIGBjdXN0b20vaW1hZ2VzLyR7ZmlsZW5hbWV9P3Y9JHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgLy8gP3Y9JHtEYXRlLm5vdygpfSBpcyB1c2VkIHRvIGZvcmNlIHRoZSBicm93c2VyIHRvIHJlbG9hZCB0aGUgaW1hZ2Ugd2hlbiBhIG5ldyBmaWxlIGlzIHVwbG9hZGVkXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJGaWxlU2l6ZSh7XG4gICAgICAgICAgLi4udGhpcy5vcHRpb25zLmZpbGUuc2l6ZSxcbiAgICAgICAgICBtZWFuaW5nZnVsVW5pdDogdHJ1ZSxcbiAgICAgICAgfSksXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJTdXBwb3J0ZWRFeHRlbnNpb25zKFxuICAgICAgICAgIHRoaXMub3B0aW9ucy5maWxlLmV4dGVuc2lvbnMsXG4gICAgICAgICksXG4gICAgICApKHZhbHVlKTtcbiAgICB9LFxuICB9LFxuICAnY3VzdG9taXphdGlvbi5sb2dvLmhlYWx0aGNoZWNrJzoge1xuICAgIHRpdGxlOiAnSGVhbHRoY2hlY2sgbG9nbycsXG4gICAgZGVzY3JpcHRpb246IGBUaGlzIGxvZ28gaXMgZGlzcGxheWVkIGR1cmluZyB0aGUgSGVhbHRoY2hlY2sgcm91dGluZSBvZiB0aGUgYXBwLmAsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5DVVNUT01JWkFUSU9OLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5maWxlcGlja2VyLFxuICAgIGRlZmF1bHRWYWx1ZTogJycsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBmaWxlOiB7XG4gICAgICAgIHR5cGU6ICdpbWFnZScsXG4gICAgICAgIGV4dGVuc2lvbnM6IFsnLmpwZWcnLCAnLmpwZycsICcucG5nJywgJy5zdmcnXSxcbiAgICAgICAgc2l6ZToge1xuICAgICAgICAgIG1heEJ5dGVzOlxuICAgICAgICAgICAgQ1VTVE9NSVpBVElPTl9FTkRQT0lOVF9QQVlMT0FEX1VQTE9BRF9DVVNUT01fRklMRV9NQVhJTVVNX0JZVEVTLFxuICAgICAgICB9LFxuICAgICAgICByZWNvbW1lbmRlZDoge1xuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHdpZHRoOiAzMDAsXG4gICAgICAgICAgICBoZWlnaHQ6IDcwLFxuICAgICAgICAgICAgdW5pdDogJ3B4JyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBzdG9yZToge1xuICAgICAgICAgIHJlbGF0aXZlUGF0aEZpbGVTeXN0ZW06ICdwdWJsaWMvYXNzZXRzL2N1c3RvbS9pbWFnZXMnLFxuICAgICAgICAgIGZpbGVuYW1lOiAnY3VzdG9taXphdGlvbi5sb2dvLmhlYWx0aGNoZWNrJyxcbiAgICAgICAgICByZXNvbHZlU3RhdGljVVJMOiAoZmlsZW5hbWU6IHN0cmluZykgPT5cbiAgICAgICAgICAgIGBjdXN0b20vaW1hZ2VzLyR7ZmlsZW5hbWV9P3Y9JHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgLy8gP3Y9JHtEYXRlLm5vdygpfSBpcyB1c2VkIHRvIGZvcmNlIHRoZSBicm93c2VyIHRvIHJlbG9hZCB0aGUgaW1hZ2Ugd2hlbiBhIG5ldyBmaWxlIGlzIHVwbG9hZGVkXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJGaWxlU2l6ZSh7XG4gICAgICAgICAgLi4udGhpcy5vcHRpb25zLmZpbGUuc2l6ZSxcbiAgICAgICAgICBtZWFuaW5nZnVsVW5pdDogdHJ1ZSxcbiAgICAgICAgfSksXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJTdXBwb3J0ZWRFeHRlbnNpb25zKFxuICAgICAgICAgIHRoaXMub3B0aW9ucy5maWxlLmV4dGVuc2lvbnMsXG4gICAgICAgICksXG4gICAgICApKHZhbHVlKTtcbiAgICB9LFxuICB9LFxuICAnY3VzdG9taXphdGlvbi5sb2dvLnJlcG9ydHMnOiB7XG4gICAgdGl0bGU6ICdQREYgcmVwb3J0cyBsb2dvJyxcbiAgICBkZXNjcmlwdGlvbjogYFRoaXMgbG9nbyBpcyB1c2VkIGluIHRoZSBQREYgcmVwb3J0cyBnZW5lcmF0ZWQgYnkgdGhlIGFwcC4gSXQncyBwbGFjZWQgYXQgdGhlIHRvcCBsZWZ0IGNvcm5lciBvZiBldmVyeSBwYWdlIG9mIHRoZSBQREYuYCxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkNVU1RPTUlaQVRJT04sXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLmZpbGVwaWNrZXIsXG4gICAgZGVmYXVsdFZhbHVlOiAnJyxcbiAgICBkZWZhdWx0VmFsdWVJZk5vdFNldDogUkVQT1JUU19MT0dPX0lNQUdFX0FTU0VUU19SRUxBVElWRV9QQVRILFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgZmlsZToge1xuICAgICAgICB0eXBlOiAnaW1hZ2UnLFxuICAgICAgICBleHRlbnNpb25zOiBbJy5qcGVnJywgJy5qcGcnLCAnLnBuZyddLFxuICAgICAgICBzaXplOiB7XG4gICAgICAgICAgbWF4Qnl0ZXM6XG4gICAgICAgICAgICBDVVNUT01JWkFUSU9OX0VORFBPSU5UX1BBWUxPQURfVVBMT0FEX0NVU1RPTV9GSUxFX01BWElNVU1fQllURVMsXG4gICAgICAgIH0sXG4gICAgICAgIHJlY29tbWVuZGVkOiB7XG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgd2lkdGg6IDE5MCxcbiAgICAgICAgICAgIGhlaWdodDogNDAsXG4gICAgICAgICAgICB1bml0OiAncHgnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHN0b3JlOiB7XG4gICAgICAgICAgcmVsYXRpdmVQYXRoRmlsZVN5c3RlbTogJ3B1YmxpYy9hc3NldHMvY3VzdG9tL2ltYWdlcycsXG4gICAgICAgICAgZmlsZW5hbWU6ICdjdXN0b21pemF0aW9uLmxvZ28ucmVwb3J0cycsXG4gICAgICAgICAgcmVzb2x2ZVN0YXRpY1VSTDogKGZpbGVuYW1lOiBzdHJpbmcpID0+IGBjdXN0b20vaW1hZ2VzLyR7ZmlsZW5hbWV9YCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuZmlsZVBpY2tlckZpbGVTaXplKHtcbiAgICAgICAgICAuLi50aGlzLm9wdGlvbnMuZmlsZS5zaXplLFxuICAgICAgICAgIG1lYW5pbmdmdWxVbml0OiB0cnVlLFxuICAgICAgICB9KSxcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuZmlsZVBpY2tlclN1cHBvcnRlZEV4dGVuc2lvbnMoXG4gICAgICAgICAgdGhpcy5vcHRpb25zLmZpbGUuZXh0ZW5zaW9ucyxcbiAgICAgICAgKSxcbiAgICAgICkodmFsdWUpO1xuICAgIH0sXG4gIH0sXG4gICdjdXN0b21pemF0aW9uLnJlcG9ydHMuZm9vdGVyJzoge1xuICAgIHRpdGxlOiAnUmVwb3J0cyBmb290ZXInLFxuICAgIGRlc2NyaXB0aW9uOiAnU2V0IHRoZSBmb290ZXIgb2YgdGhlIHJlcG9ydHMuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkNVU1RPTUlaQVRJT04sXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHRhcmVhLFxuICAgIGRlZmF1bHRWYWx1ZTogJycsXG4gICAgZGVmYXVsdFZhbHVlSWZOb3RTZXQ6IFJFUE9SVFNfUEFHRV9GT09URVJfVEVYVCxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHsgbWF4Um93czogMiwgbWF4TGVuZ3RoOiA1MCB9LFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5tdWx0aXBsZUxpbmVzU3RyaW5nKHtcbiAgICAgICAgbWF4Um93czogdGhpcy5vcHRpb25zPy5tYXhSb3dzLFxuICAgICAgICBtYXhMZW5ndGg6IHRoaXMub3B0aW9ucz8ubWF4TGVuZ3RoLFxuICAgICAgfSkodmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLnN0cmluZyh7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlLmJpbmQodGhpcykgfSk7XG4gICAgfSxcbiAgfSxcbiAgJ2N1c3RvbWl6YXRpb24ucmVwb3J0cy5oZWFkZXInOiB7XG4gICAgdGl0bGU6ICdSZXBvcnRzIGhlYWRlcicsXG4gICAgZGVzY3JpcHRpb246ICdTZXQgdGhlIGhlYWRlciBvZiB0aGUgcmVwb3J0cy4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dGFyZWEsXG4gICAgZGVmYXVsdFZhbHVlOiAnJyxcbiAgICBkZWZhdWx0VmFsdWVJZk5vdFNldDogUkVQT1JUU19QQUdFX0hFQURFUl9URVhULFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczogeyBtYXhSb3dzOiAzLCBtYXhMZW5ndGg6IDQwIH0sXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm11bHRpcGxlTGluZXNTdHJpbmcoe1xuICAgICAgICBtYXhSb3dzOiB0aGlzLm9wdGlvbnM/Lm1heFJvd3MsXG4gICAgICAgIG1heExlbmd0aDogdGhpcy5vcHRpb25zPy5tYXhMZW5ndGgsXG4gICAgICB9KSh2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuc3RyaW5nKHsgdmFsaWRhdGU6IHRoaXMudmFsaWRhdGUuYmluZCh0aGlzKSB9KTtcbiAgICB9LFxuICB9LFxuICAnZW5yb2xsbWVudC5kbnMnOiB7XG4gICAgdGl0bGU6ICdFbnJvbGxtZW50IEROUycsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnU3BlY2lmaWVzIHRoZSBXYXp1aCByZWdpc3RyYXRpb24gc2VydmVyLCB1c2VkIGZvciB0aGUgYWdlbnQgZW5yb2xsbWVudC4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dCxcbiAgICBkZWZhdWx0VmFsdWU6ICcnLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5zdHJpbmcoeyB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZSB9KTtcbiAgICB9LFxuICB9LFxuICAnZW5yb2xsbWVudC5wYXNzd29yZCc6IHtcbiAgICB0aXRsZTogJ0Vucm9sbG1lbnQgcGFzc3dvcmQnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ1NwZWNpZmllcyB0aGUgcGFzc3dvcmQgdXNlZCB0byBhdXRoZW50aWNhdGUgZHVyaW5nIHRoZSBhZ2VudCBlbnJvbGxtZW50LicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5HRU5FUkFMLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS50ZXh0LFxuICAgIGRlZmF1bHRWYWx1ZTogJycsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogZmFsc2UsXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLnN0cmluZyh7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlIH0pO1xuICAgIH0sXG4gIH0sXG4gIGhpZGVNYW5hZ2VyQWxlcnRzOiB7XG4gICAgdGl0bGU6ICdIaWRlIG1hbmFnZXIgYWxlcnRzJyxcbiAgICBkZXNjcmlwdGlvbjogJ0hpZGUgdGhlIGFsZXJ0cyBvZiB0aGUgbWFuYWdlciBpbiBldmVyeSBkYXNoYm9hcmQuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IGZhbHNlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSZWxvYWRpbmdCcm93c2VyVGFiOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyxcbiAgICApOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcbiAgICB9LFxuICB9LFxuICAnaXAuaWdub3JlJzoge1xuICAgIHRpdGxlOiAnSW5kZXggcGF0dGVybiBpZ25vcmUnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0Rpc2FibGUgY2VydGFpbiBpbmRleCBwYXR0ZXJuIG5hbWVzIGZyb20gYmVpbmcgYXZhaWxhYmxlIGluIGluZGV4IHBhdHRlcm4gc2VsZWN0b3IuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLmVkaXRvcixcbiAgICBkZWZhdWx0VmFsdWU6IFtdLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgZWRpdG9yOiB7XG4gICAgICAgIGxhbmd1YWdlOiAnanNvbicsXG4gICAgICB9LFxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGFueSk6IGFueSB7XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogc3RyaW5nLFxuICAgICk6IGFueSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9XG4gICAgfSxcbiAgICAvLyBWYWxpZGF0aW9uOiBodHRwczovL2dpdGh1Yi5jb20vZWxhc3RpYy9lbGFzdGljc2VhcmNoL2Jsb2IvdjcuMTAuMi9kb2NzL3JlZmVyZW5jZS9pbmRpY2VzL2NyZWF0ZS1pbmRleC5hc2NpaWRvY1xuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5qc29uKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuYXJyYXkoXG4gICAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzU3RyaW5nLFxuICAgICAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNOb3RFbXB0eVN0cmluZyxcbiAgICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9MaXRlcmFsU3RyaW5nKCcuJywgJy4uJyksXG4gICAgICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub1N0YXJ0c1dpdGhTdHJpbmcoJy0nLCAnXycsICcrJywgJy4nKSxcbiAgICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vdEludmFsaWRDaGFyYWN0ZXJzKFxuICAgICAgICAgICAgICAnXFxcXCcsXG4gICAgICAgICAgICAgICcvJyxcbiAgICAgICAgICAgICAgJz8nLFxuICAgICAgICAgICAgICAnXCInLFxuICAgICAgICAgICAgICAnPCcsXG4gICAgICAgICAgICAgICc+JyxcbiAgICAgICAgICAgICAgJ3wnLFxuICAgICAgICAgICAgICAnLCcsXG4gICAgICAgICAgICAgICcjJyxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKSxcbiAgICAgICAgKSxcbiAgICAgICksXG4gICAgKSxcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuYXJyYXlPZihcbiAgICAgICAgc2NoZW1hLnN0cmluZyh7XG4gICAgICAgICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuICAgICAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm9TcGFjZXMsXG4gICAgICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub0xpdGVyYWxTdHJpbmcoJy4nLCAnLi4nKSxcbiAgICAgICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vU3RhcnRzV2l0aFN0cmluZygnLScsICdfJywgJysnLCAnLicpLFxuICAgICAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm90SW52YWxpZENoYXJhY3RlcnMoXG4gICAgICAgICAgICAgICdcXFxcJyxcbiAgICAgICAgICAgICAgJy8nLFxuICAgICAgICAgICAgICAnPycsXG4gICAgICAgICAgICAgICdcIicsXG4gICAgICAgICAgICAgICc8JyxcbiAgICAgICAgICAgICAgJz4nLFxuICAgICAgICAgICAgICAnfCcsXG4gICAgICAgICAgICAgICcsJyxcbiAgICAgICAgICAgICAgJyMnLFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICApLFxuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgfSxcbiAgfSxcbiAgJ2lwLnNlbGVjdG9yJzoge1xuICAgIHRpdGxlOiAnSVAgc2VsZWN0b3InLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0RlZmluZSBpZiB0aGUgdXNlciBpcyBhbGxvd2VkIHRvIGNoYW5nZSB0aGUgc2VsZWN0ZWQgaW5kZXggcGF0dGVybiBkaXJlY3RseSBmcm9tIHRoZSB0b3AgbWVudSBiYXIuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogZmFsc2UsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uIChcbiAgICAgIHZhbHVlOiBib29sZWFuIHwgc3RyaW5nLFxuICAgICk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuICAgIH0sXG4gIH0sXG4gICd3YXp1aC51cGRhdGVzLmRpc2FibGVkJzoge1xuICAgIHRpdGxlOiAnQ2hlY2sgdXBkYXRlcycsXG4gICAgZGVzY3JpcHRpb246ICdEZWZpbmUgaWYgdGhlIGNoZWNrIHVwZGF0ZXMgc2VydmljZSBpcyBhY3RpdmUuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IGZhbHNlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IGZhbHNlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcsXG4gICAgKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG4gICAgfSxcbiAgfSxcbiAgJ2xvZ3MubGV2ZWwnOiB7XG4gICAgdGl0bGU6ICdMb2cgbGV2ZWwnLFxuICAgIGRlc2NyaXB0aW9uOiAnTG9nZ2luZyBsZXZlbCBvZiB0aGUgQXBwLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5HRU5FUkFMLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zZWxlY3QsXG4gICAgb3B0aW9uczoge1xuICAgICAgc2VsZWN0OiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiAnSW5mbycsXG4gICAgICAgICAgdmFsdWU6ICdpbmZvJyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6ICdEZWJ1ZycsXG4gICAgICAgICAgdmFsdWU6ICdkZWJ1ZycsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH0sXG4gICAgZGVmYXVsdFZhbHVlOiAnaW5mbycsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1Jlc3RhcnRpbmdQbHVnaW5QbGF0Zm9ybTogdHJ1ZSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IubGl0ZXJhbChcbiAgICAgICAgdGhpcy5vcHRpb25zLnNlbGVjdC5tYXAoKHsgdmFsdWUgfSkgPT4gdmFsdWUpLFxuICAgICAgKSh2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEub25lT2YoXG4gICAgICAgIHRoaXMub3B0aW9ucy5zZWxlY3QubWFwKCh7IHZhbHVlIH0pID0+IHNjaGVtYS5saXRlcmFsKHZhbHVlKSksXG4gICAgICApO1xuICAgIH0sXG4gIH0sXG4gIHBhdHRlcm46IHtcbiAgICB0aXRsZTogJ0luZGV4IHBhdHRlcm4nLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJEZWZhdWx0IGluZGV4IHBhdHRlcm4gdG8gdXNlIG9uIHRoZSBhcHAuIElmIHRoZXJlJ3Mgbm8gdmFsaWQgaW5kZXggcGF0dGVybiwgdGhlIGFwcCB3aWxsIGF1dG9tYXRpY2FsbHkgY3JlYXRlIG9uZSB3aXRoIHRoZSBuYW1lIGluZGljYXRlZCBpbiB0aGlzIG9wdGlvbi5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrOiB0cnVlLFxuICAgIC8vIFZhbGlkYXRpb246IGh0dHBzOi8vZ2l0aHViLmNvbS9lbGFzdGljL2VsYXN0aWNzZWFyY2gvYmxvYi92Ny4xMC4yL2RvY3MvcmVmZXJlbmNlL2luZGljZXMvY3JlYXRlLWluZGV4LmFzY2lpZG9jXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm9TcGFjZXMsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub0xpdGVyYWxTdHJpbmcoJy4nLCAnLi4nKSxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vU3RhcnRzV2l0aFN0cmluZygnLScsICdfJywgJysnLCAnLicpLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm90SW52YWxpZENoYXJhY3RlcnMoXG4gICAgICAgICdcXFxcJyxcbiAgICAgICAgJy8nLFxuICAgICAgICAnPycsXG4gICAgICAgICdcIicsXG4gICAgICAgICc8JyxcbiAgICAgICAgJz4nLFxuICAgICAgICAnfCcsXG4gICAgICAgICcsJyxcbiAgICAgICAgJyMnLFxuICAgICAgKSxcbiAgICApLFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5zdHJpbmcoeyB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZSB9KTtcbiAgICB9LFxuICB9LFxuICB0aW1lb3V0OiB7XG4gICAgdGl0bGU6ICdSZXF1ZXN0IHRpbWVvdXQnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ01heGltdW0gdGltZSwgaW4gbWlsbGlzZWNvbmRzLCB0aGUgYXBwIHdpbGwgd2FpdCBmb3IgYW4gQVBJIHJlc3BvbnNlIHdoZW4gbWFraW5nIHJlcXVlc3RzIHRvIGl0LiBJdCB3aWxsIGJlIGlnbm9yZWQgaWYgdGhlIHZhbHVlIGlzIHNldCB1bmRlciAxNTAwIG1pbGxpc2Vjb25kcy4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUubnVtYmVyLFxuICAgIGRlZmF1bHRWYWx1ZTogMjAwMDAsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiAxNTAwLFxuICAgICAgICBpbnRlZ2VyOiB0cnVlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNvbmZpZ3VyYXRpb25WYWx1ZVRvSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogc3RyaW5nLFxuICAgICk6IG51bWJlciB7XG4gICAgICByZXR1cm4gTnVtYmVyKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5udW1iZXIodGhpcy5vcHRpb25zLm51bWJlcikodmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLm51bWJlcih7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlLmJpbmQodGhpcykgfSk7XG4gICAgfSxcbiAgfSxcbiAgJ3dhenVoLm1vbml0b3JpbmcuY3JlYXRpb24nOiB7XG4gICAgdGl0bGU6ICdJbmRleCBjcmVhdGlvbicsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRGVmaW5lIHRoZSBpbnRlcnZhbCBpbiB3aGljaCBhIG5ldyB3YXp1aC1tb25pdG9yaW5nIGluZGV4IHdpbGwgYmUgY3JlYXRlZC4nLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuTU9OSVRPUklORyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc2VsZWN0LFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHNlbGVjdDogW1xuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogJ0hvdXJseScsXG4gICAgICAgICAgdmFsdWU6ICdoJyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6ICdEYWlseScsXG4gICAgICAgICAgdmFsdWU6ICdkJyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6ICdXZWVrbHknLFxuICAgICAgICAgIHZhbHVlOiAndycsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiAnTW9udGhseScsXG4gICAgICAgICAgdmFsdWU6ICdtJyxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9DUkVBVElPTixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrOiB0cnVlLFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5saXRlcmFsKFxuICAgICAgICB0aGlzLm9wdGlvbnMuc2VsZWN0Lm1hcCgoeyB2YWx1ZSB9KSA9PiB2YWx1ZSksXG4gICAgICApKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5vbmVPZihcbiAgICAgICAgdGhpcy5vcHRpb25zLnNlbGVjdC5tYXAoKHsgdmFsdWUgfSkgPT4gc2NoZW1hLmxpdGVyYWwodmFsdWUpKSxcbiAgICAgICk7XG4gICAgfSxcbiAgfSxcbiAgJ3dhenVoLm1vbml0b3JpbmcuZW5hYmxlZCc6IHtcbiAgICB0aXRsZTogJ1N0YXR1cycsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRW5hYmxlIG9yIGRpc2FibGUgdGhlIHdhenVoLW1vbml0b3JpbmcgaW5kZXggY3JlYXRpb24gYW5kL29yIHZpc3VhbGl6YXRpb24uJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkcsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9FTkFCTEVELFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSZXN0YXJ0aW5nUGx1Z2luUGxhdGZvcm06IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uIChcbiAgICAgIHZhbHVlOiBib29sZWFuIHwgc3RyaW5nLFxuICAgICk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuICAgIH0sXG4gIH0sXG4gICd3YXp1aC5tb25pdG9yaW5nLmZyZXF1ZW5jeSc6IHtcbiAgICB0aXRsZTogJ0ZyZXF1ZW5jeScsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRnJlcXVlbmN5LCBpbiBzZWNvbmRzLCBvZiBBUEkgcmVxdWVzdHMgdG8gZ2V0IHRoZSBzdGF0ZSBvZiB0aGUgYWdlbnRzIGFuZCBjcmVhdGUgYSBuZXcgZG9jdW1lbnQgaW4gdGhlIHdhenVoLW1vbml0b3JpbmcgaW5kZXggd2l0aCB0aGlzIGRhdGEuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkcsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLm51bWJlcixcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9GUkVRVUVOQ1ksXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1Jlc3RhcnRpbmdQbHVnaW5QbGF0Zm9ybTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiA2MCxcbiAgICAgICAgaW50ZWdlcjogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1Db25maWd1cmF0aW9uVmFsdWVUb0lucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IHN0cmluZyxcbiAgICApOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IubnVtYmVyKHRoaXMub3B0aW9ucy5udW1iZXIpKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5udW1iZXIoeyB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZS5iaW5kKHRoaXMpIH0pO1xuICAgIH0sXG4gIH0sXG4gICd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nOiB7XG4gICAgdGl0bGU6ICdJbmRleCBwYXR0ZXJuJyxcbiAgICBkZXNjcmlwdGlvbjogJ0RlZmF1bHQgaW5kZXggcGF0dGVybiB0byB1c2UgZm9yIFdhenVoIG1vbml0b3JpbmcuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkcsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk4sXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vTGl0ZXJhbFN0cmluZygnLicsICcuLicpLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9TdGFydHNXaXRoU3RyaW5nKCctJywgJ18nLCAnKycsICcuJyksXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb3RJbnZhbGlkQ2hhcmFjdGVycyhcbiAgICAgICAgJ1xcXFwnLFxuICAgICAgICAnLycsXG4gICAgICAgICc/JyxcbiAgICAgICAgJ1wiJyxcbiAgICAgICAgJzwnLFxuICAgICAgICAnPicsXG4gICAgICAgICd8JyxcbiAgICAgICAgJywnLFxuICAgICAgICAnIycsXG4gICAgICApLFxuICAgICksXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLnN0cmluZyh7IG1pbkxlbmd0aDogMSwgdmFsaWRhdGU6IHRoaXMudmFsaWRhdGUgfSk7XG4gICAgfSxcbiAgfSxcbiAgJ3dhenVoLm1vbml0b3JpbmcucmVwbGljYXMnOiB7XG4gICAgdGl0bGU6ICdJbmRleCByZXBsaWNhcycsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRGVmaW5lIHRoZSBudW1iZXIgb2YgcmVwbGljYXMgdG8gdXNlIGZvciB0aGUgd2F6dWgtbW9uaXRvcmluZy0qIGluZGljZXMuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkcsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLm51bWJlcixcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9JTkRJQ0VTX1JFUExJQ0FTLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgbnVtYmVyOiB7XG4gICAgICAgIG1pbjogMCxcbiAgICAgICAgaW50ZWdlcjogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1Db25maWd1cmF0aW9uVmFsdWVUb0lucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZTogZnVuY3Rpb24gKFxuICAgICAgdmFsdWU6IHN0cmluZyxcbiAgICApOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IubnVtYmVyKHRoaXMub3B0aW9ucy5udW1iZXIpKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24gKHNjaGVtYSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5udW1iZXIoeyB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZS5iaW5kKHRoaXMpIH0pO1xuICAgIH0sXG4gIH0sXG4gICd3YXp1aC5tb25pdG9yaW5nLnNoYXJkcyc6IHtcbiAgICB0aXRsZTogJ0luZGV4IHNoYXJkcycsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRGVmaW5lIHRoZSBudW1iZXIgb2Ygc2hhcmRzIHRvIHVzZSBmb3IgdGhlIHdhenVoLW1vbml0b3JpbmctKiBpbmRpY2VzLicsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5NT05JVE9SSU5HLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5udW1iZXIsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiAxLFxuICAgICAgICBpbnRlZ2VyOiB0cnVlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNvbmZpZ3VyYXRpb25WYWx1ZVRvSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlOiBmdW5jdGlvbiAoXG4gICAgICB2YWx1ZTogc3RyaW5nLFxuICAgICk6IG51bWJlciB7XG4gICAgICByZXR1cm4gTnVtYmVyKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5udW1iZXIodGhpcy5vcHRpb25zLm51bWJlcikodmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLm51bWJlcih7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlLmJpbmQodGhpcykgfSk7XG4gICAgfSxcbiAgfSxcbiAgJ3Z1bG5lcmFiaWxpdGllcy5wYXR0ZXJuJzoge1xuICAgIHRpdGxlOiAnSW5kZXggcGF0dGVybicsXG4gICAgZGVzY3JpcHRpb246ICdEZWZhdWx0IGluZGV4IHBhdHRlcm4gdG8gdXNlIGZvciB2dWxuZXJhYmlsaXRpZXMuJyxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LlZVTE5FUkFCSUxJVElFUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1ZVTE5FUkFCSUxJVElFU19QQVRURVJOLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s6IGZhbHNlLFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNOb3RFbXB0eVN0cmluZyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9MaXRlcmFsU3RyaW5nKCcuJywgJy4uJyksXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub1N0YXJ0c1dpdGhTdHJpbmcoJy0nLCAnXycsICcrJywgJy4nKSxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vdEludmFsaWRDaGFyYWN0ZXJzKFxuICAgICAgICAnXFxcXCcsXG4gICAgICAgICcvJyxcbiAgICAgICAgJz8nLFxuICAgICAgICAnXCInLFxuICAgICAgICAnPCcsXG4gICAgICAgICc+JyxcbiAgICAgICAgJ3wnLFxuICAgICAgICAnLCcsXG4gICAgICAgICcjJyxcbiAgICAgICksXG4gICAgKSxcbiAgICB2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uIChzY2hlbWEpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuc3RyaW5nKHsgbWluTGVuZ3RoOiAxLCB2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZSB9KTtcbiAgICB9LFxuICB9LFxufTtcblxuZXhwb3J0IHR5cGUgVFBsdWdpblNldHRpbmdLZXkgPSBrZXlvZiB0eXBlb2YgUExVR0lOX1NFVFRJTkdTO1xuXG5leHBvcnQgZW51bSBIVFRQX1NUQVRVU19DT0RFUyB7XG4gIENPTlRJTlVFID0gMTAwLFxuICBTV0lUQ0hJTkdfUFJPVE9DT0xTID0gMTAxLFxuICBQUk9DRVNTSU5HID0gMTAyLFxuICBPSyA9IDIwMCxcbiAgQ1JFQVRFRCA9IDIwMSxcbiAgQUNDRVBURUQgPSAyMDIsXG4gIE5PTl9BVVRIT1JJVEFUSVZFX0lORk9STUFUSU9OID0gMjAzLFxuICBOT19DT05URU5UID0gMjA0LFxuICBSRVNFVF9DT05URU5UID0gMjA1LFxuICBQQVJUSUFMX0NPTlRFTlQgPSAyMDYsXG4gIE1VTFRJX1NUQVRVUyA9IDIwNyxcbiAgTVVMVElQTEVfQ0hPSUNFUyA9IDMwMCxcbiAgTU9WRURfUEVSTUFORU5UTFkgPSAzMDEsXG4gIE1PVkVEX1RFTVBPUkFSSUxZID0gMzAyLFxuICBTRUVfT1RIRVIgPSAzMDMsXG4gIE5PVF9NT0RJRklFRCA9IDMwNCxcbiAgVVNFX1BST1hZID0gMzA1LFxuICBURU1QT1JBUllfUkVESVJFQ1QgPSAzMDcsXG4gIFBFUk1BTkVOVF9SRURJUkVDVCA9IDMwOCxcbiAgQkFEX1JFUVVFU1QgPSA0MDAsXG4gIFVOQVVUSE9SSVpFRCA9IDQwMSxcbiAgUEFZTUVOVF9SRVFVSVJFRCA9IDQwMixcbiAgRk9SQklEREVOID0gNDAzLFxuICBOT1RfRk9VTkQgPSA0MDQsXG4gIE1FVEhPRF9OT1RfQUxMT1dFRCA9IDQwNSxcbiAgTk9UX0FDQ0VQVEFCTEUgPSA0MDYsXG4gIFBST1hZX0FVVEhFTlRJQ0FUSU9OX1JFUVVJUkVEID0gNDA3LFxuICBSRVFVRVNUX1RJTUVPVVQgPSA0MDgsXG4gIENPTkZMSUNUID0gNDA5LFxuICBHT05FID0gNDEwLFxuICBMRU5HVEhfUkVRVUlSRUQgPSA0MTEsXG4gIFBSRUNPTkRJVElPTl9GQUlMRUQgPSA0MTIsXG4gIFJFUVVFU1RfVE9PX0xPTkcgPSA0MTMsXG4gIFJFUVVFU1RfVVJJX1RPT19MT05HID0gNDE0LFxuICBVTlNVUFBPUlRFRF9NRURJQV9UWVBFID0gNDE1LFxuICBSRVFVRVNURURfUkFOR0VfTk9UX1NBVElTRklBQkxFID0gNDE2LFxuICBFWFBFQ1RBVElPTl9GQUlMRUQgPSA0MTcsXG4gIElNX0FfVEVBUE9UID0gNDE4LFxuICBJTlNVRkZJQ0lFTlRfU1BBQ0VfT05fUkVTT1VSQ0UgPSA0MTksXG4gIE1FVEhPRF9GQUlMVVJFID0gNDIwLFxuICBNSVNESVJFQ1RFRF9SRVFVRVNUID0gNDIxLFxuICBVTlBST0NFU1NBQkxFX0VOVElUWSA9IDQyMixcbiAgTE9DS0VEID0gNDIzLFxuICBGQUlMRURfREVQRU5ERU5DWSA9IDQyNCxcbiAgUFJFQ09ORElUSU9OX1JFUVVJUkVEID0gNDI4LFxuICBUT09fTUFOWV9SRVFVRVNUUyA9IDQyOSxcbiAgUkVRVUVTVF9IRUFERVJfRklFTERTX1RPT19MQVJHRSA9IDQzMSxcbiAgVU5BVkFJTEFCTEVfRk9SX0xFR0FMX1JFQVNPTlMgPSA0NTEsXG4gIElOVEVSTkFMX1NFUlZFUl9FUlJPUiA9IDUwMCxcbiAgTk9UX0lNUExFTUVOVEVEID0gNTAxLFxuICBCQURfR0FURVdBWSA9IDUwMixcbiAgU0VSVklDRV9VTkFWQUlMQUJMRSA9IDUwMyxcbiAgR0FURVdBWV9USU1FT1VUID0gNTA0LFxuICBIVFRQX1ZFUlNJT05fTk9UX1NVUFBPUlRFRCA9IDUwNSxcbiAgSU5TVUZGSUNJRU5UX1NUT1JBR0UgPSA1MDcsXG4gIE5FVFdPUktfQVVUSEVOVElDQVRJT05fUkVRVUlSRUQgPSA1MTEsXG59XG5cbi8vIE1vZHVsZSBTZWN1cml0eSBjb25maWd1cmF0aW9uIGFzc2Vzc21lbnRcbmV4cG9ydCBjb25zdCBNT0RVTEVfU0NBX0NIRUNLX1JFU1VMVF9MQUJFTCA9IHtcbiAgcGFzc2VkOiAnUGFzc2VkJyxcbiAgZmFpbGVkOiAnRmFpbGVkJyxcbiAgJ25vdCBhcHBsaWNhYmxlJzogJ05vdCBhcHBsaWNhYmxlJyxcbn07XG5cbi8vIFNlYXJjaCBiYXJcblxuLy8gVGhpcyBsaW1pdHMgdGhlIHJlc3VsdHMgaW4gdGhlIEFQSSByZXF1ZXN0XG5leHBvcnQgY29uc3QgU0VBUkNIX0JBUl9XUUxfVkFMVUVfU1VHR0VTVElPTlNfQ09VTlQgPSAzMDtcbi8vIFRoaXMgbGltaXRzIHRoZSBzdWdnZXN0aW9ucyBmb3IgdGhlIHRva2VuIG9mIHR5cGUgdmFsdWUgZGlzcGxheWVkIGluIHRoZSBzZWFyY2ggYmFyXG5leHBvcnQgY29uc3QgU0VBUkNIX0JBUl9XUUxfVkFMVUVfU1VHR0VTVElPTlNfRElTUExBWV9DT1VOVCA9IDEwO1xuLyogVGltZSBpbiBtaWxsaXNlY29uZHMgdG8gZGVib3VuY2UgdGhlIGFuYWx5c2lzIG9mIHNlYXJjaCBiYXIuIFRoaXMgbWl0aWdhdGVzIHNvbWUgcHJvYmxlbXMgcmVsYXRlZFxudG8gY2hhbmdlcyBydW5uaW5nIGluIHBhcmFsbGVsICovXG5leHBvcnQgY29uc3QgU0VBUkNIX0JBUl9ERUJPVU5DRV9VUERBVEVfVElNRSA9IDQwMDtcbiJdfQ==