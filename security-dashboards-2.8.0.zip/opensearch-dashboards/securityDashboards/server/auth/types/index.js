"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "BasicAuthentication", {
  enumerable: true,
  get: function () {
    return _basic_auth.BasicAuthentication;
  }
});
Object.defineProperty(exports, "JwtAuthentication", {
  enumerable: true,
  get: function () {
    return _jwt_auth.JwtAuthentication;
  }
});
Object.defineProperty(exports, "MultipleAuthentication", {
  enumerable: true,
  get: function () {
    return _multi_auth.MultipleAuthentication;
  }
});
Object.defineProperty(exports, "OpenIdAuthentication", {
  enumerable: true,
  get: function () {
    return _openid_auth.OpenIdAuthentication;
  }
});
Object.defineProperty(exports, "ProxyAuthentication", {
  enumerable: true,
  get: function () {
    return _proxy_auth.ProxyAuthentication;
  }
});
Object.defineProperty(exports, "SamlAuthentication", {
  enumerable: true,
  get: function () {
    return _saml_auth.SamlAuthentication;
  }
});

var _basic_auth = require("./basic/basic_auth");

var _jwt_auth = require("./jwt/jwt_auth");

var _openid_auth = require("./openid/openid_auth");

var _proxy_auth = require("./proxy/proxy_auth");

var _saml_auth = require("./saml/saml_auth");

var _multi_auth = require("./multiple/multi_auth");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWVBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogICBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcclxuICpcclxuICogICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxyXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cclxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxyXG4gKlxyXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuICpcclxuICogICBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcclxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xyXG4gKiAgIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG5leHBvcnQgeyBCYXNpY0F1dGhlbnRpY2F0aW9uIH0gZnJvbSAnLi9iYXNpYy9iYXNpY19hdXRoJztcclxuZXhwb3J0IHsgSnd0QXV0aGVudGljYXRpb24gfSBmcm9tICcuL2p3dC9qd3RfYXV0aCc7XHJcbmV4cG9ydCB7IE9wZW5JZEF1dGhlbnRpY2F0aW9uIH0gZnJvbSAnLi9vcGVuaWQvb3BlbmlkX2F1dGgnO1xyXG5leHBvcnQgeyBQcm94eUF1dGhlbnRpY2F0aW9uIH0gZnJvbSAnLi9wcm94eS9wcm94eV9hdXRoJztcclxuZXhwb3J0IHsgU2FtbEF1dGhlbnRpY2F0aW9uIH0gZnJvbSAnLi9zYW1sL3NhbWxfYXV0aCc7XHJcbmV4cG9ydCB7IE11bHRpcGxlQXV0aGVudGljYXRpb24gfSBmcm9tICcuL211bHRpcGxlL211bHRpX2F1dGgnO1xyXG4iXX0=