"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ProxyAuthRoutes = void 0;

var _configSchema = require("@osd/config-schema");

var _next_url = require("../../../utils/next_url");

/*
 *   Copyright OpenSearch Contributors
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
class ProxyAuthRoutes {
  constructor(router, config, sessionStorageFactory, securityClient, coreSetup) {
    this.router = router;
    this.config = config;
    this.sessionStorageFactory = sessionStorageFactory;
    this.securityClient = securityClient;
    this.coreSetup = coreSetup;
  }

  setupRoutes() {
    this.router.get({
      path: `/auth/proxy/login`,
      validate: {
        query: _configSchema.schema.object({
          nextUrl: _configSchema.schema.maybe(_configSchema.schema.string({
            validate: _next_url.validateNextUrl
          }))
        })
      },
      options: {
        // TODO: set to false?
        authRequired: 'optional'
      }
    }, async (context, request, response) => {
      var _this$config$proxycac;

      if (request.auth.isAuthenticated) {
        const nextUrl = request.query.nextUrl || `${this.coreSetup.http.basePath.serverBasePath}/app/opensearch-dashboards`;
        response.redirected({
          headers: {
            location: nextUrl
          }
        });
      }

      const loginEndpoint = (_this$config$proxycac = this.config.proxycache) === null || _this$config$proxycac === void 0 ? void 0 : _this$config$proxycac.login_endpoint;

      if (loginEndpoint) {
        return response.redirected({
          headers: {
            location: loginEndpoint
          }
        });
      } else {
        return response.badRequest();
      }
    });
    this.router.post({
      path: `/auth/proxy/logout`,
      validate: false
    }, async (context, request, response) => {
      this.sessionStorageFactory.asScoped(request).clear();
      return response.ok();
    });
  }

}

exports.ProxyAuthRoutes = ProxyAuthRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdXRlcy50cyJdLCJuYW1lcyI6WyJQcm94eUF1dGhSb3V0ZXMiLCJjb25zdHJ1Y3RvciIsInJvdXRlciIsImNvbmZpZyIsInNlc3Npb25TdG9yYWdlRmFjdG9yeSIsInNlY3VyaXR5Q2xpZW50IiwiY29yZVNldHVwIiwic2V0dXBSb3V0ZXMiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsIm5leHRVcmwiLCJtYXliZSIsInN0cmluZyIsInZhbGlkYXRlTmV4dFVybCIsIm9wdGlvbnMiLCJhdXRoUmVxdWlyZWQiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiYXV0aCIsImlzQXV0aGVudGljYXRlZCIsImh0dHAiLCJiYXNlUGF0aCIsInNlcnZlckJhc2VQYXRoIiwicmVkaXJlY3RlZCIsImhlYWRlcnMiLCJsb2NhdGlvbiIsImxvZ2luRW5kcG9pbnQiLCJwcm94eWNhY2hlIiwibG9naW5fZW5kcG9pbnQiLCJiYWRSZXF1ZXN0IiwicG9zdCIsImFzU2NvcGVkIiwiY2xlYXIiLCJvayJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWVBOztBQU1BOztBQXJCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVU8sTUFBTUEsZUFBTixDQUFzQjtBQUMzQkMsRUFBQUEsV0FBVyxDQUNRQyxNQURSLEVBRVFDLE1BRlIsRUFHUUMscUJBSFIsRUFJUUMsY0FKUixFQUtRQyxTQUxSLEVBTVQ7QUFBQSxTQUxpQkosTUFLakIsR0FMaUJBLE1BS2pCO0FBQUEsU0FKaUJDLE1BSWpCLEdBSmlCQSxNQUlqQjtBQUFBLFNBSGlCQyxxQkFHakIsR0FIaUJBLHFCQUdqQjtBQUFBLFNBRmlCQyxjQUVqQixHQUZpQkEsY0FFakI7QUFBQSxTQURpQkMsU0FDakIsR0FEaUJBLFNBQ2pCO0FBQUU7O0FBRUdDLEVBQUFBLFdBQVcsR0FBRztBQUNuQixTQUFLTCxNQUFMLENBQVlNLEdBQVosQ0FDRTtBQUNFQyxNQUFBQSxJQUFJLEVBQUcsbUJBRFQ7QUFFRUMsTUFBQUEsUUFBUSxFQUFFO0FBQ1JDLFFBQUFBLEtBQUssRUFBRUMscUJBQU9DLE1BQVAsQ0FBYztBQUNuQkMsVUFBQUEsT0FBTyxFQUFFRixxQkFBT0csS0FBUCxDQUNQSCxxQkFBT0ksTUFBUCxDQUFjO0FBQ1pOLFlBQUFBLFFBQVEsRUFBRU87QUFERSxXQUFkLENBRE87QUFEVSxTQUFkO0FBREMsT0FGWjtBQVdFQyxNQUFBQSxPQUFPLEVBQUU7QUFDUDtBQUNBQyxRQUFBQSxZQUFZLEVBQUU7QUFGUDtBQVhYLEtBREYsRUFpQkUsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQUE7O0FBQ3BDLFVBQUlELE9BQU8sQ0FBQ0UsSUFBUixDQUFhQyxlQUFqQixFQUFrQztBQUNoQyxjQUFNVixPQUFPLEdBQ1hPLE9BQU8sQ0FBQ1YsS0FBUixDQUFjRyxPQUFkLElBQ0MsR0FBRSxLQUFLUixTQUFMLENBQWVtQixJQUFmLENBQW9CQyxRQUFwQixDQUE2QkMsY0FBZSw0QkFGakQ7QUFHQUwsUUFBQUEsUUFBUSxDQUFDTSxVQUFULENBQW9CO0FBQ2xCQyxVQUFBQSxPQUFPLEVBQUU7QUFDUEMsWUFBQUEsUUFBUSxFQUFFaEI7QUFESDtBQURTLFNBQXBCO0FBS0Q7O0FBRUQsWUFBTWlCLGFBQWEsNEJBQUcsS0FBSzVCLE1BQUwsQ0FBWTZCLFVBQWYsMERBQUcsc0JBQXdCQyxjQUE5Qzs7QUFDQSxVQUFJRixhQUFKLEVBQW1CO0FBQ2pCLGVBQU9ULFFBQVEsQ0FBQ00sVUFBVCxDQUFvQjtBQUN6QkMsVUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFlBQUFBLFFBQVEsRUFBRUM7QUFESDtBQURnQixTQUFwQixDQUFQO0FBS0QsT0FORCxNQU1PO0FBQ0wsZUFBT1QsUUFBUSxDQUFDWSxVQUFULEVBQVA7QUFDRDtBQUNGLEtBdkNIO0FBMENBLFNBQUtoQyxNQUFMLENBQVlpQyxJQUFaLENBQ0U7QUFDRTFCLE1BQUFBLElBQUksRUFBRyxvQkFEVDtBQUVFQyxNQUFBQSxRQUFRLEVBQUU7QUFGWixLQURGLEVBS0UsT0FBT1UsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFdBQUtsQixxQkFBTCxDQUEyQmdDLFFBQTNCLENBQW9DZixPQUFwQyxFQUE2Q2dCLEtBQTdDO0FBQ0EsYUFBT2YsUUFBUSxDQUFDZ0IsRUFBVCxFQUFQO0FBQ0QsS0FSSDtBQVVEOztBQTlEMEIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiAgIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xyXG4gKlxyXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXHJcbiAqICAgWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxyXG4gKiAgIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XHJcbiAqXHJcbiAqICAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxyXG4gKlxyXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxyXG4gKiAgIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxyXG4gKiAgIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXHJcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XHJcbmltcG9ydCB7IElSb3V0ZXIsIFNlc3Npb25TdG9yYWdlRmFjdG9yeSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XHJcbmltcG9ydCB7IFNlY3VyaXR5U2Vzc2lvbkNvb2tpZSB9IGZyb20gJy4uLy4uLy4uL3Nlc3Npb24vc2VjdXJpdHlfY29va2llJztcclxuaW1wb3J0IHsgU2VjdXJpdHlQbHVnaW5Db25maWdUeXBlIH0gZnJvbSAnLi4vLi4vLi4nO1xyXG5pbXBvcnQgeyBTZWN1cml0eUNsaWVudCB9IGZyb20gJy4uLy4uLy4uL2JhY2tlbmQvb3BlbnNlYXJjaF9zZWN1cml0eV9jbGllbnQnO1xyXG5pbXBvcnQgeyBDb3JlU2V0dXAgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyB2YWxpZGF0ZU5leHRVcmwgfSBmcm9tICcuLi8uLi8uLi91dGlscy9uZXh0X3VybCc7XHJcblxyXG5leHBvcnQgY2xhc3MgUHJveHlBdXRoUm91dGVzIHtcclxuICBjb25zdHJ1Y3RvcihcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgcm91dGVyOiBJUm91dGVyLFxyXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb25maWc6IFNlY3VyaXR5UGx1Z2luQ29uZmlnVHlwZSxcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgc2Vzc2lvblN0b3JhZ2VGYWN0b3J5OiBTZXNzaW9uU3RvcmFnZUZhY3Rvcnk8U2VjdXJpdHlTZXNzaW9uQ29va2llPixcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgc2VjdXJpdHlDbGllbnQ6IFNlY3VyaXR5Q2xpZW50LFxyXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb3JlU2V0dXA6IENvcmVTZXR1cFxyXG4gICkge31cclxuXHJcbiAgcHVibGljIHNldHVwUm91dGVzKCkge1xyXG4gICAgdGhpcy5yb3V0ZXIuZ2V0KFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogYC9hdXRoL3Byb3h5L2xvZ2luYCxcclxuICAgICAgICB2YWxpZGF0ZToge1xyXG4gICAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xyXG4gICAgICAgICAgICBuZXh0VXJsOiBzY2hlbWEubWF5YmUoXHJcbiAgICAgICAgICAgICAgc2NoZW1hLnN0cmluZyh7XHJcbiAgICAgICAgICAgICAgICB2YWxpZGF0ZTogdmFsaWRhdGVOZXh0VXJsLFxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9wdGlvbnM6IHtcclxuICAgICAgICAgIC8vIFRPRE86IHNldCB0byBmYWxzZT9cclxuICAgICAgICAgIGF1dGhSZXF1aXJlZDogJ29wdGlvbmFsJyxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVxdWVzdC5hdXRoLmlzQXV0aGVudGljYXRlZCkge1xyXG4gICAgICAgICAgY29uc3QgbmV4dFVybCA9XHJcbiAgICAgICAgICAgIHJlcXVlc3QucXVlcnkubmV4dFVybCB8fFxyXG4gICAgICAgICAgICBgJHt0aGlzLmNvcmVTZXR1cC5odHRwLmJhc2VQYXRoLnNlcnZlckJhc2VQYXRofS9hcHAvb3BlbnNlYXJjaC1kYXNoYm9hcmRzYDtcclxuICAgICAgICAgIHJlc3BvbnNlLnJlZGlyZWN0ZWQoe1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgbG9jYXRpb246IG5leHRVcmwsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGxvZ2luRW5kcG9pbnQgPSB0aGlzLmNvbmZpZy5wcm94eWNhY2hlPy5sb2dpbl9lbmRwb2ludDtcclxuICAgICAgICBpZiAobG9naW5FbmRwb2ludCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlZGlyZWN0ZWQoe1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgbG9jYXRpb246IGxvZ2luRW5kcG9pbnQsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3QoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgdGhpcy5yb3V0ZXIucG9zdChcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6IGAvYXV0aC9wcm94eS9sb2dvdXRgLFxyXG4gICAgICAgIHZhbGlkYXRlOiBmYWxzZSxcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgdGhpcy5zZXNzaW9uU3RvcmFnZUZhY3RvcnkuYXNTY29wZWQocmVxdWVzdCkuY2xlYXIoKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soKTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl19