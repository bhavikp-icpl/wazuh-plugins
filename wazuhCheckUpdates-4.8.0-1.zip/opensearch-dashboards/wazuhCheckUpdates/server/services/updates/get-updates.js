"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUpdates = void 0;

var _types = require("../../../common/types");

var _constants = require("../../../common/constants");

var _savedObject = require("../saved-object");

var _pluginServices = require("../../plugin-services");

const getUpdates = async (queryApi = false, forceQuery = false) => {
  try {
    if (!queryApi) {
      const availableUpdates = await (0, _savedObject.getSavedObject)(_constants.SAVED_OBJECT_UPDATES);
      return availableUpdates;
    }

    const {
      controllers: {
        WazuhHostsCtrl
      },
      services: {
        wazuhApiClient
      }
    } = (0, _pluginServices.getWazuhCore)();
    const wazuhHostsController = new WazuhHostsCtrl();
    const hosts = await wazuhHostsController.getHostsEntries();
    const apisAvailableUpdates = await Promise.all(hosts === null || hosts === void 0 ? void 0 : hosts.map(async api => {
      const data = {};
      const method = 'GET';
      const path = `/manager/version/check?force_query=${forceQuery}`;
      const options = {
        apiHostID: api.id,
        forceRefresh: true
      };

      try {
        const response = await wazuhApiClient.client.asInternalUser.request(method, path, data, options);
        const update = response.data.data;
        const {
          current_version,
          update_check,
          last_available_major,
          last_available_minor,
          last_available_patch,
          last_check_date
        } = update;

        const getStatus = () => {
          if (update_check === false) {
            return _types.API_UPDATES_STATUS.DISABLED;
          }

          if (last_available_major !== null && last_available_major !== void 0 && last_available_major.tag || last_available_minor !== null && last_available_minor !== void 0 && last_available_minor.tag || last_available_patch !== null && last_available_patch !== void 0 && last_available_patch.tag) {
            return _types.API_UPDATES_STATUS.AVAILABLE_UPDATES;
          }

          return _types.API_UPDATES_STATUS.UP_TO_DATE;
        };

        return {
          current_version,
          update_check,
          last_available_major,
          last_available_minor,
          last_available_patch,
          last_check_date: last_check_date || undefined,
          api_id: api.id,
          status: getStatus()
        };
      } catch (e) {
        var _e$response, _e$response$data, _e$response$data$deta, _e$response2, _e$response2$data;

        const error = {
          title: (_e$response = e.response) === null || _e$response === void 0 ? void 0 : (_e$response$data = _e$response.data) === null || _e$response$data === void 0 ? void 0 : _e$response$data.title,
          detail: (_e$response$data$deta = (_e$response2 = e.response) === null || _e$response2 === void 0 ? void 0 : (_e$response2$data = _e$response2.data) === null || _e$response2$data === void 0 ? void 0 : _e$response2$data.detail) !== null && _e$response$data$deta !== void 0 ? _e$response$data$deta : e.message
        };
        return {
          api_id: api.id,
          status: _types.API_UPDATES_STATUS.ERROR,
          error
        };
      }
    }));
    const savedObject = {
      apis_available_updates: apisAvailableUpdates,
      last_check_date: new Date()
    };
    await (0, _savedObject.setSavedObject)(_constants.SAVED_OBJECT_UPDATES, savedObject);
    return savedObject;
  } catch (error) {
    const message = error instanceof Error ? error.message : typeof error === 'string' ? error : 'Error trying to get available updates';
    const {
      services: {
        log
      }
    } = (0, _pluginServices.getWazuhCore)();
    log('wazuh-check-updates:getUpdates', message);
    return Promise.reject(error);
  }
};

exports.getUpdates = getUpdates;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC11cGRhdGVzLnRzIl0sIm5hbWVzIjpbImdldFVwZGF0ZXMiLCJxdWVyeUFwaSIsImZvcmNlUXVlcnkiLCJhdmFpbGFibGVVcGRhdGVzIiwiU0FWRURfT0JKRUNUX1VQREFURVMiLCJjb250cm9sbGVycyIsIldhenVoSG9zdHNDdHJsIiwic2VydmljZXMiLCJ3YXp1aEFwaUNsaWVudCIsIndhenVoSG9zdHNDb250cm9sbGVyIiwiaG9zdHMiLCJnZXRIb3N0c0VudHJpZXMiLCJhcGlzQXZhaWxhYmxlVXBkYXRlcyIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJhcGkiLCJkYXRhIiwibWV0aG9kIiwicGF0aCIsIm9wdGlvbnMiLCJhcGlIb3N0SUQiLCJpZCIsImZvcmNlUmVmcmVzaCIsInJlc3BvbnNlIiwiY2xpZW50IiwiYXNJbnRlcm5hbFVzZXIiLCJyZXF1ZXN0IiwidXBkYXRlIiwiY3VycmVudF92ZXJzaW9uIiwidXBkYXRlX2NoZWNrIiwibGFzdF9hdmFpbGFibGVfbWFqb3IiLCJsYXN0X2F2YWlsYWJsZV9taW5vciIsImxhc3RfYXZhaWxhYmxlX3BhdGNoIiwibGFzdF9jaGVja19kYXRlIiwiZ2V0U3RhdHVzIiwiQVBJX1VQREFURVNfU1RBVFVTIiwiRElTQUJMRUQiLCJ0YWciLCJBVkFJTEFCTEVfVVBEQVRFUyIsIlVQX1RPX0RBVEUiLCJ1bmRlZmluZWQiLCJhcGlfaWQiLCJzdGF0dXMiLCJlIiwiZXJyb3IiLCJ0aXRsZSIsImRldGFpbCIsIm1lc3NhZ2UiLCJFUlJPUiIsInNhdmVkT2JqZWN0IiwiYXBpc19hdmFpbGFibGVfdXBkYXRlcyIsIkRhdGUiLCJFcnJvciIsImxvZyIsInJlamVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBOztBQUtBOztBQUNBOztBQUNBOztBQUVPLE1BQU1BLFVBQVUsR0FBRyxPQUN4QkMsUUFBUSxHQUFHLEtBRGEsRUFFeEJDLFVBQVUsR0FBRyxLQUZXLEtBR007QUFDOUIsTUFBSTtBQUNGLFFBQUksQ0FBQ0QsUUFBTCxFQUFlO0FBQ2IsWUFBTUUsZ0JBQWdCLEdBQUksTUFBTSxpQ0FDOUJDLCtCQUQ4QixDQUFoQztBQUlBLGFBQU9ELGdCQUFQO0FBQ0Q7O0FBRUQsVUFBTTtBQUNKRSxNQUFBQSxXQUFXLEVBQUU7QUFBRUMsUUFBQUE7QUFBRixPQURUO0FBRUpDLE1BQUFBLFFBQVEsRUFBRTtBQUFFQyxRQUFBQTtBQUFGO0FBRk4sUUFHRixtQ0FISjtBQUlBLFVBQU1DLG9CQUFvQixHQUFHLElBQUlILGNBQUosRUFBN0I7QUFFQSxVQUFNSSxLQUF1QixHQUMzQixNQUFNRCxvQkFBb0IsQ0FBQ0UsZUFBckIsRUFEUjtBQUdBLFVBQU1DLG9CQUFvQixHQUFHLE1BQU1DLE9BQU8sQ0FBQ0MsR0FBUixDQUNqQ0osS0FEaUMsYUFDakNBLEtBRGlDLHVCQUNqQ0EsS0FBSyxDQUFFSyxHQUFQLENBQVcsTUFBTUMsR0FBTixJQUFhO0FBQ3RCLFlBQU1DLElBQUksR0FBRyxFQUFiO0FBQ0EsWUFBTUMsTUFBTSxHQUFHLEtBQWY7QUFDQSxZQUFNQyxJQUFJLEdBQUksc0NBQXFDakIsVUFBVyxFQUE5RDtBQUNBLFlBQU1rQixPQUFPLEdBQUc7QUFDZEMsUUFBQUEsU0FBUyxFQUFFTCxHQUFHLENBQUNNLEVBREQ7QUFFZEMsUUFBQUEsWUFBWSxFQUFFO0FBRkEsT0FBaEI7O0FBSUEsVUFBSTtBQUNGLGNBQU1DLFFBQVEsR0FBRyxNQUFNaEIsY0FBYyxDQUFDaUIsTUFBZixDQUFzQkMsY0FBdEIsQ0FBcUNDLE9BQXJDLENBQ3JCVCxNQURxQixFQUVyQkMsSUFGcUIsRUFHckJGLElBSHFCLEVBSXJCRyxPQUpxQixDQUF2QjtBQU9BLGNBQU1RLE1BQU0sR0FBR0osUUFBUSxDQUFDUCxJQUFULENBQWNBLElBQTdCO0FBRUEsY0FBTTtBQUNKWSxVQUFBQSxlQURJO0FBRUpDLFVBQUFBLFlBRkk7QUFHSkMsVUFBQUEsb0JBSEk7QUFJSkMsVUFBQUEsb0JBSkk7QUFLSkMsVUFBQUEsb0JBTEk7QUFNSkMsVUFBQUE7QUFOSSxZQU9GTixNQVBKOztBQVNBLGNBQU1PLFNBQVMsR0FBRyxNQUFNO0FBQ3RCLGNBQUlMLFlBQVksS0FBSyxLQUFyQixFQUE0QjtBQUMxQixtQkFBT00sMEJBQW1CQyxRQUExQjtBQUNEOztBQUVELGNBQ0VOLG9CQUFvQixTQUFwQixJQUFBQSxvQkFBb0IsV0FBcEIsSUFBQUEsb0JBQW9CLENBQUVPLEdBQXRCLElBQ0FOLG9CQURBLGFBQ0FBLG9CQURBLGVBQ0FBLG9CQUFvQixDQUFFTSxHQUR0QixJQUVBTCxvQkFGQSxhQUVBQSxvQkFGQSxlQUVBQSxvQkFBb0IsQ0FBRUssR0FIeEIsRUFJRTtBQUNBLG1CQUFPRiwwQkFBbUJHLGlCQUExQjtBQUNEOztBQUVELGlCQUFPSCwwQkFBbUJJLFVBQTFCO0FBQ0QsU0FkRDs7QUFnQkEsZUFBTztBQUNMWCxVQUFBQSxlQURLO0FBRUxDLFVBQUFBLFlBRks7QUFHTEMsVUFBQUEsb0JBSEs7QUFJTEMsVUFBQUEsb0JBSks7QUFLTEMsVUFBQUEsb0JBTEs7QUFNTEMsVUFBQUEsZUFBZSxFQUFFQSxlQUFlLElBQUlPLFNBTi9CO0FBT0xDLFVBQUFBLE1BQU0sRUFBRTFCLEdBQUcsQ0FBQ00sRUFQUDtBQVFMcUIsVUFBQUEsTUFBTSxFQUFFUixTQUFTO0FBUlosU0FBUDtBQVVELE9BN0NELENBNkNFLE9BQU9TLENBQVAsRUFBZTtBQUFBOztBQUNmLGNBQU1DLEtBQUssR0FBRztBQUNaQyxVQUFBQSxLQUFLLGlCQUFFRixDQUFDLENBQUNwQixRQUFKLG9FQUFFLFlBQVlQLElBQWQscURBQUUsaUJBQWtCNkIsS0FEYjtBQUVaQyxVQUFBQSxNQUFNLDJDQUFFSCxDQUFDLENBQUNwQixRQUFKLHNFQUFFLGFBQVlQLElBQWQsc0RBQUUsa0JBQWtCOEIsTUFBcEIseUVBQThCSCxDQUFDLENBQUNJO0FBRjFCLFNBQWQ7QUFLQSxlQUFPO0FBQ0xOLFVBQUFBLE1BQU0sRUFBRTFCLEdBQUcsQ0FBQ00sRUFEUDtBQUVMcUIsVUFBQUEsTUFBTSxFQUFFUCwwQkFBbUJhLEtBRnRCO0FBR0xKLFVBQUFBO0FBSEssU0FBUDtBQUtEO0FBQ0YsS0FqRUQsQ0FEaUMsQ0FBbkM7QUFxRUEsVUFBTUssV0FBVyxHQUFHO0FBQ2xCQyxNQUFBQSxzQkFBc0IsRUFBRXZDLG9CQUROO0FBRWxCc0IsTUFBQUEsZUFBZSxFQUFFLElBQUlrQixJQUFKO0FBRkMsS0FBcEI7QUFLQSxVQUFNLGlDQUFlaEQsK0JBQWYsRUFBcUM4QyxXQUFyQyxDQUFOO0FBRUEsV0FBT0EsV0FBUDtBQUNELEdBL0ZELENBK0ZFLE9BQU9MLEtBQVAsRUFBYztBQUNkLFVBQU1HLE9BQU8sR0FDWEgsS0FBSyxZQUFZUSxLQUFqQixHQUNJUixLQUFLLENBQUNHLE9BRFYsR0FFSSxPQUFPSCxLQUFQLEtBQWlCLFFBQWpCLEdBQ0FBLEtBREEsR0FFQSx1Q0FMTjtBQU9BLFVBQU07QUFDSnRDLE1BQUFBLFFBQVEsRUFBRTtBQUFFK0MsUUFBQUE7QUFBRjtBQUROLFFBRUYsbUNBRko7QUFJQUEsSUFBQUEsR0FBRyxDQUFDLGdDQUFELEVBQW1DTixPQUFuQyxDQUFIO0FBQ0EsV0FBT25DLE9BQU8sQ0FBQzBDLE1BQVIsQ0FBZVYsS0FBZixDQUFQO0FBQ0Q7QUFDRixDQWxITSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFQSV9VUERBVEVTX1NUQVRVUyxcbiAgQXZhaWxhYmxlVXBkYXRlcyxcbiAgUmVzcG9uc2VBcGlBdmFpbGFibGVVcGRhdGVzLFxufSBmcm9tICcuLi8uLi8uLi9jb21tb24vdHlwZXMnO1xuaW1wb3J0IHsgU0FWRURfT0JKRUNUX1VQREFURVMgfSBmcm9tICcuLi8uLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IGdldFNhdmVkT2JqZWN0LCBzZXRTYXZlZE9iamVjdCB9IGZyb20gJy4uL3NhdmVkLW9iamVjdCc7XG5pbXBvcnQgeyBnZXRXYXp1aENvcmUgfSBmcm9tICcuLi8uLi9wbHVnaW4tc2VydmljZXMnO1xuXG5leHBvcnQgY29uc3QgZ2V0VXBkYXRlcyA9IGFzeW5jIChcbiAgcXVlcnlBcGkgPSBmYWxzZSxcbiAgZm9yY2VRdWVyeSA9IGZhbHNlLFxuKTogUHJvbWlzZTxBdmFpbGFibGVVcGRhdGVzPiA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKCFxdWVyeUFwaSkge1xuICAgICAgY29uc3QgYXZhaWxhYmxlVXBkYXRlcyA9IChhd2FpdCBnZXRTYXZlZE9iamVjdChcbiAgICAgICAgU0FWRURfT0JKRUNUX1VQREFURVMsXG4gICAgICApKSBhcyBBdmFpbGFibGVVcGRhdGVzO1xuXG4gICAgICByZXR1cm4gYXZhaWxhYmxlVXBkYXRlcztcbiAgICB9XG5cbiAgICBjb25zdCB7XG4gICAgICBjb250cm9sbGVyczogeyBXYXp1aEhvc3RzQ3RybCB9LFxuICAgICAgc2VydmljZXM6IHsgd2F6dWhBcGlDbGllbnQgfSxcbiAgICB9ID0gZ2V0V2F6dWhDb3JlKCk7XG4gICAgY29uc3Qgd2F6dWhIb3N0c0NvbnRyb2xsZXIgPSBuZXcgV2F6dWhIb3N0c0N0cmwoKTtcblxuICAgIGNvbnN0IGhvc3RzOiB7IGlkOiBzdHJpbmcgfVtdID1cbiAgICAgIGF3YWl0IHdhenVoSG9zdHNDb250cm9sbGVyLmdldEhvc3RzRW50cmllcygpO1xuXG4gICAgY29uc3QgYXBpc0F2YWlsYWJsZVVwZGF0ZXMgPSBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIGhvc3RzPy5tYXAoYXN5bmMgYXBpID0+IHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHt9O1xuICAgICAgICBjb25zdCBtZXRob2QgPSAnR0VUJztcbiAgICAgICAgY29uc3QgcGF0aCA9IGAvbWFuYWdlci92ZXJzaW9uL2NoZWNrP2ZvcmNlX3F1ZXJ5PSR7Zm9yY2VRdWVyeX1gO1xuICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgIGFwaUhvc3RJRDogYXBpLmlkLFxuICAgICAgICAgIGZvcmNlUmVmcmVzaDogdHJ1ZSxcbiAgICAgICAgfTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHdhenVoQXBpQ2xpZW50LmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgICAgcGF0aCxcbiAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICk7XG5cbiAgICAgICAgICBjb25zdCB1cGRhdGUgPSByZXNwb25zZS5kYXRhLmRhdGEgYXMgUmVzcG9uc2VBcGlBdmFpbGFibGVVcGRhdGVzO1xuXG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgY3VycmVudF92ZXJzaW9uLFxuICAgICAgICAgICAgdXBkYXRlX2NoZWNrLFxuICAgICAgICAgICAgbGFzdF9hdmFpbGFibGVfbWFqb3IsXG4gICAgICAgICAgICBsYXN0X2F2YWlsYWJsZV9taW5vcixcbiAgICAgICAgICAgIGxhc3RfYXZhaWxhYmxlX3BhdGNoLFxuICAgICAgICAgICAgbGFzdF9jaGVja19kYXRlLFxuICAgICAgICAgIH0gPSB1cGRhdGU7XG5cbiAgICAgICAgICBjb25zdCBnZXRTdGF0dXMgPSAoKSA9PiB7XG4gICAgICAgICAgICBpZiAodXBkYXRlX2NoZWNrID09PSBmYWxzZSkge1xuICAgICAgICAgICAgICByZXR1cm4gQVBJX1VQREFURVNfU1RBVFVTLkRJU0FCTEVEO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgIGxhc3RfYXZhaWxhYmxlX21ham9yPy50YWcgfHxcbiAgICAgICAgICAgICAgbGFzdF9hdmFpbGFibGVfbWlub3I/LnRhZyB8fFxuICAgICAgICAgICAgICBsYXN0X2F2YWlsYWJsZV9wYXRjaD8udGFnXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIEFQSV9VUERBVEVTX1NUQVRVUy5BVkFJTEFCTEVfVVBEQVRFUztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIEFQSV9VUERBVEVTX1NUQVRVUy5VUF9UT19EQVRFO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgY3VycmVudF92ZXJzaW9uLFxuICAgICAgICAgICAgdXBkYXRlX2NoZWNrLFxuICAgICAgICAgICAgbGFzdF9hdmFpbGFibGVfbWFqb3IsXG4gICAgICAgICAgICBsYXN0X2F2YWlsYWJsZV9taW5vcixcbiAgICAgICAgICAgIGxhc3RfYXZhaWxhYmxlX3BhdGNoLFxuICAgICAgICAgICAgbGFzdF9jaGVja19kYXRlOiBsYXN0X2NoZWNrX2RhdGUgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgYXBpX2lkOiBhcGkuaWQsXG4gICAgICAgICAgICBzdGF0dXM6IGdldFN0YXR1cygpLFxuICAgICAgICAgIH07XG4gICAgICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgICAgIGNvbnN0IGVycm9yID0ge1xuICAgICAgICAgICAgdGl0bGU6IGUucmVzcG9uc2U/LmRhdGE/LnRpdGxlLFxuICAgICAgICAgICAgZGV0YWlsOiBlLnJlc3BvbnNlPy5kYXRhPy5kZXRhaWwgPz8gZS5tZXNzYWdlLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYXBpX2lkOiBhcGkuaWQsXG4gICAgICAgICAgICBzdGF0dXM6IEFQSV9VUERBVEVTX1NUQVRVUy5FUlJPUixcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH0pLFxuICAgICk7XG5cbiAgICBjb25zdCBzYXZlZE9iamVjdCA9IHtcbiAgICAgIGFwaXNfYXZhaWxhYmxlX3VwZGF0ZXM6IGFwaXNBdmFpbGFibGVVcGRhdGVzLFxuICAgICAgbGFzdF9jaGVja19kYXRlOiBuZXcgRGF0ZSgpLFxuICAgIH07XG5cbiAgICBhd2FpdCBzZXRTYXZlZE9iamVjdChTQVZFRF9PQkpFQ1RfVVBEQVRFUywgc2F2ZWRPYmplY3QpO1xuXG4gICAgcmV0dXJuIHNhdmVkT2JqZWN0O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICA/IGVycm9yLm1lc3NhZ2VcbiAgICAgICAgOiB0eXBlb2YgZXJyb3IgPT09ICdzdHJpbmcnXG4gICAgICAgID8gZXJyb3JcbiAgICAgICAgOiAnRXJyb3IgdHJ5aW5nIHRvIGdldCBhdmFpbGFibGUgdXBkYXRlcyc7XG5cbiAgICBjb25zdCB7XG4gICAgICBzZXJ2aWNlczogeyBsb2cgfSxcbiAgICB9ID0gZ2V0V2F6dWhDb3JlKCk7XG5cbiAgICBsb2coJ3dhenVoLWNoZWNrLXVwZGF0ZXM6Z2V0VXBkYXRlcycsIG1lc3NhZ2UpO1xuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gIH1cbn07XG4iXX0=